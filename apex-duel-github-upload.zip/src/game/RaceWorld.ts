import * as THREE from 'three';
import { RaceAudio } from './audio';
import { buildCarVisual, CarVisual, updateCarVisual } from './carLoader';
import { PooledRaceParticles } from './particles';
import {
  applyWallBounce,
  CAR_IDS,
  CAR_VARIANTS,
  CHUNK_SIZE,
  clamp,
  clampDt,
  computeAiControl,
  computeGearAndRpm,
  createCarState,
  DIFFICULTY_SPECS,
  driveCar,
  formatRaceTime,
  getPlayerPosition,
  getStandings,
  getUpcomingTurn,
  HW,
  isInSlipstream,
  isWrongWay,
  LAPS,
  locateOnTrack,
  NCH,
  placeCar,
  recoverCar,
  resolveCollision,
  TRACK,
  WALL,
} from './rules';
import {
  createRaceTextures,
  paintGantryLights,
  RaceTextures,
} from './textures';
import {
  BodyState,
  CameraMode,
  CarState,
  CarVariantId,
  ControlInput,
  Difficulty,
  GameMode,
  HudSnapshot,
  TimeOfDay,
} from './types';

const SKID_MAX = 150;

function detectSoftwareGl(renderer: THREE.WebGLRenderer): boolean {
  try {
    const gl = renderer.getContext();
    const dbg = gl.getExtension('WEBGL_debug_renderer_info');
    const name = dbg
      ? String(gl.getParameter(dbg.UNMASKED_RENDERER_WEBGL) || '')
      : String(gl.getParameter(gl.RENDERER) || '');
    return /SwiftShader|llvmpipe|Softpipe|Software Rasterizer|ANGLE.*SwiftShader/i.test(
      name
    );
  } catch {
    return false;
  }
}

export class RaceWorld {
  private container: HTMLElement;
  private minimapCanvas: HTMLCanvasElement;
  private minimapCtx: CanvasRenderingContext2D | null;
  private onHudUpdate: (snap: HudSnapshot) => void;

  private renderer: THREE.WebGLRenderer;
  private isSoftwareGl: boolean;
  private scene: THREE.Scene;
  private camera: THREE.PerspectiveCamera;
  private textures: RaceTextures;
  private audio = new RaceAudio();
  private particles = new PooledRaceParticles();

  private hemiLight: THREE.HemisphereLight;
  private sunLight: THREE.DirectionalLight;
  private fillLight: THREE.DirectionalLight;

  private skyMat: THREE.ShaderMaterial;
  private sunDiscMat: THREE.MeshBasicMaterial;
  private sunHaloMat: THREE.SpriteMaterial;
  private sunDiscMesh: THREE.Mesh;
  private sunHaloSprite: THREE.Sprite;
  private mountainCylMat: THREE.MeshBasicMaterial;
  private skylineCylMat: THREE.MeshBasicMaterial;
  private blimpGroup: THREE.Group;

  private pmrem: THREE.PMREMGenerator;
  private envTexDay: THREE.Texture | null = null;
  private envTexSunset: THREE.Texture | null = null;
  private envTexNight: THREE.Texture | null = null;

  private trackGroup = new THREE.Group();
  private carsGroup = new THREE.Group();
  private chunkIndex = 0;

  // Dynamic single-mesh skid buffer
  private skidPositions = new Float32Array(SKID_MAX * 4 * 3);
  private skidColors = new Float32Array(SKID_MAX * 4 * 3);
  private skidGeo: THREE.BufferGeometry;
  private skidHead = 0;

  // Game & car state
  private mode: GameMode = 'menu';
  private timeOfDay: TimeOfDay = 'day';
  private difficulty: Difficulty = 'pro';
  private selectedCarId: CarVariantId = 'sup';
  private cameraMode: CameraMode = 0;
  private muted = false;

  private cars: CarState[] = [];
  private visuals: CarVisual[] = [];
  private showroomVis: CarVisual | null = null;
  private playerIndex = 0;

  private raceTimeSec = 0;
  private countdownSec = 3.2;
  private lastCountdownBeep = 4;
  private prevGantryLit = -1;
  private shakeTrauma = 0;
  private recordLapSec = 0;
  private bannerText = '';
  private bannerTone: 'info' | 'best' | 'boost' = 'info';
  private bannerTimer = 0;
  private prevPlayerGear = 1;
  private prevDriftBoost = false;
  private speedStreakClock = 0;

  // Camera smoothing & interactive showroom drag state
  private camX = 0;
  private camY = 5;
  private camZ = -10;
  private lookX = 0;
  private lookY = 1.5;
  private lookZ = 0;
  private showroomAngle = 0.88;
  private isDraggingShowroom = false;
  private dragStartX = 0;
  private dragStartAngle = 0.88;

  // Controls
  private keys: Record<string, boolean> = {};
  private touchState: ControlInput = { st: 0, th: 0, br: 0, hb: 0, nt: 0 };

  // Loop & timing
  private rafId: number | null = null;
  private paceTimer: number | null = null;
  private prevMs = 0;
  private accumSec = 0;
  private totalClockSec = 0;
  private disposed = false;

  // Zero-GC scratch objects
  private tmpMat = new THREE.Matrix4();
  private tmpPos = new THREE.Vector3();
  private tmpQuat = new THREE.Quaternion();
  private tmpScale = new THREE.Vector3();
  private tmpEuler = new THREE.Euler();
  private tmpColor = new THREE.Color();

  constructor(
    container: HTMLElement,
    minimapCanvas: HTMLCanvasElement,
    onHudUpdate: (snap: HudSnapshot) => void
  ) {
    this.container = container;
    this.minimapCanvas = minimapCanvas;
    this.minimapCtx = minimapCanvas.getContext('2d');
    this.onHudUpdate = onHudUpdate;

    const w = container.clientWidth || window.innerWidth || 1280;
    const h = container.clientHeight || window.innerHeight || 720;

    // Temporary renderer probe for software WebGL check
    this.renderer = new THREE.WebGLRenderer({
      antialias: true,
      powerPreference: 'high-performance',
    });
    this.isSoftwareGl = detectSoftwareGl(this.renderer);

    if (this.isSoftwareGl) {
      // Keep antialiasing + 1.0 pixel ratio so car silhouettes and HD textures look razor sharp
      this.renderer.setPixelRatio(1);
    } else {
      this.renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, 2));
      this.renderer.shadowMap.enabled = true;
      this.renderer.shadowMap.type = THREE.PCFSoftShadowMap;
    }

    this.renderer.setSize(w, h);
    this.renderer.outputColorSpace = THREE.SRGBColorSpace;
    this.renderer.toneMapping = THREE.ACESFilmicToneMapping;
    this.renderer.toneMappingExposure = 0.94;
    container.appendChild(this.renderer.domElement);

    const maxAniso = this.isSoftwareGl
      ? 1
      : Math.min(8, this.renderer.capabilities.getMaxAnisotropy());
    this.textures = createRaceTextures(maxAniso, () => {
      if (!this.disposed && this.isSoftwareGl && this.mode === 'menu') {
        this.renderMenuOnce();
      }
    });

    this.scene = new THREE.Scene();
    this.scene.fog = new THREE.Fog(0xb5d6f5, 320, 1850);

    this.camera = new THREE.PerspectiveCamera(62, w / h, 0.35, 3600);
    this.camera.position.set(0, 3.6, -8);

    // Three-point outdoor HDR-like lighting
    this.hemiLight = new THREE.HemisphereLight(0xdaf0ff, 0x3b4d2b, 0.95);
    this.scene.add(this.hemiLight);

    this.sunLight = new THREE.DirectionalLight(0xfff5e4, 2.55);
    this.sunLight.position.set(160, 220, 120);
    if (!this.isSoftwareGl) {
      this.sunLight.castShadow = true;
      this.sunLight.shadow.mapSize.set(1536, 1536);
      this.sunLight.shadow.camera.near = 10;
      this.sunLight.shadow.camera.far = 420;
      const d = 110;
      this.sunLight.shadow.camera.left = -d;
      this.sunLight.shadow.camera.right = d;
      this.sunLight.shadow.camera.top = d;
      this.sunLight.shadow.camera.bottom = -d;
      this.sunLight.shadow.bias = -0.0006;
    }
    this.scene.add(this.sunLight);
    this.scene.add(this.sunLight.target);

    this.fillLight = new THREE.DirectionalLight(0x7cb8ff, 0.65);
    this.fillLight.position.set(-140, 80, -160);
    this.scene.add(this.fillLight);

    // PMREM Sky + Terrain Reflection Environment
    this.pmrem = new THREE.PMREMGenerator(this.renderer);
    this.buildEnvMaps();

    // Dynamic Sky Shader Dome with Sun/Moon Bloom, Cirrus Clouds & Night Starfield
    this.skyMat = new THREE.ShaderMaterial({
      uniforms: {
        uTop: { value: new THREE.Color(0x286bc8) },
        uMid: { value: new THREE.Color(0x7dbdf2) },
        uHor: { value: new THREE.Color(0xd2e7f8) },
        uSunDir: { value: new THREE.Vector3(0.45, 0.55, 0.4).normalize() },
        uSunCol: { value: new THREE.Color(0xfff6dc) },
        uCloudCol: { value: new THREE.Color(0xffffff) },
        uTime: { value: 0 },
        uShowClouds: { value: this.isSoftwareGl ? 0.0 : 1.0 },
        uStarIntensity: { value: 0.0 },
      },
      vertexShader: `
        varying vec3 vWorldDir;
        void main() {
          vec4 wp = modelMatrix * vec4(position, 1.0);
          vWorldDir = normalize(position);
          gl_Position = projectionMatrix * viewMatrix * wp;
        }
      `,
      fragmentShader: `
        uniform vec3 uTop, uMid, uHor, uSunDir, uSunCol, uCloudCol;
        uniform float uTime, uShowClouds, uStarIntensity;
        varying vec3 vWorldDir;

        float hash(vec2 p) {
          return fract(sin(dot(p, vec2(127.1, 311.7))) * 43758.5453);
        }
        float noise(vec2 p) {
          vec2 i = floor(p);
          vec2 f = fract(p);
          vec2 u = f * f * (3.0 - 2.0 * f);
          return mix(
            mix(hash(i + vec2(0.0, 0.0)), hash(i + vec2(1.0, 0.0)), u.x),
            mix(hash(i + vec2(0.0, 1.0)), hash(i + vec2(1.0, 1.0)), u.x),
            u.y
          );
        }

        void main() {
          vec3 dir = normalize(vWorldDir);
          float h = clamp(dir.y, 0.0, 1.0);
          vec3 col = mix(uHor, uMid, pow(h, 0.48));
          col = mix(col, uTop, pow(h, 1.15));

          // Layered procedural cirrus clouds above horizon
          if (uShowClouds > 0.5 && dir.y > 0.03) {
            vec2 uv = dir.xz / (dir.y + 0.22) * 1.45 + vec2(uTime * 0.012, uTime * 0.004);
            float n = noise(uv * 2.2) * 0.6 + noise(uv * 4.7 + 3.1) * 0.4;
            float cloudMask = smoothstep(0.56, 0.86, n) * smoothstep(0.03, 0.24, dir.y) * (1.0 - smoothstep(0.55, 0.95, dir.y));
            col = mix(col, uCloudCol, cloudMask * 0.46);
          }

          // Crisp pinpoint alpine night starfield
          if (uStarIntensity > 0.01 && dir.y > 0.06) {
            vec2 skyCoord = vec2(atan(dir.z, dir.x) * 68.0, asin(clamp(dir.y, -1.0, 1.0)) * 136.0);
            vec2 cell = floor(skyCoord);
            vec2 f = fract(skyCoord);
            float st = hash(cell);
            if (st > 0.968) {
              vec2 jitter = vec2(hash(cell + 17.3), hash(cell + 41.9)) * 0.52 + 0.24;
              float dist = length(f - jitter);
              float radius = mix(0.055, 0.11, fract(st * 137.0));
              float point = smoothstep(radius, radius * 0.15, dist);
              float twinkle = 0.68 + 0.32 * sin(uTime * 2.4 + st * 120.0);
              vec3 starCol = mix(vec3(0.84, 0.91, 1.0), vec3(1.0, 0.95, 0.86), fract(st * 53.0));
              col += starCol * point * twinkle * uStarIntensity * smoothstep(0.06, 0.28, dir.y);
            }
          }

          // Mie atmospheric sun / moon halo
          float sd = max(0.0, dot(dir, normalize(uSunDir)));
          col += uSunCol * pow(sd, 10.0) * 0.34;
          col += uSunCol * pow(sd, 96.0) * 0.65;
          gl_FragColor = vec4(col, 1.0);
        }
      `,
      side: THREE.BackSide,
      depthWrite: false,
    });
    this.scene.add(new THREE.Mesh(new THREE.SphereGeometry(2600, 32, 20), this.skyMat));

    // Sun disc & glow sprite
    this.sunDiscMat = new THREE.MeshBasicMaterial({
      color: 0xffffff,
      fog: false,
    });
    this.sunDiscMesh = new THREE.Mesh(
      new THREE.CircleGeometry(42, 24),
      this.sunDiscMat
    );
    this.scene.add(this.sunDiscMesh);

    this.sunHaloMat = new THREE.SpriteMaterial({
      map: this.textures.nitroGlow,
      color: 0xffe4b5,
      transparent: true,
      opacity: 0.42,
      blending: THREE.AdditiveBlending,
      depthWrite: false,
      fog: false,
    });
    this.sunHaloSprite = new THREE.Sprite(this.sunHaloMat);
    this.sunHaloSprite.scale.set(280, 280, 1);
    this.scene.add(this.sunHaloSprite);

    // 1. Outer 3072px photorealistic Alpine Mountain Panorama (fog: false so full HD crispness shows!)
    this.mountainCylMat = new THREE.MeshBasicMaterial({
      map: this.textures.mountainDay,
      transparent: true,
      alphaTest: 0.04,
      side: THREE.BackSide,
      depthWrite: false,
      fog: false,
    });
    const mountainCyl = new THREE.Mesh(
      new THREE.CylinderGeometry(1650, 1650, 480, 72, 1, true),
      this.mountainCylMat
    );
    mountainCyl.position.set(150, 212, 160);
    this.scene.add(mountainCyl);

    // 2. Mid-distance Motorsport Circuit Skyline (grandstands, towers, floodlights — fog: false, sits cleanly below alpine peaks)
    this.skylineCylMat = new THREE.MeshBasicMaterial({
      map: this.textures.farSkyline,
      transparent: true,
      alphaTest: 0.08,
      side: THREE.BackSide,
      depthWrite: false,
      fog: false,
      opacity: 0.85,
      color: 0xe8f0fa,
    });
    const skylineCyl = new THREE.Mesh(
      new THREE.CylinderGeometry(1180, 1180, 130, 72, 1, true),
      this.skylineCylMat
    );
    skylineCyl.position.set(150, 48, 160);
    this.scene.add(skylineCyl);

    // Lush HD Alpine valley meadow ground
    const grassMesh = new THREE.Mesh(
      new THREE.PlaneGeometry(4200, 4200),
      new THREE.MeshStandardMaterial({
        map: this.textures.grass,
        roughness: 0.92,
        metalness: 0.02,
      })
    );
    grassMesh.rotation.x = -Math.PI * 0.5;
    grassMesh.position.y = -0.05;
    grassMesh.receiveShadow = !this.isSoftwareGl;
    this.scene.add(grassMesh);

    this.blimpGroup = this.buildSkyBlimp();
    this.scene.add(this.blimpGroup);

    // Skid mark buffer mesh
    const skidIdx: number[] = [];
    for (let i = 0; i < SKID_MAX; i++) {
      const a = i * 4;
      skidIdx.push(a, a + 1, a + 2, a, a + 2, a + 3);
    }
    this.skidGeo = new THREE.BufferGeometry();
    this.skidGeo.setAttribute(
      'position',
      new THREE.BufferAttribute(this.skidPositions, 3)
    );
    this.skidGeo.setAttribute(
      'color',
      new THREE.BufferAttribute(this.skidColors, 3)
    );
    this.skidGeo.setIndex(skidIdx);
    const skidMesh = new THREE.Mesh(
      this.skidGeo,
      new THREE.MeshBasicMaterial({
        vertexColors: true,
        transparent: true,
        opacity: 0.56,
        depthWrite: false,
        polygonOffset: true,
        polygonOffsetFactor: -2,
        polygonOffsetUnits: -2,
      })
    );
    skidMesh.frustumCulled = false;
    skidMesh.renderOrder = 3;
    this.scene.add(skidMesh);

    this.scene.add(this.trackGroup);
    this.scene.add(this.carsGroup);
    this.scene.add(this.particles.group);

    // Load saved personal best circuit lap time if present
    try {
      const saved = window.localStorage.getItem('apex_duel_best_lap_sec');
      const parsed = saved ? Number(saved) : 0;
      if (Number.isFinite(parsed) && parsed > 10 && parsed < 600) {
        this.recordLapSec = parsed;
      }
    } catch {
      // ignore storage errors in private iframes
    }

    // Build chunk 0 immediately for the live 3D garage/grid showroom
    this.buildChunk(0);
    this.chunkIndex = 1;
    this.rebuildShowroomCar();
    this.applyTimeOfDay('day');

    window.addEventListener('resize', this.handleResize);
    window.addEventListener('keydown', this.handleKeyDown);
    window.addEventListener('keyup', this.handleKeyUp);
    window.addEventListener('blur', this.handleBlur);
    this.renderer.domElement.addEventListener('pointerdown', this.handleCanvasPointerDown);
    window.addEventListener('pointermove', this.handleCanvasPointerMove);
    window.addEventListener('pointerup', this.handleCanvasPointerUp);

    this.prevMs = performance.now();
    this.emitHud();
    this.scheduleNextFrame();
  }

  private buildEnvMaps() {
    const makeEnv = (top: number, mid: number, bot: number, sunCol: number) => {
      const es = new THREE.Scene();
      const g = new THREE.SphereGeometry(20, 24, 16);
      const m = new THREE.ShaderMaterial({
        uniforms: {
          uTop: { value: new THREE.Color(top) },
          uMid: { value: new THREE.Color(mid) },
          uBot: { value: new THREE.Color(bot) },
        },
        vertexShader: `
          varying vec3 vD;
          void main() { vD = normalize(position); gl_Position = projectionMatrix * modelViewMatrix * vec4(position,1.0); }
        `,
        fragmentShader: `
          uniform vec3 uTop, uMid, uBot;
          varying vec3 vD;
          void main() {
            float y = vD.y;
            vec3 c = y > 0.0 ? mix(uMid, uTop, pow(y, 0.72)) : mix(uMid, uBot, pow(-y, 0.55));
            gl_FragColor = vec4(c, 1.0);
          }
        `,
        side: THREE.BackSide,
      });
      es.add(new THREE.Mesh(g, m));

      // Crisp overhead automotive light strips for realistic clearcoat body-line reflections
      const stripGeo = new THREE.PlaneGeometry(14, 2.2);
      const stripMat = new THREE.MeshBasicMaterial({ color: sunCol, side: THREE.DoubleSide });
      const s1 = new THREE.Mesh(stripGeo, stripMat);
      s1.position.set(0, 12, 5);
      s1.rotation.x = Math.PI * 0.42;
      es.add(s1);
      const s2 = new THREE.Mesh(stripGeo, stripMat);
      s2.position.set(7, 9, -6);
      s2.lookAt(0, 0, 0);
      es.add(s2);

      const rt = this.pmrem.fromScene(es, 0.035);
      g.dispose();
      m.dispose();
      stripGeo.dispose();
      stripMat.dispose();
      return rt.texture;
    };
    this.envTexDay = makeEnv(0x3a82e0, 0xe8f4ff, 0x566452, 0xffffff);
    this.envTexSunset = makeEnv(0x2c2f60, 0xffae73, 0x4b3830, 0xffe4bd);
    this.envTexNight = makeEnv(0x0b1530, 0x243b66, 0x111722, 0xd8ecff);
  }

  private buildSkyBlimp(): THREE.Group {
    const blimp = new THREE.Group();
    const hull = new THREE.Mesh(
      new THREE.SphereGeometry(14, 20, 14),
      new THREE.MeshStandardMaterial({
        color: 0xf1f5f9,
        roughness: 0.35,
        metalness: 0.25,
      })
    );
    hull.scale.set(1, 0.72, 2.75);
    blimp.add(hull);

    const stripe = new THREE.Mesh(
      new THREE.CylinderGeometry(11.4, 11.4, 8, 20, 1, true),
      new THREE.MeshStandardMaterial({
        color: 0xff6d1f,
        roughness: 0.4,
        metalness: 0.3,
      })
    );
    stripe.rotation.x = Math.PI * 0.5;
    blimp.add(stripe);

    const gondola = new THREE.Mesh(
      new THREE.BoxGeometry(3.2, 2.4, 8.5),
      new THREE.MeshStandardMaterial({ color: 0x1e293b, roughness: 0.5 })
    );
    gondola.position.y = -10.8;
    blimp.add(gondola);

    const finGeo = new THREE.BoxGeometry(0.4, 7.5, 9);
    const finMat = new THREE.MeshStandardMaterial({ color: 0xff6d1f, roughness: 0.4 });
    const vFin = new THREE.Mesh(finGeo, finMat);
    vFin.position.set(0, 7, -30);
    blimp.add(vFin);
    const hFin = new THREE.Mesh(finGeo, finMat);
    hFin.rotation.z = Math.PI * 0.5;
    hFin.position.set(0, 0, -30);
    blimp.add(hFin);

    blimp.position.set(150, 145, 160);
    return blimp;
  }

  private buildChunk(ci: number) {
    const N = TRACK.N;
    const i0 = ci * CHUNK_SIZE;
    const i1 = Math.min(N, (ci + 1) * CHUNK_SIZE);
    if (i0 >= N) return;

    const grp = new THREE.Group();
    const count = i1 - i0;
    const hw = HW;
    const kw = 1.65;

    // 1. PBR Asphalt ribbon
    const rv: number[] = [];
    const ru: number[] = [];
    const ridx: number[] = [];
    for (let k = 0; k <= count; k++) {
      const i = (i0 + k) % N;
      rv.push(
        TRACK.x[i] - TRACK.nx[i] * hw,
        0.12,
        TRACK.z[i] - TRACK.nz[i] * hw,
        TRACK.x[i] + TRACK.nx[i] * hw,
        0.12,
        TRACK.z[i] + TRACK.nz[i] * hw
      );
      const v = (i0 + k) * 3.5 / 20;
      ru.push(0, v, 1, v);
    }
    for (let k = 0; k < count; k++) {
      const a = k * 2;
      ridx.push(a, a + 2, a + 1, a + 1, a + 2, a + 3);
    }
    const rg = new THREE.BufferGeometry();
    rg.setAttribute('position', new THREE.Float32BufferAttribute(rv, 3));
    rg.setAttribute('uv', new THREE.Float32BufferAttribute(ru, 2));
    rg.setIndex(ridx);
    rg.computeVertexNormals();
    const roadMesh = new THREE.Mesh(
      rg,
      new THREE.MeshStandardMaterial({
        map: this.textures.asphalt,
        bumpMap: this.textures.asphaltBump,
        bumpScale: 0.055,
        roughnessMap: this.textures.asphaltRough,
        roughness: 0.86,
        metalness: 0.06,
        envMapIntensity: 0.65,
        side: THREE.DoubleSide,
      })
    );
    roadMesh.receiveShadow = !this.isSoftwareGl;
    grp.add(roadMesh);

    // 2. Red/White chamfered curbs
    for (const side of [-1, 1]) {
      const cv: number[] = [];
      const cc: number[] = [];
      const cidx: number[] = [];
      for (let k = 0; k <= count; k++) {
        const i = (i0 + k) % N;
        const px = TRACK.x[i];
        const pz = TRACK.z[i];
        const nx = TRACK.nx[i];
        const nz = TRACK.nz[i];
        const r = ((i0 + k) % 2 === 0 ? 1 : 0) === 1;
        cv.push(
          px + nx * side * hw,
          0.14,
          pz + nz * side * hw,
          px + nx * side * (hw + kw),
          0.19,
          pz + nz * side * (hw + kw)
        );
        const col = r ? [0.88, 0.14, 0.14] : [0.94, 0.95, 0.97];
        cc.push(...col, ...col);
      }
      for (let k = 0; k < count; k++) {
        const a = k * 2;
        if (side > 0) {
          cidx.push(a, a + 2, a + 1, a + 1, a + 2, a + 3);
        } else {
          cidx.push(a, a + 1, a + 2, a + 1, a + 3, a + 2);
        }
      }
      const cg = new THREE.BufferGeometry();
      cg.setAttribute('position', new THREE.Float32BufferAttribute(cv, 3));
      cg.setAttribute('color', new THREE.Float32BufferAttribute(cc, 3));
      cg.setIndex(cidx);
      cg.computeVertexNormals();
      const curbMesh = new THREE.Mesh(
        cg,
        new THREE.MeshStandardMaterial({
          vertexColors: true,
          roughness: 0.56,
          metalness: 0.1,
          side: THREE.DoubleSide,
        })
      );
      curbMesh.receiveShadow = !this.isSoftwareGl;
      grp.add(curbMesh);
    }

    // 3. Crisp UV-mapped FIA concrete barriers + brushed metallic top guardrail
    for (const side of [-1, 1]) {
      const bv: number[] = [];
      const buv: number[] = [];
      const bidx: number[] = [];
      const mv: number[] = [];
      const midx: number[] = [];

      for (let k = 0; k <= count; k++) {
        const i = (i0 + k) % N;
        const x = TRACK.x[i] + TRACK.nx[i] * side * (WALL + 1.2);
        const z = TRACK.z[i] + TRACK.nz[i] * side * (WALL + 1.2);
        bv.push(x, 0, z, x, 1.35, z);
        const u = (i0 + k) * 0.25;
        buv.push(u, 0, u, 1);

        const rx = TRACK.x[i] + TRACK.nx[i] * side * (WALL + 1.02);
        const rz = TRACK.z[i] + TRACK.nz[i] * side * (WALL + 1.02);
        mv.push(rx, 1.35, rz, rx, 1.62, rz);
      }
      for (let k = 0; k < count; k++) {
        const a = k * 2;
        bidx.push(a, a + 1, a + 2, a + 1, a + 3, a + 2);
        midx.push(a, a + 1, a + 2, a + 1, a + 3, a + 2);
      }
      const bg = new THREE.BufferGeometry();
      bg.setAttribute('position', new THREE.Float32BufferAttribute(bv, 3));
      bg.setAttribute('uv', new THREE.Float32BufferAttribute(buv, 2));
      bg.setIndex(bidx);
      bg.computeVertexNormals();
      grp.add(
        new THREE.Mesh(
          bg,
          new THREE.MeshStandardMaterial({
            map: this.textures.barrier,
            roughness: 0.62,
            metalness: 0.12,
            side: THREE.DoubleSide,
          })
        )
      );

      const mg = new THREE.BufferGeometry();
      mg.setAttribute('position', new THREE.Float32BufferAttribute(mv, 3));
      mg.setIndex(midx);
      mg.computeVertexNormals();
      grp.add(
        new THREE.Mesh(
          mg,
          new THREE.MeshStandardMaterial({
            color: 0xc8d2df,
            roughness: 0.28,
            metalness: 0.82,
            side: THREE.DoubleSide,
          })
        )
      );
    }

    // 4. Instanced boulders
    const boulderPositions: Array<{
      x: number;
      y: number;
      z: number;
      rx: number;
      ry: number;
      rz: number;
      s: number;
    }> = [];
    for (let i = i0; i < i1; i++) {
      if ((i * 7 + 3) % 13 !== 0) continue;
      const side = (i % 2 ? 1 : -1) * (WALL + 6 + (i % 5) * 4);
      boulderPositions.push({
        x: TRACK.x[i] + TRACK.nx[i] * side,
        y: 0.4 + (i % 3) * 0.25,
        z: TRACK.z[i] + TRACK.nz[i] * side,
        rx: i * 0.6,
        ry: i * 1.1,
        rz: 0,
        s: 0.85 + (i % 4) * 0.42,
      });
    }
    if (boulderPositions.length) {
      const bGeo = new THREE.DodecahedronGeometry(1.15, 0);
      const bMat = new THREE.MeshStandardMaterial({
        roughness: 0.9,
        metalness: 0.05,
        flatShading: true,
      });
      const bInst = new THREE.InstancedMesh(bGeo, bMat, boulderPositions.length);
      for (let j = 0; j < boulderPositions.length; j++) {
        const bp = boulderPositions[j];
        this.tmpPos.set(bp.x, bp.y, bp.z);
        this.tmpEuler.set(bp.rx, bp.ry, bp.rz);
        this.tmpQuat.setFromEuler(this.tmpEuler);
        this.tmpScale.set(bp.s, bp.s * 0.7, bp.s);
        this.tmpMat.compose(this.tmpPos, this.tmpQuat, this.tmpScale);
        bInst.setMatrixAt(j, this.tmpMat);
        this.tmpColor.setHSL(0.08, 0.14, 0.34 + ((j * 7) % 5) * 0.035);
        bInst.setColorAt(j, this.tmpColor);
      }
      bInst.instanceMatrix.needsUpdate = true;
      if (bInst.instanceColor) bInst.instanceColor.needsUpdate = true;
      grp.add(bInst);
    }

    // 5. Photorealistic 4-column HD alpine pine & spruce billboard trees
    const tv: number[] = [];
    const tu: number[] = [];
    const tidx: number[] = [];
    let tc = 0;
    for (let i = i0; i < i1; i += 2) {
      for (const sgn of [-1, 1]) {
        const h = (i * 2654435761 + sgn * 999983) >>> 0;
        if (h % 5 > 3) continue;
        const d = WALL + 8 + (h % 68);
        const cx = TRACK.x[i] + TRACK.nx[i] * sgn * d;
        const cz = TRACK.z[i] + TRACK.nz[i] * sgn * d;
        const sz = 7.5 + (h % 6);
        const col = h % 4;
        const u0 = col / 4 + 0.012;
        const u1 = (col + 1) / 4 - 0.012;
        const v0 = 0.06;
        const v1 = 0.96;
        const r = (h % 100) * 0.0314;

        for (let a = 0; a < 2; a++) {
          const ang = r + a * Math.PI * 0.5;
          const dx = Math.cos(ang) * sz * 0.48;
          const dz = Math.sin(ang) * sz * 0.48;
          tv.push(
            cx - dx,
            -0.2,
            cz - dz,
            cx + dx,
            -0.2,
            cz + dz,
            cx + dx,
            sz * 1.48,
            cz + dz,
            cx - dx,
            sz * 1.48,
            cz - dz
          );
          tu.push(u0, v0, u1, v0, u1, v1, u0, v1);
          const q = tc * 4;
          tidx.push(q, q + 1, q + 2, q, q + 2, q + 3);
          tc++;
        }
      }
    }
    if (tc) {
      const tg = new THREE.BufferGeometry();
      tg.setAttribute('position', new THREE.Float32BufferAttribute(tv, 3));
      tg.setAttribute('uv', new THREE.Float32BufferAttribute(tu, 2));
      tg.setIndex(tidx);
      const treesMesh = new THREE.Mesh(
        tg,
        new THREE.MeshBasicMaterial({
          map: this.textures.trees,
          alphaTest: 0.42,
          side: THREE.DoubleSide,
        })
      );
      grp.add(treesMesh);
    }

    // 6. Grandstands, Sponsor Boards, Stadium Floodlight Pylons, Tyre Chicane Stacks
    const standMat = new THREE.MeshStandardMaterial({
      color: 0x384354,
      roughness: 0.72,
      metalness: 0.25,
    });
    const crowdMat = new THREE.MeshBasicMaterial({ map: this.textures.crowd });
    const roofMat = new THREE.MeshStandardMaterial({
      color: 0xe6ebf2,
      roughness: 0.35,
      metalness: 0.55,
    });
    const postMat = new THREE.MeshStandardMaterial({
      color: 0x222936,
      roughness: 0.4,
      metalness: 0.75,
    });
    const floodBulbMat = new THREE.MeshStandardMaterial({
      color: 0xffffff,
      emissive: 0xfff3d6,
      emissiveIntensity: 3.0,
      roughness: 0.2,
    });

    for (let i = i0; i < i1; i++) {
      // Grandstands
      if (i % 56 === 10) {
        const sgn = (i / 56) % 2 ? 1 : -1;
        const g = new THREE.Group();
        const base = new THREE.Mesh(new THREE.BoxGeometry(24, 3.6, 8), standMat);
        base.position.y = 1.8;
        g.add(base);
        const seats = new THREE.Mesh(new THREE.PlaneGeometry(23, 5.2), crowdMat);
        seats.position.set(0, 4.4, 2.2);
        seats.rotation.x = -0.58;
        g.add(seats);
        const roof = new THREE.Mesh(new THREE.BoxGeometry(25, 0.35, 9), roofMat);
        roof.position.set(0, 7.6, -0.5);
        g.add(roof);
        g.position.set(
          TRACK.x[i] + TRACK.nx[i] * sgn * (WALL + 14),
          0,
          TRACK.z[i] + TRACK.nz[i] * sgn * (WALL + 14)
        );
        g.rotation.y = TRACK.h[i] + (sgn > 0 ? -Math.PI * 0.5 : Math.PI * 0.5);
        grp.add(g);
      }

      // Sponsor billboards
      if (i % 34 === 6) {
        const sgn = (i / 34) % 2 ? -1 : 1;
        const b = new THREE.Group();
        const panel = new THREE.Mesh(
          new THREE.BoxGeometry(11.2, 3.2, 0.35),
          new THREE.MeshStandardMaterial({
            map: this.textures.sponsors[(i / 34 | 0) % this.textures.sponsors.length],
            roughness: 0.42,
            metalness: 0.15,
          })
        );
        panel.position.y = 3.2;
        b.add(panel);
        for (const px of [-4.2, 4.2]) {
          const post = new THREE.Mesh(new THREE.BoxGeometry(0.32, 3.2, 0.32), postMat);
          post.position.set(px, 1.6, 0);
          b.add(post);
        }
        b.position.set(
          TRACK.x[i] + TRACK.nx[i] * sgn * (WALL + 3.4),
          0,
          TRACK.z[i] + TRACK.nz[i] * sgn * (WALL + 3.4)
        );
        b.rotation.y = TRACK.h[i] + (sgn > 0 ? -Math.PI * 0.5 : Math.PI * 0.5);
        grp.add(b);
      }

      // Stadium Floodlight Pylons
      if (i % 68 === 24) {
        const sgn = i % 136 === 24 ? 1 : -1;
        const pylon = new THREE.Group();
        const mast = new THREE.Mesh(
          new THREE.CylinderGeometry(0.28, 0.45, 22, 8),
          postMat
        );
        mast.position.y = 11;
        pylon.add(mast);

        const head = new THREE.Mesh(new THREE.BoxGeometry(6.4, 2.1, 0.7), postMat);
        head.position.set(0, 22, 0.3);
        head.rotation.x = 0.25;
        pylon.add(head);

        const bank = new THREE.Mesh(new THREE.PlaneGeometry(5.8, 1.65), floodBulbMat);
        bank.position.set(0, 22, 0.68);
        bank.rotation.x = 0.25;
        pylon.add(bank);

        pylon.position.set(
          TRACK.x[i] + TRACK.nx[i] * sgn * (WALL + 9.5),
          0,
          TRACK.z[i] + TRACK.nz[i] * sgn * (WALL + 9.5)
        );
        pylon.rotation.y = TRACK.h[i] + (sgn > 0 ? -Math.PI * 0.5 : Math.PI * 0.5);
        grp.add(pylon);
      }

      // Corner Tire Wall Stacks
      if (TRACK.ka[i] > 0.0085 && i % 4 === 0) {
        const turnDir = Math.sign(
          TRACK.h[(i + 2) % N] - TRACK.h[(i + N - 2) % N]
        );
        const outerSgn = turnDir >= 0 ? -1 : 1;
        const tire = new THREE.Mesh(
          new THREE.CylinderGeometry(0.65, 0.65, 1.15, 10),
          new THREE.MeshStandardMaterial({
            color: (i >> 2) & 1 ? 0xd92626 : 0xf1f5f9,
            roughness: 0.75,
          })
        );
        tire.position.set(
          TRACK.x[i] + TRACK.nx[i] * outerSgn * (WALL + 0.1),
          0.6,
          TRACK.z[i] + TRACK.nz[i] * outerSgn * (WALL + 0.1)
        );
        grp.add(tire);
      }

      // FIA 150m / 100m / 50m Braking Zone Distance Boards ahead of major corners
      if (i > 25 && i % 16 === 0 && TRACK.ka[(i + 18) % N] > 0.011 && TRACK.ka[i] < 0.005) {
        const turnDir = Math.sign(
          TRACK.h[(i + 20) % N] - TRACK.h[(i + 14) % N]
        );
        const outerSgn = turnDir >= 0 ? -1 : 1;
        const boardIdx = ((i / 16) | 0) % this.textures.brakeBoards.length;
        const board = new THREE.Mesh(
          new THREE.BoxGeometry(2.2, 1.15, 0.16),
          new THREE.MeshStandardMaterial({
            map: this.textures.brakeBoards[boardIdx],
            roughness: 0.4,
            metalness: 0.1,
          })
        );
        board.position.set(
          TRACK.x[i] + TRACK.nx[i] * outerSgn * (WALL - 0.6),
          1.95,
          TRACK.z[i] + TRACK.nz[i] * outerSgn * (WALL - 0.6)
        );
        board.rotation.y = TRACK.h[i];
        grp.add(board);
      }
    }

    // Back-straight Overhead Alpine Motorsport Sponsor Bridge (Chunk 7)
    if (ci === 7) {
      const bIdx = Math.min(N - 1, i0 + Math.floor(count * 0.5));
      const bridge = new THREE.Group();
      const darkSteel = new THREE.MeshStandardMaterial({
        color: 0x162030,
        roughness: 0.36,
        metalness: 0.8,
      });
      const neonCyan = new THREE.MeshStandardMaterial({
        color: 0x38d2ff,
        emissive: 0x22b8ff,
        emissiveIntensity: 2.2,
        roughness: 0.2,
      });
      for (const sx of [-HW - 1.4, HW + 1.4]) {
        const leg = new THREE.Mesh(new THREE.BoxGeometry(1.1, 8.8, 1.4), darkSteel);
        leg.position.set(sx, 4.4, 0);
        bridge.add(leg);
        const trim = new THREE.Mesh(new THREE.BoxGeometry(1.18, 0.25, 1.48), neonCyan);
        trim.position.set(sx, 6.2, 0);
        bridge.add(trim);
      }
      const spanW = (HW + 1.6) * 2;
      const deck = new THREE.Mesh(new THREE.BoxGeometry(spanW, 2.2, 2.6), darkSteel);
      deck.position.set(0, 8.2, 0);
      bridge.add(deck);
      const bannerFace = new THREE.Mesh(
        new THREE.PlaneGeometry(spanW - 1.5, 1.7),
        new THREE.MeshBasicMaterial({
          map: this.textures.sponsors[0],
          side: THREE.DoubleSide,
        })
      );
      bannerFace.position.set(0, 8.2, -1.32);
      bridge.add(bannerFace);
      const bannerBack = bannerFace.clone();
      bannerBack.position.set(0, 8.2, 1.32);
      bridge.add(bannerBack);

      bridge.position.set(TRACK.x[bIdx], 0, TRACK.z[bIdx]);
      bridge.rotation.y = TRACK.h[bIdx];
      grp.add(bridge);
    }

    // 7. Chunk 0 Hero Circuit Landmarks: Start/Finish Grid + Pro Truss Gantry + Control Tower + Pit Garages
    if (ci === 0) {
      // Crisp motorsport-scale checkered start/finish strip across track
      const sfLine = new THREE.Mesh(
        new THREE.PlaneGeometry(HW * 2 - 0.5, 2.0),
        new THREE.MeshBasicMaterial({
          map: this.textures.startGrid,
          transparent: true,
          polygonOffset: true,
          polygonOffsetFactor: -1,
          polygonOffsetUnits: -1,
        })
      );
      sfLine.rotation.x = -Math.PI * 0.5;
      sfLine.position.set(TRACK.x[0], 0.135, TRACK.z[0]);
      sfLine.rotation.z = -TRACK.h[0];
      grp.add(sfLine);

      // Painted starting grid brackets
      const gridMat = new THREE.MeshBasicMaterial({
        color: 0xf4f7fb,
        transparent: true,
        opacity: 0.72,
      });
      for (const slot of [
        { idx: (N - 1) % N, lat: -3.2 },
        { idx: (N - 3) % N, lat: 3.2 },
        { idx: (N - 5) % N, lat: -3.2 },
        { idx: (N - 7) % N, lat: 3.2 },
      ]) {
        const box = new THREE.Mesh(new THREE.PlaneGeometry(2.6, 0.25), gridMat);
        box.rotation.x = -Math.PI * 0.5;
        box.rotation.z = -TRACK.h[slot.idx];
        box.position.set(
          TRACK.x[slot.idx] + TRACK.nx[slot.idx] * slot.lat,
          0.132,
          TRACK.z[slot.idx] + TRACK.nz[slot.idx] * slot.lat
        );
        grp.add(box);
      }

      // Start/Finish Steel Truss Gantry with Live Signal Pods
      const gantry = new THREE.Group();
      const steelMat = new THREE.MeshStandardMaterial({
        color: 0x1b2432,
        roughness: 0.38,
        metalness: 0.78,
      });
      const pillarH = 10.2;
      for (const sx of [-HW - 1.35, HW + 1.35]) {
        const tower = new THREE.Mesh(
          new THREE.BoxGeometry(1.15, pillarH, 1.35),
          steelMat
        );
        tower.position.set(sx, pillarH * 0.5, 0);
        gantry.add(tower);

        const accentBand = new THREE.Mesh(
          new THREE.BoxGeometry(1.22, 0.45, 1.42),
          new THREE.MeshStandardMaterial({ color: 0xff6d1f, roughness: 0.3 })
        );
        accentBand.position.set(sx, 7.6, 0);
        gantry.add(accentBand);
      }

      const spanW = (HW + 1.65) * 2;
      const beam = new THREE.Mesh(new THREE.BoxGeometry(spanW, 2.3, 1.3), steelMat);
      beam.position.set(0, 9.15, 0);
      gantry.add(beam);

      const bannerMat = new THREE.MeshStandardMaterial({
        map: this.textures.gantryBanner,
        roughness: 0.42,
        metalness: 0.15,
      });
      for (const zf of [0.68, -0.68]) {
        const face = new THREE.Mesh(new THREE.PlaneGeometry(spanW - 1.4, 2.0), bannerMat);
        face.position.set(0, 9.15, zf);
        if (zf < 0) face.rotation.y = Math.PI;
        gantry.add(face);
      }

      const lightsHousing = new THREE.Mesh(
        new THREE.BoxGeometry(7.2, 1.4, 0.65),
        steelMat
      );
      lightsHousing.position.set(0, 7.35, 0);
      gantry.add(lightsHousing);

      const lightsFace = new THREE.Mesh(
        new THREE.PlaneGeometry(6.8, 1.25),
        new THREE.MeshBasicMaterial({ map: this.textures.gantryLightsTex })
      );
      lightsFace.position.set(0, 7.35, -0.34);
      lightsFace.rotation.y = Math.PI;
      gantry.add(lightsFace);

      const lightsFaceFront = new THREE.Mesh(
        new THREE.PlaneGeometry(6.8, 1.25),
        new THREE.MeshBasicMaterial({ map: this.textures.gantryLightsTex })
      );
      lightsFaceFront.position.set(0, 7.35, 0.34);
      gantry.add(lightsFaceFront);

      gantry.position.set(TRACK.x[0], 0, TRACK.z[0]);
      gantry.rotation.y = TRACK.h[0];
      grp.add(gantry);

      // Race Control & Timing Tower beside the start straight
      const towerGrp = new THREE.Group();
      const tShaft = new THREE.Mesh(
        new THREE.BoxGeometry(5.5, 22, 5.5),
        new THREE.MeshStandardMaterial({ color: 0x202938, roughness: 0.55, metalness: 0.45 })
      );
      tShaft.position.y = 11;
      towerGrp.add(tShaft);

      const tDeck = new THREE.Mesh(
        new THREE.CylinderGeometry(5.8, 4.8, 4.4, 8),
        new THREE.MeshPhysicalMaterial({
          color: 0x162436,
          roughness: 0.08,
          metalness: 0.3,
          clearcoat: 1.0,
        })
      );
      tDeck.position.y = 22.8;
      towerGrp.add(tDeck);

      const tCap = new THREE.Mesh(
        new THREE.CylinderGeometry(6.2, 6.2, 0.8, 8),
        new THREE.MeshStandardMaterial({ color: 0xff6d1f, roughness: 0.35 })
      );
      tCap.position.y = 25.3;
      towerGrp.add(tCap);

      const tIdx = 8;
      towerGrp.position.set(
        TRACK.x[tIdx] - TRACK.nx[tIdx] * (WALL + 14),
        0,
        TRACK.z[tIdx] - TRACK.nz[tIdx] * (WALL + 14)
      );
      grp.add(towerGrp);

      // Pit Lane Garage Complex along main straight
      const paddock = new THREE.Mesh(
        new THREE.BoxGeometry(36, 4.8, 9),
        new THREE.MeshStandardMaterial({ color: 0x263042, roughness: 0.6, metalness: 0.35 })
      );
      const pIdx = 22;
      paddock.position.set(
        TRACK.x[pIdx] - TRACK.nx[pIdx] * (WALL + 13),
        2.4,
        TRACK.z[pIdx] - TRACK.nz[pIdx] * (WALL + 13)
      );
      paddock.rotation.y = TRACK.h[pIdx] + Math.PI * 0.5;
      grp.add(paddock);
    }

    this.trackGroup.add(grp);
  }

  private getCarTexPack() {
    return {
      contactShadow: this.textures.contactShadow,
      nitroGlow: this.textures.nitroGlow,
      headlightGlow: this.textures.headlightGlow,
      headlightBeam: this.textures.headlightBeam,
      brakeGlow: this.textures.brakeGlow,
    };
  }

  private applyCarLighting(vis: CarVisual, isShowroom: boolean) {
    const isNight = this.timeOfDay === 'night';
    const isSunset = this.timeOfDay === 'sunset';
    if (isShowroom) {
      vis.headlightGlowMat.opacity = isNight ? 0.72 : isSunset ? 0.26 : 0.0;
      vis.headlightBeamMat.opacity = isNight ? 0.58 : isSunset ? 0.14 : 0.0;
      vis.brakeGlowMat.opacity = isNight ? 0.42 : isSunset ? 0.24 : 0.0;
    } else {
      vis.headlightGlowMat.opacity = isNight ? 0.82 : isSunset ? 0.52 : 0.14;
      vis.headlightBeamMat.opacity = isNight ? 0.66 : isSunset ? 0.22 : 0.0;
    }
  }

  private rebuildShowroomCar() {
    if (this.showroomVis) {
      this.carsGroup.remove(this.showroomVis.root);
      this.showroomVis = null;
    }
    this.clearVisuals();
    const v = CAR_VARIANTS[this.selectedCarId];
    this.showroomVis = buildCarVisual(
      v,
      this.getCarTexPack(),
      !this.isSoftwareGl,
      this.isSoftwareGl
    );
    // Park hero car cleanly ahead of gantry on open sunlit asphalt (idx = 6)
    const sIdx = 6;
    this.showroomVis.root.position.set(TRACK.x[sIdx], 0.12, TRACK.z[sIdx]);
    this.showroomVis.root.rotation.y = TRACK.h[sIdx];
    this.applyCarLighting(this.showroomVis, true);
    this.carsGroup.add(this.showroomVis.root);
  }

  private clearVisuals() {
    for (const vis of this.visuals) {
      this.carsGroup.remove(vis.root);
    }
    this.visuals = [];
  }

  private setupRaceGrid() {
    if (this.showroomVis) {
      this.carsGroup.remove(this.showroomVis.root);
      this.showroomVis = null;
    }
    this.clearVisuals();
    this.particles.clear();
    this.skidPositions.fill(0);
    this.skidGeo.attributes.position.needsUpdate = true;

    const rivals = CAR_IDS.filter((id) => id !== this.selectedCarId).slice(0, 3);
    const lineup: CarVariantId[] = [this.selectedCarId, ...rivals];
    this.playerIndex = 0;

    const slots: Array<{ idx: number; lat: number }> = [
      { idx: (TRACK.N - 1) % TRACK.N, lat: -3.2 },
      { idx: (TRACK.N - 3) % TRACK.N, lat: 3.2 },
      { idx: (TRACK.N - 5) % TRACK.N, lat: -3.2 },
      { idx: (TRACK.N - 7) % TRACK.N, lat: 3.2 },
    ];

    const carTex = this.getCarTexPack();
    this.cars = lineup.map((id, i) => {
      const st = createCarState(id);
      st.lap = -1;
      st.baseLane = slots[i].lat;
      st.lane = slots[i].lat;
      placeCar(st, slots[i].idx, slots[i].lat);
      const vis = buildCarVisual(
        st.c,
        carTex,
        !this.isSoftwareGl,
        this.isSoftwareGl
      );
      vis.root.position.set(st.x, 0.12, st.z);
      vis.root.rotation.y = st.h;
      this.applyCarLighting(vis, false);
      this.carsGroup.add(vis.root);
      this.visuals.push(vis);
      return st;
    });

    const p = this.cars[this.playerIndex];
    this.camX = p.x - Math.sin(p.h) * 8;
    this.camY = 3.6;
    this.camZ = p.z - Math.cos(p.h) * 8;
    this.lookX = p.x;
    this.lookY = 1.5;
    this.lookZ = p.z;
    this.camera.position.set(this.camX, this.camY, this.camZ);
    this.camera.lookAt(this.lookX, this.lookY, this.lookZ);

    this.raceTimeSec = 0;
    this.countdownSec = 3.2;
    this.lastCountdownBeep = 4;
    this.prevGantryLit = -1;
    this.shakeTrauma = 0;
    this.bannerText = '';
    this.bannerTimer = 0;
    this.prevPlayerGear = 1;
    this.prevDriftBoost = false;
    paintGantryLights(
      this.textures.gantryLightsCanvas,
      this.textures.gantryLightsTex,
      3.2,
      false
    );
  }

  public setTimeOfDay(tod: TimeOfDay) {
    this.timeOfDay = tod;
    this.applyTimeOfDay(tod);
    this.emitHud();
    if (this.isSoftwareGl && this.mode === 'menu') this.renderMenuOnce();
  }

  private applyTimeOfDay(tod: TimeOfDay) {
    const isSunset = tod === 'sunset';
    const isNight = tod === 'night';
    this.mountainCylMat.map = isSunset
      ? this.textures.mountainSunset
      : this.textures.mountainDay;
    this.mountainCylMat.color.setHex(
      isNight ? 0x455c82 : isSunset ? 0xffcaa4 : 0xffffff
    );
    this.mountainCylMat.needsUpdate = true;

    if (isNight) {
      this.scene.fog = new THREE.Fog(0x0b152a, 280, 1800);
      this.skyMat.uniforms.uTop.value.setHex(0x050918);
      this.skyMat.uniforms.uMid.value.setHex(0x0e1d3d);
      this.skyMat.uniforms.uHor.value.setHex(0x1b3058);
      this.skyMat.uniforms.uSunDir.value.set(-0.45, 0.42, 0.78).normalize();
      this.skyMat.uniforms.uSunCol.value.setHex(0xb8d8ff);
      this.skyMat.uniforms.uCloudCol.value.setHex(0x283e66);
      this.skyMat.uniforms.uStarIntensity.value = 1.0;
      this.skylineCylMat.color.setHex(0x324668);

      // Moonlit floodlit night stadium balance (cars stay crystal clear & sculptural)
      this.hemiLight.color.setHex(0x6e9ce8);
      this.hemiLight.groundColor.setHex(0x141a28);
      this.hemiLight.intensity = 0.78;
      this.sunLight.color.setHex(0xcce2ff);
      this.sunLight.intensity = 1.65;
      this.sunLight.position.set(-140, 180, 190);
      this.fillLight.color.setHex(0xff9b54);
      this.fillLight.intensity = 0.55;
      this.sunDiscMat.color.setHex(0xe8f4ff);
      this.sunHaloMat.color.setHex(0x7cb8ff);
      this.renderer.toneMappingExposure = 1.02;
      this.scene.environment = this.envTexNight;
    } else if (isSunset) {
      this.scene.fog = new THREE.Fog(0xe29268, 420, 2200);
      this.skyMat.uniforms.uTop.value.setHex(0x1f2854);
      this.skyMat.uniforms.uMid.value.setHex(0xc46960);
      this.skyMat.uniforms.uHor.value.setHex(0xf6b274);
      this.skyMat.uniforms.uSunDir.value.set(0.65, 0.22, -0.72).normalize();
      this.skyMat.uniforms.uSunCol.value.setHex(0xffc985);
      this.skyMat.uniforms.uCloudCol.value.setHex(0xffc59a);
      this.skyMat.uniforms.uStarIntensity.value = 0.12;
      this.skylineCylMat.color.setHex(0x6d505c);

      this.hemiLight.color.setHex(0xffc99e);
      this.hemiLight.groundColor.setHex(0x362822);
      this.hemiLight.intensity = 0.72;
      this.sunLight.color.setHex(0xffb474);
      this.sunLight.intensity = 2.25;
      this.sunLight.position.set(210, 95, -230);
      this.fillLight.color.setHex(0x889cf0);
      this.fillLight.intensity = 0.48;
      this.sunDiscMat.color.setHex(0xffd7a1);
      this.sunHaloMat.color.setHex(0xff9b54);
      this.renderer.toneMappingExposure = 0.98;
      this.scene.environment = this.envTexSunset;
    } else {
      this.scene.fog = new THREE.Fog(0xbcdaf6, 460, 2400);
      this.skyMat.uniforms.uTop.value.setHex(0x286bc8);
      this.skyMat.uniforms.uMid.value.setHex(0x7dbdf2);
      this.skyMat.uniforms.uHor.value.setHex(0xd2e7f8);
      this.skyMat.uniforms.uSunDir.value.set(0.45, 0.56, 0.4).normalize();
      this.skyMat.uniforms.uSunCol.value.setHex(0xfff6dc);
      this.skyMat.uniforms.uCloudCol.value.setHex(0xffffff);
      this.skyMat.uniforms.uStarIntensity.value = 0.0;
      this.skylineCylMat.color.setHex(0xd8e5f4);

      this.hemiLight.color.setHex(0xdcf0ff);
      this.hemiLight.groundColor.setHex(0x3f4e32);
      this.hemiLight.intensity = 0.68;
      this.sunLight.color.setHex(0xfff7ea);
      this.sunLight.intensity = 2.05;
      this.sunLight.position.set(160, 220, 120);
      this.fillLight.color.setHex(0x8ec4ff);
      this.fillLight.intensity = 0.42;
      this.sunDiscMat.color.setHex(0xffffff);
      this.sunHaloMat.color.setHex(0xffe4b5);
      this.renderer.toneMappingExposure = 0.94;
      this.scene.environment = this.envTexDay;
    }

    if (this.showroomVis) {
      this.applyCarLighting(this.showroomVis, true);
    }
    for (const vis of this.visuals) {
      this.applyCarLighting(vis, false);
    }

    const sunDir = this.skyMat.uniforms.uSunDir.value as THREE.Vector3;
    this.sunDiscMesh.position.copy(sunDir).multiplyScalar(2200);
    this.sunDiscMesh.lookAt(0, 0, 0);
    this.sunHaloSprite.position.copy(sunDir).multiplyScalar(2180);
  }

  public setDifficulty(d: Difficulty) {
    this.difficulty = d;
    this.emitHud();
  }

  public selectCar(id: CarVariantId) {
    if (this.selectedCarId === id) return;
    this.selectedCarId = id;
    if (this.mode === 'menu') {
      this.rebuildShowroomCar();
      if (this.isSoftwareGl) this.renderMenuOnce();
    }
    this.emitHud();
  }

  public cycleCamera() {
    this.cameraMode = ((this.cameraMode + 1) % 4) as CameraMode;
    this.emitHud();
  }

  public toggleMute() {
    this.muted = !this.muted;
    this.audio.setMuted(this.muted);
    this.emitHud();
  }

  public setTouchControl(key: keyof ControlInput, value: number) {
    this.audio.unlock();
    this.touchState[key] = value;
  }

  private wakeLoopNow() {
    if (!this.isSoftwareGl || this.disposed) return;
    if (this.paceTimer !== null) {
      clearTimeout(this.paceTimer);
      this.paceTimer = null;
    }
    if (this.rafId !== null) {
      cancelAnimationFrame(this.rafId);
      this.rafId = null;
    }
    this.prevMs = performance.now();
    this.rafId = requestAnimationFrame(this.frameLoop);
  }

  public startRace() {
    this.audio.unlock();
    this.setupRaceGrid();
    if (this.chunkIndex < NCH) {
      this.mode = 'loading';
    } else {
      this.mode = 'count';
    }
    this.emitHud();
    this.wakeLoopNow();
  }

  public togglePause() {
    if (this.mode === 'race') {
      this.mode = 'pause';
      this.audio.silence();
      this.emitHud();
    } else if (this.mode === 'pause') {
      this.mode = 'race';
      this.emitHud();
      this.wakeLoopNow();
    }
  }

  public restartRace() {
    this.startRace();
  }

  public returnToGarage() {
    this.mode = 'menu';
    this.audio.silence();
    this.particles.clear();
    this.rebuildShowroomCar();
    this.emitHud();
    if (this.isSoftwareGl) this.renderMenuOnce();
  }

  public recoverPlayer() {
    if (this.mode === 'race' && this.cars[this.playerIndex]) {
      recoverCar(this.cars[this.playerIndex]);
    }
  }

  private getBodyState(): BodyState {
    if (this.mode === 'menu') return 'title';
    if (this.mode === 'pause') return 'paused';
    if (this.mode === 'done') return 'gameover';
    return 'playing';
  }

  private getPlayerInput(): ControlInput {
    const k = this.keys;
    const st = clamp(
      (k['KeyA'] || k['ArrowLeft'] ? 1 : 0) -
        (k['KeyD'] || k['ArrowRight'] ? 1 : 0) +
        this.touchState.st,
      -1,
      1
    );
    const th =
      k['KeyW'] || k['ArrowUp'] || this.touchState.th > 0 ? 1 : 0;
    const br =
      k['KeyS'] || k['ArrowDown'] || this.touchState.br > 0 ? 1 : 0;
    const hb = k['Space'] || this.touchState.hb > 0 ? 1 : 0;
    const nt =
      k['ShiftLeft'] ||
      k['ShiftRight'] ||
      k['KeyN'] ||
      this.touchState.nt > 0
        ? 1
        : 0;
    return { st, th, br, hb, nt };
  }

  private addSkidSegment(c: CarState) {
    const offX = Math.cos(c.h) * 0.72;
    const offZ = -Math.sin(c.h) * 0.72;
    const rx = Math.sin(c.h) * 1.3;
    const rz = Math.cos(c.h) * 1.3;
    const fwX = Math.sin(c.h) * 0.6;
    const fwZ = Math.cos(c.h) * 0.6;

    for (const sgn of [-1, 1]) {
      const px = c.x - rx + offX * sgn;
      const pz = c.z - rz + offZ * sgn;
      const qx = px - fwX;
      const qz = pz - fwZ;
      const wX = Math.cos(c.h) * 0.14;
      const wZ = -Math.sin(c.h) * 0.14;

      const base = this.skidHead * 12;
      this.skidPositions[base] = px - wX;
      this.skidPositions[base + 1] = 0.135;
      this.skidPositions[base + 2] = pz - wZ;

      this.skidPositions[base + 3] = px + wX;
      this.skidPositions[base + 4] = 0.135;
      this.skidPositions[base + 5] = pz + wZ;

      this.skidPositions[base + 6] = qx + wX;
      this.skidPositions[base + 7] = 0.135;
      this.skidPositions[base + 8] = qz + wZ;

      this.skidPositions[base + 9] = qx - wX;
      this.skidPositions[base + 10] = 0.135;
      this.skidPositions[base + 11] = qz - wZ;

      const shade = c.off ? 0.28 : 0.08;
      for (let v = 0; v < 4; v++) {
        this.skidColors[base + v * 3] = shade;
        this.skidColors[base + v * 3 + 1] = c.off ? 0.22 : 0.08;
        this.skidColors[base + v * 3 + 2] = c.off ? 0.12 : 0.09;
      }
      this.skidHead = (this.skidHead + 1) % SKID_MAX;
    }
    this.skidGeo.attributes.position.needsUpdate = true;
    this.skidGeo.attributes.color.needsUpdate = true;
  }

  private stepSimulation(dt: number) {
    if (this.mode === 'count') {
      this.countdownSec -= dt;
      const ceilSec = Math.ceil(this.countdownSec);
      if (ceilSec < this.lastCountdownBeep && ceilSec >= 0) {
        this.lastCountdownBeep = ceilSec;
        this.audio.playCountdownTone(ceilSec === 0);
      }
      const litPods = Math.max(0, 4 - ceilSec);
      if (litPods !== this.prevGantryLit) {
        this.prevGantryLit = litPods;
        paintGantryLights(
          this.textures.gantryLightsCanvas,
          this.textures.gantryLightsTex,
          this.countdownSec,
          false
        );
      }
      if (this.countdownSec <= 0) {
        this.mode = 'race';
        paintGantryLights(
          this.textures.gantryLightsCanvas,
          this.textures.gantryLightsTex,
          0,
          true
        );
      }
    }

    if (this.mode !== 'race') return;

    if (this.bannerTimer > 0) {
      this.bannerTimer = Math.max(0, this.bannerTimer - dt);
      if (this.bannerTimer <= 0) this.bannerText = '';
    }

    this.raceTimeSec += dt;
    const diffSpec = DIFFICULTY_SPECS[this.difficulty];
    const pCar = this.cars[this.playerIndex];

    let maxSkidForAudio = 0;

    for (let i = 0; i < this.cars.length; i++) {
      const c = this.cars[i];
      const isPlayer = i === this.playerIndex;
      let u: ControlInput;
      if (isPlayer) {
        u = this.getPlayerInput();
      } else {
        const gapRatio = clamp((pCar.prog - c.prog) / 28, -1, 1);
        const boost = 1 + gapRatio * 0.075;
        u = computeAiControl(c, this.cars, diffSpec.mult, boost, dt);
      }

      const drafting = isInSlipstream(c, this.cars);
      driveCar(c, u, dt, drafting);
      const lapEvent = locateOnTrack(c);
      if (lapEvent === 1) {
        if (c.lap > 0) {
          const lapDuration = this.raceTimeSec - c.ls;
          c.last = lapDuration;
          const isNewPersonalBest = !c.best || lapDuration < c.best;
          if (isNewPersonalBest) c.best = lapDuration;

          if (isPlayer) {
            const isCircuitRecord =
              !this.recordLapSec || lapDuration < this.recordLapSec;
            if (isCircuitRecord) {
              this.recordLapSec = lapDuration;
              try {
                window.localStorage.setItem(
                  'apex_duel_best_lap_sec',
                  lapDuration.toFixed(3)
                );
              } catch {
                // ignore storage errors
              }
            }
            if (c.lap < LAPS) {
              this.audio.playLapChime(isCircuitRecord || isNewPersonalBest);
              this.showBanner(
                isCircuitRecord
                  ? `NEW CIRCUIT RECORD · ${formatRaceTime(lapDuration)}`
                  : isNewPersonalBest
                    ? `BEST LAP · ${formatRaceTime(lapDuration)}`
                    : `LAP ${c.lap + 1}/${LAPS} · ${formatRaceTime(lapDuration)}`,
                isCircuitRecord || isNewPersonalBest ? 'best' : 'info',
                2.6
              );
            }
          }
        }
        c.ls = this.raceTimeSec;
        if (c.lap >= LAPS && !c.fin) {
          c.fin = this.raceTimeSec;
        }
      }

      const wallImpact = applyWallBounce(c);
      if (wallImpact > 3) {
        this.particles.emitSparks(
          c.x,
          0.35,
          c.z,
          -TRACK.nx[c.idx] * Math.sign(c.lat),
          -TRACK.nz[c.idx] * Math.sign(c.lat),
          9
        );
        if (isPlayer) {
          this.shakeTrauma = Math.min(1, this.shakeTrauma + wallImpact * 0.035);
          this.audio.playImpact(wallImpact);
        }
      }

      // Compute drift slip for tyre marks, smoke particles & gravel spray
      const fx = Math.sin(c.h);
      const fz = Math.cos(c.h);
      const latSlip = Math.abs(c.vx * fz - c.vz * fx);
      const sliding = (latSlip > 4.2 || u.hb > 0 || c.off > 0) && Math.abs(c.s) > 9;
      if (isPlayer) {
        maxSkidForAudio = sliding ? Math.min(1, latSlip / 14 + (u.hb ? 0.5 : 0)) : 0;
        const driftBoostNow = c.driftBoostTimer > 0.1;
        if (driftBoostNow && !this.prevDriftBoost) {
          this.showBanner('DRIFT EXIT BOOST!', 'boost', 1.35);
          this.particles.emitBackfire(c.x - fx * 2.2, 0.25, c.z - fz * 2.2, -fx, -fz, true);
          this.audio.playGearShift(true);
        }
        this.prevDriftBoost = driftBoostNow;

        // High-speed / nitro / slipstream 3D wind streaks around player car
        if (Math.abs(c.s) > 54 || c.nitroActive || c.draftingActive) {
          this.speedStreakClock += dt;
          if (this.speedStreakClock > (c.nitroActive ? 0.035 : 0.07)) {
            this.speedStreakClock = 0;
            const sideSign = Math.random() > 0.5 ? 1 : -1;
            const sideDist = 1.6 + Math.random() * 2.4;
            const sx = c.x + fx * 3.2 + fz * sideSign * sideDist;
            const sz = c.z + fz * 3.2 - fx * sideSign * sideDist;
            this.particles.emitSpeedStreak(
              sx,
              0.55 + Math.random() * 1.15,
              sz,
              -fx,
              -fz,
              c.nitroActive
            );
          }
        }
      }

      if (sliding) {
        c.skidClock += dt;
        if (c.skidClock > 0.035) {
          c.skidClock = 0;
          this.addSkidSegment(c);
          this.particles.emitSmoke(
            c.x - fx * 1.4,
            0.14,
            c.z - fz * 1.4,
            c.vx,
            c.vz,
            c.off > 0
          );
        }
      }

      updateCarVisual(this.visuals[i], c, u.st, this.totalClockSec);
    }

    // Car-to-car collisions
    for (let i = 0; i < this.cars.length; i++) {
      for (let j = i + 1; j < this.cars.length; j++) {
        const a = this.cars[i];
        const b = this.cars[j];
        const impact = resolveCollision(a, b);
        if (impact > 2) {
          this.particles.emitSparks(
            (a.x + b.x) * 0.5,
            0.55,
            (a.z + b.z) * 0.5,
            (a.x - b.x) * 0.4,
            (a.z - b.z) * 0.4,
            12
          );
          if (i === this.playerIndex || j === this.playerIndex) {
            this.shakeTrauma = Math.min(1, this.shakeTrauma + impact * 0.045);
            this.audio.playImpact(impact);
          }
        }
      }
    }

    // Check race completion
    if (pCar.fin && this.mode === 'race') {
      this.mode = 'done';
      this.audio.playLapChime(getPlayerPosition(this.cars, pCar) === 1);
      this.audio.silence();
      this.emitHud();
    }

    // Audio telemetry + upshift exhaust pop
    const gearData = computeGearAndRpm(pCar.s, pCar.c.vmax);
    if (this.mode === 'race' && gearData.gear !== this.prevPlayerGear) {
      const upshift = gearData.gear > this.prevPlayerGear;
      this.prevPlayerGear = gearData.gear;
      if (Math.abs(pCar.s) > 12) {
        this.audio.playGearShift(upshift);
        const fx = Math.sin(pCar.h);
        const fz = Math.cos(pCar.h);
        this.particles.emitBackfire(
          pCar.x - fx * 2.25,
          0.25,
          pCar.z - fz * 2.25,
          -fx,
          -fz,
          pCar.nitroActive
        );
      }
    }
    this.audio.updateTelemetry(
      this.mode === 'race',
      false,
      Math.abs(pCar.s),
      gearData.rpmRatio,
      pCar.nitroActive,
      maxSkidForAudio,
      pCar.c.model,
      pCar.draftingActive
    );
  }

  private showBanner(text: string, tone: 'info' | 'best' | 'boost', durationSec: number) {
    this.bannerText = text;
    this.bannerTone = tone;
    this.bannerTimer = durationSec;
  }

  private updateCamera(dt: number) {
    if (this.mode === 'menu' && this.showroomVis) {
      if (!this.isDraggingShowroom) {
        this.showroomAngle += dt * 0.16;
      }
      const sIdx = 6;
      const cx = TRACK.x[sIdx];
      const cz = TRACK.z[sIdx];
      const r = 8.4;
      const camX = cx + Math.cos(this.showroomAngle) * r;
      const camZ = cz + Math.sin(this.showroomAngle) * r;
      this.camera.position.set(camX, 2.08, camZ);
      // Frame 100% of the hero car (front splitter to rear GT300 wing) cleanly in the right 58% of the screen
      const rightX = Math.sin(this.showroomAngle);
      const rightZ = -Math.cos(this.showroomAngle);
      this.camera.lookAt(cx - rightX * 1.18, 0.72, cz - rightZ * 1.18);
      if (Math.abs(this.camera.fov - 40) > 0.1) {
        this.camera.fov += (40 - this.camera.fov) * 0.25;
        this.camera.updateProjectionMatrix();
      }
      return;
    }

    const p = this.cars[this.playerIndex];
    if (!p) return;

    const fx = Math.sin(p.h);
    const fz = Math.cos(p.h);
    const absSpd = Math.abs(p.s);
    const lookingBack = !!(this.keys['KeyB'] || this.keys['KeyQ']);

    let tx: number;
    let ty: number;
    let tz: number;
    let lx: number;
    let ly: number;
    let lz: number;

    if (lookingBack) {
      tx = p.x + fx * 6.8;
      ty = 2.65;
      tz = p.z + fz * 6.8;
      lx = p.x - fx * 14;
      ly = 1.25;
      lz = p.z - fz * 14;
      this.camX = tx;
      this.camY = ty;
      this.camZ = tz;
      this.lookX = lx;
      this.lookY = ly;
      this.lookZ = lz;
    } else if (this.cameraMode === 3) {
      // Visceral road-hugging Bumper Cam
      tx = p.x + fx * 2.15;
      ty = 0.72;
      tz = p.z + fz * 2.15;
      lx = p.x + fx * 28;
      ly = 0.74;
      lz = p.z + fz * 28;
      this.camX = tx;
      this.camY = ty;
      this.camZ = tz;
      this.lookX = lx;
      this.lookY = ly;
      this.lookZ = lz;
    } else if (this.cameraMode === 2) {
      // Hood cam
      tx = p.x + fx * 1.1;
      ty = 1.62;
      tz = p.z + fz * 1.1;
      lx = p.x + fx * 22;
      ly = 1.45;
      lz = p.z + fz * 22;
      this.camX = tx;
      this.camY = ty;
      this.camZ = tz;
      this.lookX = lx;
      this.lookY = ly;
      this.lookZ = lz;
    } else {
      const dist =
        this.cameraMode === 1
          ? 4.6 + Math.min(absSpd, 75) * 0.025
          : 7.4 + Math.min(absSpd, 75) * 0.04;
      const height = this.cameraMode === 1 ? 2.45 : 3.35;
      tx = p.x - fx * dist;
      ty = height;
      tz = p.z - fz * dist;
      lx = p.x + fx * 7.5;
      ly = 1.35;
      lz = p.z + fz * 7.5;

      const posLerp = 1 - Math.exp(-9.5 * dt);
      const lookLerp = 1 - Math.exp(-13 * dt);
      this.camX += (tx - this.camX) * posLerp;
      this.camY += (ty - this.camY) * posLerp;
      this.camZ += (tz - this.camZ) * posLerp;
      this.lookX += (lx - this.lookX) * lookLerp;
      this.lookY += (ly - this.lookY) * lookLerp;
      this.lookZ += (lz - this.lookZ) * lookLerp;
    }

    // Subtle trauma camera shake
    let shakeX = 0;
    let shakeY = 0;
    if (this.shakeTrauma > 0.005) {
      const mag = this.shakeTrauma * this.shakeTrauma * 0.35;
      shakeX = (Math.random() - 0.5) * mag;
      shakeY = (Math.random() - 0.5) * mag;
      this.shakeTrauma = Math.max(0, this.shakeTrauma - dt * 2.4);
    }

    this.camera.position.set(this.camX + shakeX, this.camY + shakeY, this.camZ);
    this.camera.lookAt(this.lookX, this.lookY, this.lookZ);

    // Dynamic speed + nitro + slipstream FOV punch
    const baseFov = this.cameraMode === 3 ? 68 : 62;
    const targetFov =
      baseFov +
      clamp(absSpd / 85, 0, 1) * 7.5 +
      (p.nitroActive ? 5.5 : 0) +
      (p.draftingActive ? 2.2 : 0);
    if (Math.abs(this.camera.fov - targetFov) > 0.08) {
      this.camera.fov += (targetFov - this.camera.fov) * 0.14;
      this.camera.updateProjectionMatrix();
    }

    // Follow sun shadow frustum to player car
    if (!this.isSoftwareGl) {
      const sunOffset =
        this.timeOfDay === 'sunset' ? [140, 60, -160] : [110, 160, 90];
      this.sunLight.position.set(
        p.x + sunOffset[0],
        sunOffset[1],
        p.z + sunOffset[2]
      );
      this.sunLight.target.position.set(p.x, 0, p.z);
    }
  }

  private drawMinimap() {
    const g = this.minimapCtx;
    if (!g || this.mode === 'menu' || !this.cars.length) return;
    const w = this.minimapCanvas.width;
    const h = this.minimapCanvas.height;
    g.clearRect(0, 0, w, h);

    // Compute bounds once cleanly (track coords roughly -330..650 x, -60..400 z)
    const minX = -340;
    const maxX = 660;
    const minZ = -65;
    const maxZ = 405;
    const pad = 12;
    const sx = (w - pad * 2) / (maxX - minX);
    const sy = (h - pad * 2) / (maxZ - minZ);
    const scale = Math.min(sx, sy);
    const ox = (w - (maxX - minX) * scale) * 0.5;
    const oy = (h - (maxZ - minZ) * scale) * 0.5;
    const tx = (x: number) => ox + (x - minX) * scale;
    const ty = (z: number) => oy + (z - minZ) * scale;

    // Circuit loop
    g.beginPath();
    for (let i = 0; i < TRACK.N; i += 3) {
      const px = tx(TRACK.x[i]);
      const py = ty(TRACK.z[i]);
      if (i === 0) g.moveTo(px, py);
      else g.lineTo(px, py);
    }
    g.closePath();
    g.strokeStyle = 'rgba(255,255,255,0.22)';
    g.lineWidth = 5;
    g.stroke();

    // Start/finish tick
    g.strokeStyle = '#ff6d1f';
    g.lineWidth = 2.5;
    g.beginPath();
    g.moveTo(tx(TRACK.x[0] - TRACK.nx[0] * 14), ty(TRACK.z[0] - TRACK.nz[0] * 14));
    g.lineTo(tx(TRACK.x[0] + TRACK.nx[0] * 14), ty(TRACK.z[0] + TRACK.nz[0] * 14));
    g.stroke();

    // Cars
    for (let i = 0; i < this.cars.length; i++) {
      const c = this.cars[i];
      const isP = i === this.playerIndex;
      g.beginPath();
      g.arc(tx(c.x), ty(c.z), isP ? 4.4 : 3.1, 0, Math.PI * 2);
      g.fillStyle = isP ? '#38d2ff' : c.c.sw;
      g.fill();
      if (isP) {
        g.strokeStyle = '#ffffff';
        g.lineWidth = 1.5;
        g.stroke();
      }
    }
  }

  private emitHud() {
    const p = this.cars[this.playerIndex];
    const absSpeed = p ? Math.abs(p.s) : 0;
    const gearData = p
      ? computeGearAndRpm(p.s, p.c.vmax)
      : { gear: 1, rpmRatio: 0.18 };
    const standings = this.cars.length
      ? getStandings(this.cars).map((c) => ({
          name: c.c.name,
          swatch: c.c.sw,
          isPlayer: c === p,
          finishTimeSec: c.fin,
          topSpeedKmh: c.topSpeedKmh,
        }))
      : [];

    this.onHudUpdate({
      mode: this.mode,
      bodyState: this.getBodyState(),
      timeOfDay: this.timeOfDay,
      difficulty: this.difficulty,
      selectedCar: this.selectedCarId,
      cameraMode: this.cameraMode,
      muted: this.muted,
      lap: p ? clamp(p.lap + 1, 1, LAPS) : 1,
      totalLaps: LAPS,
      position: p ? getPlayerPosition(this.cars, p) : 1,
      totalCars: this.cars.length || 4,
      raceTimeSec: this.raceTimeSec,
      bestLapSec: p ? p.best : 0,
      recordLapSec: this.recordLapSec,
      countdownSec: this.countdownSec,
      offTrack: p ? p.off > 0 : false,
      wrongWay: p ? isWrongWay(p) : false,
      drafting: p ? p.draftingActive : false,
      drifting: p ? p.driftingActive : false,
      driftScore: p ? p.driftScore : 0,
      upcomingTurn: p && this.mode === 'race' ? getUpcomingTurn(p.idx) : 'none',
      bannerText: this.bannerText,
      bannerTone: this.bannerTone,
      speedKmh: Math.round(absSpeed * 3.6),
      gear: gearData.gear,
      rpmRatio: gearData.rpmRatio,
      nitroRatio: p ? p.nitro / 100 : 1,
      nitroActive: p ? p.nitroActive : false,
      loadProgress: this.chunkIndex / NCH,
      loadText: `Building circuit sectors ${this.chunkIndex}/${NCH}…`,
      standings,
      playerTopSpeedKmh: p ? p.topSpeedKmh : 0,
      playerFinishTimeSec: p ? p.fin : 0,
      playerBestLapSec: p ? p.best : 0,
      playerDriftTotal: p ? p.driftScore : 0,
    });
  }

  private renderMenuOnce() {
    if (this.disposed) return;
    this.updateCamera(0.016);
    this.renderer.render(this.scene, this.camera);
  }

  private scheduleNextFrame() {
    if (this.disposed) return;
    if (this.isSoftwareGl) {
      // Yield generously on CPU SwiftShader so Chromium compositor & interactions stay instant,
      // while hardware GPUs run uncapped at full 60-120fps requestAnimationFrame.
      const delay =
        this.mode === 'menu' || this.mode === 'pause' || this.mode === 'done'
          ? 2400
          : this.mode === 'loading'
            ? 80
            : 280;
      this.paceTimer = window.setTimeout(() => {
        if (!this.disposed) {
          this.rafId = requestAnimationFrame(this.frameLoop);
        }
      }, delay);
    } else {
      this.rafId = requestAnimationFrame(this.frameLoop);
    }
  }

  private frameLoop = (nowMs: number) => {
    if (this.disposed) return;

    const dt = clampDt((nowMs - this.prevMs) / 1000);
    this.prevMs = nowMs;
    this.totalClockSec += dt;

    // Update sky time + drifting sky blimp
    this.skyMat.uniforms.uTime.value = this.totalClockSec;
    const blimpAng = this.totalClockSec * 0.045;
    const bx = 150 + Math.cos(blimpAng) * 340;
    const bz = 160 + Math.sin(blimpAng) * 210;
    this.blimpGroup.position.set(bx, 145 + Math.sin(blimpAng * 2) * 4, bz);
    this.blimpGroup.rotation.y = -blimpAng;

    if (this.mode === 'loading') {
      const batch = this.isSoftwareGl ? 2 : 3;
      for (let b = 0; b < batch && this.chunkIndex < NCH; b++) {
        this.buildChunk(this.chunkIndex++);
      }
      if (this.chunkIndex >= NCH) {
        this.mode = 'count';
        this.lastCountdownBeep = 4;
      }
      this.emitHud();
    } else if (this.mode === 'count') {
      this.stepSimulation(dt);
      const p = this.cars[this.playerIndex];
      if (p) {
        const gd = computeGearAndRpm(p.s, p.c.vmax);
        this.audio.updateTelemetry(true, true, 0, gd.rpmRatio, false, 0);
      }
      this.drawMinimap();
      this.emitHud();
    } else if (this.mode === 'race') {
      this.accumSec = Math.min(this.accumSec + dt, 0.12);
      const step = 1 / 60;
      while (this.accumSec >= step) {
        this.stepSimulation(step);
        this.accumSec -= step;
      }
      this.particles.update(dt);
      this.drawMinimap();
      this.emitHud();
    }

    this.updateCamera(dt);
    this.renderer.render(this.scene, this.camera);
    this.scheduleNextFrame();
  };

  private handleResize = () => {
    const w = this.container.clientWidth || window.innerWidth || 1280;
    const h = this.container.clientHeight || window.innerHeight || 720;
    this.camera.aspect = w / h;
    this.camera.updateProjectionMatrix();
    this.renderer.setSize(w, h);
    if (this.isSoftwareGl && this.mode === 'menu') {
      this.renderMenuOnce();
    }
  };

  private handleKeyDown = (e: KeyboardEvent) => {
    this.audio.unlock();
    this.keys[e.code] = true;

    if (this.mode === 'menu' && (e.code === 'Enter' || e.code === 'Space')) {
      e.preventDefault();
      this.startRace();
      return;
    }

    if (e.code === 'KeyP' || e.code === 'Escape') {
      if (this.mode === 'race' || this.mode === 'pause') {
        e.preventDefault();
        this.togglePause();
      }
    } else if (e.code === 'KeyC' && !e.repeat) {
      if (this.mode === 'race' || this.mode === 'count') {
        this.cycleCamera();
      }
    } else if (e.code === 'KeyR' && !e.repeat) {
      this.recoverPlayer();
    } else if (e.code === 'KeyM' && !e.repeat) {
      this.toggleMute();
    }
  };

  private handleKeyUp = (e: KeyboardEvent) => {
    this.keys[e.code] = false;
  };

  private handleCanvasPointerDown = (e: PointerEvent) => {
    if (this.mode !== 'menu') return;
    this.isDraggingShowroom = true;
    this.dragStartX = e.clientX;
    this.dragStartAngle = this.showroomAngle;
  };

  private handleCanvasPointerMove = (e: PointerEvent) => {
    if (!this.isDraggingShowroom || this.mode !== 'menu') return;
    const dx = e.clientX - this.dragStartX;
    this.showroomAngle = this.dragStartAngle + dx * 0.0085;
    if (this.isSoftwareGl) {
      this.renderMenuOnce();
    }
  };

  private handleCanvasPointerUp = () => {
    this.isDraggingShowroom = false;
  };

  private handleBlur = () => {
    this.keys = {};
    this.touchState = { st: 0, th: 0, br: 0, hb: 0, nt: 0 };
    this.isDraggingShowroom = false;
    if (this.mode === 'race') {
      this.audio.silence();
    }
  };

  public dispose() {
    this.disposed = true;
    if (this.rafId !== null) cancelAnimationFrame(this.rafId);
    if (this.paceTimer !== null) clearTimeout(this.paceTimer);
    window.removeEventListener('resize', this.handleResize);
    window.removeEventListener('keydown', this.handleKeyDown);
    window.removeEventListener('keyup', this.handleKeyUp);
    window.removeEventListener('blur', this.handleBlur);
    this.renderer.domElement.removeEventListener('pointerdown', this.handleCanvasPointerDown);
    window.removeEventListener('pointermove', this.handleCanvasPointerMove);
    window.removeEventListener('pointerup', this.handleCanvasPointerUp);
    this.audio.dispose();
    this.particles.dispose();
    this.textures.dispose();
    this.envTexDay?.dispose();
    this.envTexSunset?.dispose();
    this.envTexNight?.dispose();
    this.pmrem.dispose();
    this.skidGeo.dispose();
    this.renderer.dispose();
    if (this.renderer.domElement.parentNode === this.container) {
      this.container.removeChild(this.renderer.domElement);
    }
  }
}
