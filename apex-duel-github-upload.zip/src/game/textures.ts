import * as THREE from 'three';
import { IMG } from './legacyAssets';

export interface RaceTextures {
  grass: THREE.CanvasTexture;
  asphalt: THREE.CanvasTexture;
  asphaltBump: THREE.CanvasTexture;
  asphaltRough: THREE.CanvasTexture;
  trees: THREE.CanvasTexture;
  mountainDay: THREE.Texture;
  mountainSunset: THREE.Texture;
  farSkyline: THREE.CanvasTexture;
  startGrid: THREE.CanvasTexture;
  barrier: THREE.CanvasTexture;
  contactShadow: THREE.CanvasTexture;
  nitroGlow: THREE.CanvasTexture;
  headlightGlow: THREE.CanvasTexture;
  headlightBeam: THREE.CanvasTexture;
  brakeGlow: THREE.CanvasTexture;
  gantryBanner: THREE.CanvasTexture;
  gantryLightsCanvas: HTMLCanvasElement;
  gantryLightsTex: THREE.CanvasTexture;
  crowd: THREE.CanvasTexture;
  sponsors: THREE.CanvasTexture[];
  brakeBoards: THREE.CanvasTexture[];
  dispose: () => void;
}

function loadMountainTexture(
  primaryUrl: string,
  fallbackB64: string,
  maxAniso: number,
  onReady?: () => void
): THREE.Texture {
  const tex = new THREE.Texture();
  tex.colorSpace = THREE.SRGBColorSpace;
  tex.anisotropy = maxAniso;
  tex.wrapS = THREE.RepeatWrapping;
  tex.wrapT = THREE.ClampToEdgeWrapping;
  tex.minFilter = THREE.LinearFilter;
  tex.magFilter = THREE.LinearFilter;
  tex.generateMipmaps = false;
  tex.repeat.set(2, 1);

  const hiResImg = new Image();
  hiResImg.onload = () => {
    tex.image = hiResImg;
    tex.needsUpdate = true;
    onReady?.();
  };
  hiResImg.onerror = () => {
    const fallbackImg = new Image();
    fallbackImg.onload = () => {
      tex.image = fallbackImg;
      tex.needsUpdate = true;
      onReady?.();
    };
    fallbackImg.src = `data:image/png;base64,${fallbackB64}`;
  };
  hiResImg.src = primaryUrl;

  return tex;
}

/**
 * Loads a high-resolution panorama JPG at its full native pixel resolution
 * and keys out the pure white sky into smooth feathered alpha so it composites
 * crisply in front of the mountain vista and sky dome.
 */
function loadKeyedVistaTexture(
  url: string,
  maxAniso: number,
  repeatX: number,
  trimBottomWhiteBand: boolean,
  onReady?: () => void
): THREE.CanvasTexture {
  const canvas = document.createElement('canvas');
  canvas.width = 1376;
  canvas.height = 768;
  const g = canvas.getContext('2d', { willReadFrequently: true })!;
  g.clearRect(0, 0, canvas.width, canvas.height);

  const tex = new THREE.CanvasTexture(canvas);
  tex.colorSpace = THREE.SRGBColorSpace;
  tex.wrapS = THREE.RepeatWrapping;
  tex.wrapT = THREE.ClampToEdgeWrapping;
  tex.minFilter = THREE.LinearFilter;
  tex.magFilter = THREE.LinearFilter;
  tex.generateMipmaps = false;
  tex.repeat.set(repeatX, 1);
  tex.anisotropy = maxAniso;

  const img = new Image();
  img.onload = () => {
    const w = img.naturalWidth || 1376;
    const h = img.naturalHeight || 768;
    canvas.width = w;
    canvas.height = h;
    g.clearRect(0, 0, w, h);
    g.drawImage(img, 0, 0, w, h);

    if (trimBottomWhiteBand) {
      const imgData = g.getImageData(0, 0, w, h);
      const d = imgData.data;
      let maxContentRow = h - 1;
      for (let y = h - 1; y >= 0; y--) {
        let darkFound = false;
        const rowOff = y * w * 4;
        for (let x = 0; x < w; x += 4) {
          const r = d[rowOff + x * 4];
          const gr = d[rowOff + x * 4 + 1];
          const b = d[rowOff + x * 4 + 2];
          if (r < 210 || gr < 210 || b < 210) {
            darkFound = true;
            break;
          }
        }
        if (darkFound) {
          maxContentRow = y;
          break;
        }
      }
      if (maxContentRow < h - 8 && maxContentRow > 80) {
        g.clearRect(0, 0, w, h);
        g.drawImage(
          img,
          0,
          0,
          w,
          maxContentRow,
          0,
          Math.round(h * 0.25),
          w,
          Math.round(h * 0.75)
        );
      }
    }

    const finalData = g.getImageData(0, 0, w, h);
    const fd = finalData.data;
    for (let y = 0; y < h; y++) {
      const topFade = y < 20 ? 0 : Math.min(1, (y - 20) / (h * 0.14));
      for (let x = 0; x < w; x++) {
        const i = (y * w + x) * 4;
        const r = fd[i];
        const gr = fd[i + 1];
        const b = fd[i + 2];
        const lum = (r + gr + b) / 3;
        const maxC = Math.max(r, gr, b);
        const minC = Math.min(r, gr, b);
        const sat = maxC - minC;

        const keyAlpha = Math.max(0, Math.min(1, (242 - lum) / 28 + sat / 34));
        fd[i + 3] = Math.round(keyAlpha * topFade * 255);
      }
    }
    g.putImageData(finalData, 0, 0);
    tex.needsUpdate = true;
    onReady?.();
  };
  img.src = url;
  return tex;
}

/**
 * Loads the 4-tree photorealistic alpine conifer sprite sheet at native HD
 * resolution and keys out its pure white background with clean edge defringing.
 */
function loadHdTreeSheetTexture(
  maxAniso: number,
  onReady?: () => void
): THREE.CanvasTexture {
  const canvas = document.createElement('canvas');
  canvas.width = 1376;
  canvas.height = 768;
  const g = canvas.getContext('2d', { willReadFrequently: true })!;
  g.clearRect(0, 0, canvas.width, canvas.height);

  const tex = new THREE.CanvasTexture(canvas);
  tex.colorSpace = THREE.SRGBColorSpace;
  tex.anisotropy = maxAniso;
  tex.minFilter = THREE.LinearMipmapLinearFilter;
  tex.magFilter = THREE.LinearFilter;

  const img = new Image();
  img.onload = () => {
    const w = img.naturalWidth || 1376;
    const h = img.naturalHeight || 768;
    canvas.width = w;
    canvas.height = h;
    g.clearRect(0, 0, w, h);
    g.drawImage(img, 0, 0, w, h);

    const imgData = g.getImageData(0, 0, w, h);
    const d = imgData.data;
    for (let i = 0; i < d.length; i += 4) {
      const r = d[i];
      const gr = d[i + 1];
      const b = d[i + 2];
      const lum = (r + gr + b) / 3;
      const sat = Math.max(r, gr, b) - Math.min(r, gr, b);
      // Key white studio background aggressively while preserving pine needles & trunks
      const alpha = Math.max(0, Math.min(1, (226 - lum) / 36 + sat / 34));
      d[i + 3] = Math.round(alpha * 255);
      // Defringe needle borders into natural forest shadow so zero white halo appears
      if (alpha > 0.04 && alpha < 0.96) {
        d[i] = Math.max(0, Math.round(r * 0.48));
        d[i + 1] = Math.max(0, Math.round(gr * 0.62));
        d[i + 2] = Math.max(0, Math.round(b * 0.46));
      }
    }
    g.putImageData(imgData, 0, 0);
    tex.needsUpdate = true;
    onReady?.();
  };
  img.onerror = () => {
    const fallback = new Image();
    fallback.onload = () => {
      canvas.width = fallback.naturalWidth || 512;
      canvas.height = fallback.naturalHeight || 512;
      g.drawImage(fallback, 0, 0, canvas.width, canvas.height);
      tex.needsUpdate = true;
      onReady?.();
    };
    fallback.src = `data:image/webp;base64,${IMG.trees}`;
  };
  img.src = '/assets/alpine-trees-hd.jpg';

  return tex;
}

/**
 * Loads the HD alpine meadow grass texture, crops out the corner edge, and
 * creates a seamless 2x2 mirrored tile at 1024x1024 so the entire valley looks lush.
 */
function makeHdGrassTexture(
  maxAniso: number,
  onReady?: () => void
): THREE.CanvasTexture {
  const c = document.createElement('canvas');
  c.width = 1024;
  c.height = 1024;
  const g = c.getContext('2d')!;
  g.fillStyle = '#3b6428';
  g.fillRect(0, 0, 1024, 1024);

  const tex = new THREE.CanvasTexture(c);
  tex.colorSpace = THREE.SRGBColorSpace;
  tex.wrapS = THREE.RepeatWrapping;
  tex.wrapT = THREE.RepeatWrapping;
  tex.repeat.set(145, 145);
  tex.anisotropy = maxAniso;

  const img = new Image();
  img.onload = () => {
    // Use clean top-left 74% square (excludes corner asphalt artifact) and mirror-tile 2x2
    const srcSize = Math.floor(Math.min(img.naturalWidth, img.naturalHeight) * 0.74);
    const half = 512;
    const drawTile = (dx: number, dy: number, flipX: boolean, flipY: boolean) => {
      g.save();
      g.translate(dx + (flipX ? half : 0), dy + (flipY ? half : 0));
      g.scale(flipX ? -1 : 1, flipY ? -1 : 1);
      g.drawImage(img, 0, 0, srcSize, srcSize, 0, 0, half, half);
      g.restore();
    };
    drawTile(0, 0, false, false);
    drawTile(half, 0, true, false);
    drawTile(0, half, false, true);
    drawTile(half, half, true, true);
    tex.needsUpdate = true;
    onReady?.();
  };
  img.onerror = () => {
    const fb = new Image();
    fb.onload = () => {
      g.drawImage(fb, 0, 0, 1024, 1024);
      tex.needsUpdate = true;
      onReady?.();
    };
    fb.src = `data:image/jpeg;base64,${IMG.grass}`;
  };
  img.src = '/assets/alpine-grass-hd.jpg';

  return tex;
}

/**
 * Full 1024x1024 HD motorsport circuit asphalt composited from the generated
 * aggregate photograph + FIA white edge boundaries + subtle lane rubbering.
 */
function makeEnhancedAsphaltTexture(
  maxAniso: number,
  onReady?: () => void
): THREE.CanvasTexture {
  const c = document.createElement('canvas');
  c.width = 1024;
  c.height = 1024;
  const g = c.getContext('2d')!;

  g.fillStyle = '#2d323a';
  g.fillRect(0, 0, 1024, 1024);

  const paintMarkings = () => {
    // Subtle dark rubbered racing groove along lanes
    const groove = g.createLinearGradient(0, 0, 1024, 0);
    groove.addColorStop(0.0, 'rgba(8,10,14,0.22)');
    groove.addColorStop(0.18, 'rgba(10,12,18,0.32)');
    groove.addColorStop(0.5, 'rgba(18,22,28,0.06)');
    groove.addColorStop(0.82, 'rgba(10,12,18,0.32)');
    groove.addColorStop(1.0, 'rgba(8,10,14,0.22)');
    g.fillStyle = groove;
    g.fillRect(0, 0, 1024, 1024);

    // Crisp FIA white track boundary lines
    g.fillStyle = 'rgba(244,247,252,0.92)';
    g.fillRect(24, 0, 16, 1024);
    g.fillRect(984, 0, 16, 1024);

    // Subtle dashed center racing guide
    g.fillStyle = 'rgba(236,242,248,0.36)';
    for (let y = 40; y < 1024; y += 256) {
      g.fillRect(507, y, 10, 108);
    }
  };

  paintMarkings();

  const tex = new THREE.CanvasTexture(c);
  tex.colorSpace = THREE.SRGBColorSpace;
  tex.wrapS = THREE.RepeatWrapping;
  tex.wrapT = THREE.RepeatWrapping;
  tex.repeat.set(1, 2);
  tex.anisotropy = maxAniso;

  const img = new Image();
  img.onload = () => {
    g.drawImage(img, 0, 0, 1024, 1024);
    // Slightly darken raw tarmac so crisp white markings & glossy car reflections pop
    g.fillStyle = 'rgba(16, 20, 26, 0.24)';
    g.fillRect(0, 0, 1024, 1024);
    paintMarkings();
    tex.needsUpdate = true;
    onReady?.();
  };
  img.onerror = () => {
    const fb = new Image();
    fb.onload = () => {
      g.drawImage(fb, 0, 0, 1024, 1024);
      paintMarkings();
      tex.needsUpdate = true;
      onReady?.();
    };
    fb.src = `data:image/jpeg;base64,${IMG.asphalt}`;
  };
  img.src = '/assets/circuit-asphalt-hd.jpg';
  return tex;
}

function makeAsphaltBumpTexture(maxAniso: number): THREE.CanvasTexture {
  const c = document.createElement('canvas');
  c.width = 512;
  c.height = 512;
  const g = c.getContext('2d')!;
  g.fillStyle = '#808080';
  g.fillRect(0, 0, 512, 512);

  let seed = 1337;
  const rand = () => {
    seed = (seed * 16807) % 2147483647;
    return (seed - 1) / 2147483646;
  };
  for (let i = 0; i < 22000; i++) {
    const x = (rand() * 512) | 0;
    const y = (rand() * 512) | 0;
    const v = 90 + ((rand() * 82) | 0);
    g.fillStyle = `rgb(${v},${v},${v})`;
    g.fillRect(x, y, 2, 2);
  }

  const tex = new THREE.CanvasTexture(c);
  tex.colorSpace = THREE.NoColorSpace;
  tex.wrapS = THREE.RepeatWrapping;
  tex.wrapT = THREE.RepeatWrapping;
  tex.repeat.set(1, 2);
  tex.anisotropy = maxAniso;
  return tex;
}

function makeAsphaltRoughTexture(maxAniso: number): THREE.CanvasTexture {
  const c = document.createElement('canvas');
  c.width = 256;
  c.height = 256;
  const g = c.getContext('2d')!;
  const grad = g.createLinearGradient(0, 0, 256, 0);
  grad.addColorStop(0.0, '#d8d8d8');
  grad.addColorStop(0.22, '#868686');
  grad.addColorStop(0.5, '#b6b6b6');
  grad.addColorStop(0.78, '#868686');
  grad.addColorStop(1.0, '#d8d8d8');
  g.fillStyle = grad;
  g.fillRect(0, 0, 256, 256);

  const tex = new THREE.CanvasTexture(c);
  tex.colorSpace = THREE.NoColorSpace;
  tex.wrapS = THREE.RepeatWrapping;
  tex.wrapT = THREE.RepeatWrapping;
  tex.repeat.set(1, 2);
  tex.anisotropy = maxAniso;
  return tex;
}

function makeStartGridTexture(): THREE.CanvasTexture {
  const c = document.createElement('canvas');
  c.width = 1024;
  c.height = 128;
  const g = c.getContext('2d')!;
  g.clearRect(0, 0, 1024, 128);

  const sq = 32;
  for (let row = 0; row < 4; row++) {
    for (let col = 0; col < 32; col++) {
      g.fillStyle =
        (row + col) % 2 === 0
          ? 'rgba(246,248,252,0.92)'
          : 'rgba(18,22,28,0.92)';
      g.fillRect(col * sq, row * sq, sq, sq);
    }
  }
  const tex = new THREE.CanvasTexture(c);
  tex.colorSpace = THREE.SRGBColorSpace;
  tex.anisotropy = 4;
  return tex;
}

function makeContactShadowTexture(): THREE.CanvasTexture {
  const c = document.createElement('canvas');
  c.width = 256;
  c.height = 256;
  const g = c.getContext('2d')!;
  g.clearRect(0, 0, 256, 256);
  const grad = g.createRadialGradient(128, 128, 18, 128, 128, 122);
  grad.addColorStop(0.0, 'rgba(4,6,10,0.88)');
  grad.addColorStop(0.54, 'rgba(4,6,10,0.6)');
  grad.addColorStop(0.84, 'rgba(4,6,10,0.16)');
  grad.addColorStop(1.0, 'rgba(4,6,10,0)');
  g.fillStyle = grad;
  g.fillRect(0, 0, 256, 256);

  const tex = new THREE.CanvasTexture(c);
  tex.colorSpace = THREE.SRGBColorSpace;
  return tex;
}

function makeRadialGlowTexture(
  innerColor: string,
  midColor: string,
  outerColor: string
): THREE.CanvasTexture {
  const c = document.createElement('canvas');
  c.width = 128;
  c.height = 128;
  const g = c.getContext('2d')!;
  const grad = g.createRadialGradient(64, 64, 3, 64, 64, 62);
  grad.addColorStop(0.0, innerColor);
  grad.addColorStop(0.32, midColor);
  grad.addColorStop(0.68, outerColor);
  grad.addColorStop(1.0, 'rgba(0,0,0,0)');
  g.fillStyle = grad;
  g.fillRect(0, 0, 128, 128);
  const tex = new THREE.CanvasTexture(c);
  tex.colorSpace = THREE.SRGBColorSpace;
  return tex;
}

function makeGantryBannerTexture(): THREE.CanvasTexture {
  const c = document.createElement('canvas');
  c.width = 1024;
  c.height = 192;
  const g = c.getContext('2d')!;
  g.fillStyle = '#0d131d';
  g.fillRect(0, 0, 1024, 192);

  const sq = 24;
  for (let row = 0; row < 8; row++) {
    for (let col = 0; col < 8; col++) {
      g.fillStyle = (row + col) % 2 === 0 ? '#f4f6f9' : '#131922';
      g.fillRect(col * sq, row * sq, sq, sq);
      g.fillRect(1024 - (col + 1) * sq, row * sq, sq, sq);
    }
  }

  g.fillStyle = '#ff6d1f';
  g.fillRect(192, 0, 640, 14);
  g.fillRect(192, 178, 640, 14);

  g.fillStyle = '#ffffff';
  g.font = '800 72px "Chakra Petch", sans-serif';
  g.textAlign = 'center';
  g.textBaseline = 'middle';
  g.fillText('APEX DUEL', 512, 86);

  g.fillStyle = '#38d2ff';
  g.font = '700 26px "Chakra Petch", sans-serif';
  g.fillText('GRAND PRIX CIRCUIT', 512, 142);

  const tex = new THREE.CanvasTexture(c);
  tex.colorSpace = THREE.SRGBColorSpace;
  tex.anisotropy = 4;
  return tex;
}

function makeCrowdTexture(): THREE.CanvasTexture {
  const c = document.createElement('canvas');
  c.width = 256;
  c.height = 128;
  const g = c.getContext('2d')!;
  g.fillStyle = '#242b38';
  g.fillRect(0, 0, 256, 128);

  const palette = ['#e8513c', '#38bdf8', '#facc15', '#ffffff', '#fb923c', '#94a3b8'];
  let seed = 4242;
  const rand = () => {
    seed = (seed * 48271) % 2147483647;
    return (seed - 1) / 2147483646;
  };
  for (let row = 0; row < 8; row++) {
    const y = 8 + row * 15;
    g.fillStyle = row % 2 === 0 ? '#1b212d' : '#2a3344';
    g.fillRect(0, y + 6, 256, 6);
    for (let x = 4; x < 252; x += 7) {
      g.fillStyle = palette[(rand() * palette.length) | 0];
      g.fillRect(x, y, 4, 6);
    }
  }
  const tex = new THREE.CanvasTexture(c);
  tex.colorSpace = THREE.SRGBColorSpace;
  tex.wrapS = THREE.RepeatWrapping;
  return tex;
}

function makeSponsorTextures(): THREE.CanvasTexture[] {
  const specs: Array<[string, string, string]> = [
    ['APEX', '#0d1524', '#ff6d1f'],
    ['TURBO-X', '#151923', '#38d2ff'],
    ['NITROLUX', '#1b1026', '#fbbf24'],
    ['VELOCITÀ', '#240f15', '#f8fafc'],
    ['REDLINE', '#121822', '#ef4444'],
    ['OCTANE', '#0f1f19', '#a3e635'],
  ];
  return specs.map(([label, bg, fg]) => {
    const c = document.createElement('canvas');
    c.width = 512;
    c.height = 160;
    const g = c.getContext('2d')!;
    g.fillStyle = bg;
    g.fillRect(0, 0, 512, 160);
    g.fillStyle = fg;
    g.fillRect(0, 0, 512, 12);
    g.fillRect(0, 148, 512, 12);
    g.font = '800 68px "Chakra Petch", sans-serif';
    g.textAlign = 'center';
    g.textBaseline = 'middle';
    g.fillText(label, 256, 84);
    const tex = new THREE.CanvasTexture(c);
    tex.colorSpace = THREE.SRGBColorSpace;
    tex.anisotropy = 4;
    return tex;
  });
}

export function paintGantryLights(
  canvas: HTMLCanvasElement,
  tex: THREE.CanvasTexture,
  countdownSec: number,
  isRacing: boolean
) {
  const g = canvas.getContext('2d')!;
  g.fillStyle = '#0a0d14';
  g.fillRect(0, 0, 512, 96);

  const litCount = isRacing ? 5 : Math.max(0, 4 - Math.ceil(countdownSec));
  const color = isRacing ? '#22e67c' : '#ff3326';

  for (let i = 0; i < 5; i++) {
    const cx = 64 + i * 96;
    const cy = 48;
    const lit = isRacing || i < litCount;
    if (lit) {
      const grad = g.createRadialGradient(cx, cy, 4, cx, cy, 38);
      grad.addColorStop(0, '#ffffff');
      grad.addColorStop(0.35, color);
      grad.addColorStop(1, 'rgba(0,0,0,0)');
      g.fillStyle = grad;
      g.beginPath();
      g.arc(cx, cy, 38, 0, Math.PI * 2);
      g.fill();
    }
    g.fillStyle = lit ? color : '#27171a';
    g.beginPath();
    g.arc(cx, cy, 22, 0, Math.PI * 2);
    g.fill();

    g.strokeStyle = '#3b4254';
    g.lineWidth = 3;
    g.stroke();
  }
  tex.needsUpdate = true;
}

export function createRaceTextures(
  maxAniso: number,
  onAssetReady?: () => void
): RaceTextures {
  const grass = makeHdGrassTexture(maxAniso, onAssetReady);
  const asphalt = makeEnhancedAsphaltTexture(maxAniso, onAssetReady);
  const asphaltBump = makeAsphaltBumpTexture(maxAniso);
  const asphaltRough = makeAsphaltRoughTexture(maxAniso);
  const trees = loadHdTreeSheetTexture(maxAniso, onAssetReady);
  const mountainDay = loadMountainTexture(
    '/assets/mountain-day.png',
    IMG.bd_day,
    maxAniso,
    onAssetReady
  );
  const mountainSunset = loadMountainTexture(
    '/assets/mountain-sunset.png',
    IMG.bd_sunset,
    maxAniso,
    onAssetReady
  );
  const farSkyline = loadKeyedVistaTexture(
    '/assets/far-circuit-skyline.jpg',
    maxAniso,
    4,
    true,
    onAssetReady
  );
  const startGrid = makeStartGridTexture();
  const barrier = makeBarrierTexture(maxAniso);
  const contactShadow = makeContactShadowTexture();
  const nitroGlow = makeRadialGlowTexture(
    'rgba(255,255,255,1)',
    'rgba(130,225,255,0.92)',
    'rgba(30,130,255,0.4)'
  );
  const headlightGlow = makeRadialGlowTexture(
    'rgba(255,255,255,0.95)',
    'rgba(215,242,255,0.55)',
    'rgba(140,210,255,0.14)'
  );
  const headlightBeam = makeHeadlightBeamTexture();
  const brakeGlow = makeRadialGlowTexture(
    'rgba(255,235,235,0.95)',
    'rgba(255,42,42,0.72)',
    'rgba(210,10,18,0.22)'
  );
  const gantryBanner = makeGantryBannerTexture();

  const gantryLightsCanvas = document.createElement('canvas');
  gantryLightsCanvas.width = 512;
  gantryLightsCanvas.height = 96;
  const gantryLightsTex = new THREE.CanvasTexture(gantryLightsCanvas);
  gantryLightsTex.colorSpace = THREE.SRGBColorSpace;
  paintGantryLights(gantryLightsCanvas, gantryLightsTex, 3, false);

  const crowd = makeCrowdTexture();
  const sponsors = makeSponsorTextures();
  const brakeBoards = makeBrakeBoardTextures();

  return {
    grass,
    asphalt,
    asphaltBump,
    asphaltRough,
    trees,
    mountainDay,
    mountainSunset,
    farSkyline,
    startGrid,
    barrier,
    contactShadow,
    nitroGlow,
    headlightGlow,
    headlightBeam,
    brakeGlow,
    gantryBanner,
    gantryLightsCanvas,
    gantryLightsTex,
    crowd,
    sponsors,
    brakeBoards,
    dispose() {
      grass.dispose();
      asphalt.dispose();
      asphaltBump.dispose();
      asphaltRough.dispose();
      trees.dispose();
      mountainDay.dispose();
      mountainSunset.dispose();
      farSkyline.dispose();
      startGrid.dispose();
      barrier.dispose();
      contactShadow.dispose();
      nitroGlow.dispose();
      headlightGlow.dispose();
      headlightBeam.dispose();
      brakeGlow.dispose();
      gantryBanner.dispose();
      gantryLightsTex.dispose();
      crowd.dispose();
      sponsors.forEach((s) => s.dispose());
      brakeBoards.forEach((b) => b.dispose());
    },
  };
}

function makeHeadlightBeamTexture(): THREE.CanvasTexture {
  const w = 128;
  const h = 256;
  const c = document.createElement('canvas');
  c.width = w;
  c.height = h;
  const g = c.getContext('2d')!;
  const img = g.createImageData(w, h);
  const d = img.data;

  // PlaneGeometry rotated -PI/2 maps canvas y=0 to -Z (car headlights) and y=h to +Z (road ahead)
  for (let y = 0; y < h; y++) {
    const t = y / (h - 1); // 0 at headlamp, 1 at far end
    const halfWidth = 10 + t * 50; // fans smoothly outward down the road
    const longFade = Math.pow(1 - t, 1.65) * Math.min(1, t * 14 + 0.25);

    for (let x = 0; x < w; x++) {
      const dx = Math.abs(x - w * 0.5) / halfWidth;
      if (dx >= 1.25) continue;
      // Smooth Gaussian-like lateral falloff with brighter Xenon center core
      const radial = Math.max(0, 1 - dx);
      const softCone = radial * radial * (3 - 2 * radial);
      const core = Math.exp(-dx * dx * 3.8);
      const alpha = Math.min(1, (softCone * 0.52 + core * 0.42) * longFade * 0.88);
      const idx = (y * w + x) * 4;
      // Warm white core near headlamp transitioning to crisp cool Xenon downrange
      d[idx] = Math.round(255 - t * 65);
      d[idx + 1] = Math.round(252 - t * 30);
      d[idx + 2] = 255;
      d[idx + 3] = Math.round(alpha * 255);
    }
  }
  g.putImageData(img, 0, 0);

  const tex = new THREE.CanvasTexture(c);
  tex.colorSpace = THREE.SRGBColorSpace;
  return tex;
}

function makeBrakeBoardTextures(): THREE.CanvasTexture[] {
  return ['150', '100', '50'].map((num) => {
    const c = document.createElement('canvas');
    c.width = 256;
    c.height = 128;
    const g = c.getContext('2d')!;
    g.fillStyle = '#f8fafc';
    g.fillRect(0, 0, 256, 128);
    g.strokeStyle = '#dc2626';
    g.lineWidth = 12;
    g.strokeRect(6, 6, 244, 116);
    g.fillStyle = '#0f172a';
    g.font = '900 72px "Chakra Petch", sans-serif';
    g.textAlign = 'center';
    g.textBaseline = 'middle';
    g.fillText(`${num}m`, 128, 66);
    const tex = new THREE.CanvasTexture(c);
    tex.colorSpace = THREE.SRGBColorSpace;
    return tex;
  });
}

function makeBarrierTexture(maxAniso: number): THREE.CanvasTexture {
  const c = document.createElement('canvas');
  c.width = 1024;
  c.height = 128;
  const g = c.getContext('2d')!;

  // Concrete circuit safety wall base
  g.fillStyle = '#dde3ea';
  g.fillRect(0, 0, 1024, 128);

  // Subtle top cap shadow & bottom concrete footing
  g.fillStyle = '#adb7c4';
  g.fillRect(0, 0, 1024, 14);
  g.fillStyle = '#8b95a3';
  g.fillRect(0, 106, 1024, 22);

  // Crisp FIA crimson & pure white motorsport safety bands (zero vertex interpolation blur)
  const stripeW = 256;
  for (let x = 0; x < 1024; x += stripeW) {
    const isRed = ((x / stripeW) | 0) % 2 === 0;
    g.fillStyle = isRed ? '#c82020' : '#f4f7fb';
    g.fillRect(x, 22, stripeW, 74);

    // Subtle dark vertical expansion joint between concrete wall modules
    g.fillStyle = 'rgba(20, 28, 38, 0.35)';
    g.fillRect(x, 0, 4, 128);
  }

  // Thin motorsport accent pinstripe along upper & lower band edge
  g.fillStyle = '#1b2230';
  g.fillRect(0, 18, 1024, 5);
  g.fillRect(0, 96, 1024, 5);

  // Subtle concrete grain specks
  let seed = 4242;
  const rand = () => {
    seed = (seed * 16807) % 2147483647;
    return (seed - 1) / 2147483646;
  };
  for (let i = 0; i < 3500; i++) {
    const x = (rand() * 1024) | 0;
    const y = (rand() * 128) | 0;
    g.fillStyle = rand() > 0.5 ? 'rgba(0,0,0,0.06)' : 'rgba(255,255,255,0.05)';
    g.fillRect(x, y, 2, 2);
  }

  const tex = new THREE.CanvasTexture(c);
  tex.colorSpace = THREE.SRGBColorSpace;
  tex.wrapS = THREE.RepeatWrapping;
  tex.wrapT = THREE.ClampToEdgeWrapping;
  tex.anisotropy = maxAniso;
  return tex;
}
