import { THUMBS } from './legacyAssets';
import {
  CAR_IDS,
  CAR_VARIANTS,
  DIFFICULTY_SPECS,
  formatOrdinal,
  formatRaceTime,
  getCarStats,
} from './rules';
import {
  CameraMode,
  CarVariantId,
  Difficulty,
  HudSnapshot,
  TimeOfDay,
  TurnSeverity,
} from './types';

export interface HudCallbacks {
  onSelectTimeOfDay: (tod: TimeOfDay) => void;
  onSelectDifficulty: (d: Difficulty) => void;
  onSelectCar: (id: CarVariantId) => void;
  onStartRace: () => void;
  onCycleCamera: () => void;
  onToggleMute: () => void;
  onTogglePause: () => void;
  onRecoverCar: () => void;
  onRestartRace: () => void;
  onChangeCar: () => void;
  onTouchControl: (key: 'st' | 'th' | 'br' | 'hb' | 'nt', val: number) => void;
}

const CAM_LABELS: Record<CameraMode, string> = {
  0: 'Chase [C]',
  1: 'Close [C]',
  2: 'Hood [C]',
  3: 'Bumper [C]',
};

const TURN_META: Record<
  TurnSeverity,
  { arrow: string; label: string; hot: boolean }
> = {
  none: { arrow: '', label: '', hot: false },
  left: { arrow: '↰', label: 'SHARP LEFT', hot: false },
  right: { arrow: '↱', label: 'SHARP RIGHT', hot: false },
  'hairpin-left': { arrow: '↶', label: 'HAIRPIN LEFT', hot: true },
  'hairpin-right': { arrow: '↷', label: 'HAIRPIN RIGHT', hot: true },
};

export class RaceHud {
  public readonly minimapCanvas: HTMLCanvasElement;

  private root: HTMLElement;
  private cb: HudCallbacks;

  // Screen overlays
  private titleEl: HTMLElement;
  private raceHudEl: HTMLElement;
  private loadingEl: HTMLElement;
  private pauseEl: HTMLElement;
  private doneEl: HTMLElement;

  // Title controls
  private todButtons = new Map<TimeOfDay, HTMLButtonElement>();
  private diffButtons = new Map<Difficulty, HTMLButtonElement>();
  private carCards = new Map<CarVariantId, HTMLButtonElement>();
  private recordBadgeEl: HTMLElement;

  // Telemetry refs (direct property updates, zero layout thrash)
  private lapValEl: HTMLElement;
  private posValEl: HTMLElement;
  private timeValEl: HTMLElement;
  private bestValEl: HTMLElement;
  private speedValEl: HTMLElement;
  private gearValEl: HTMLElement;
  private rpmBarEl: HTMLElement;
  private nitroBarEl: HTMLElement;
  private camBtn: HTMLButtonElement;
  private muteBtn: HTMLButtonElement;
  private countdownEl: HTMLElement;
  private offTrackEl: HTMLElement;
  private wrongWayEl: HTMLElement;
  private turnWarnEl: HTMLElement;
  private turnArrowEl: HTMLElement;
  private turnLabelEl: HTMLElement;
  private statusStripEl: HTMLElement;
  private bannerEl: HTMLElement;
  private loadBarEl: HTMLElement;
  private loadLabelEl: HTMLElement;

  // Results refs
  private resultHeadlineEl: HTMLElement;
  private resultMetaEl: HTMLElement;
  private resultRowsEl: HTMLElement;

  private prevMode: string = '';
  private prevTod: string = '';
  private prevDiff: string = '';
  private prevCar: string = '';
  private prevCam: number = -1;
  private prevMuted: boolean | null = null;
  private prevTurn: TurnSeverity = 'none';
  private prevRecord: number = -1;

  constructor(root: HTMLElement, cb: HudCallbacks) {
    this.root = root;
    this.cb = cb;

    this.root.innerHTML = `
      <!-- Title & Garage Overlay -->
      <section class="overlay title-overlay" id="screen-title">
        <div class="title-panel">
          <header class="brand-header">
            <div class="brand-mark" aria-hidden="true">
              <svg viewBox="0 0 64 36" width="52" height="30" fill="none">
                <path d="M4 30L20 6h14L18 30H4z" fill="#ff6d1f"/>
                <path d="M24 30L40 6h12L36 30H24z" fill="#38d2ff"/>
                <path d="M44 30L56 12h6L50 30h-6z" fill="#f8fafc"/>
              </svg>
            </div>
            <div class="brand-copy">
              <h1>APEX DUEL</h1>
              <p class="subtitle">GT300 &amp; EB110 Alpine Circuit Showdown</p>
            </div>
            <div class="record-box hidden" id="garage-record"></div>
          </header>

          <div class="setup-row">
            <div class="setup-group">
              <span class="group-label">Conditions</span>
              <div class="seg-group">
                <button type="button" class="seg-btn active" id="btn-tod-day" data-tod="day">Day</button>
                <button type="button" class="seg-btn" id="btn-tod-sunset" data-tod="sunset">Sunset</button>
                <button type="button" class="seg-btn" id="btn-tod-night" data-tod="night">Night</button>
              </div>
            </div>
            <div class="setup-group">
              <span class="group-label">AI Pace</span>
              <div class="seg-group">
                <button type="button" class="seg-btn" data-diff="rookie">Rookie</button>
                <button type="button" class="seg-btn active" data-diff="pro">Pro</button>
                <button type="button" class="seg-btn" data-diff="legend">Legend</button>
              </div>
            </div>
          </div>

          <div class="garage-grid" id="garage-grid"></div>

          <div class="title-footer">
            <p class="controls-hint">
              WASD / Arrows drive &middot; Shift/N nitro &middot; Space drift &middot; C cam &middot; B look back &middot; Drag car to inspect
            </p>
            <button type="button" class="cta-btn" id="btn-start-game" data-start="true">
              Race Now
            </button>
          </div>
        </div>
      </section>

      <!-- Live Race HUD -->
      <section class="race-hud hidden" id="screen-hud">
        <div class="hud-top">
          <div class="hud-block hud-timing">
            <div class="stat-cell">
              <span class="stat-label">POS</span>
              <span class="stat-value accent-cyan" id="hud-pos">1st/4</span>
            </div>
            <div class="stat-cell">
              <span class="stat-label">LAP</span>
              <span class="stat-value" id="hud-lap">1/3</span>
            </div>
            <div class="stat-cell">
              <span class="stat-label">TIME</span>
              <span class="stat-value mono" id="hud-time">0:00.00</span>
            </div>
            <div class="stat-cell">
              <span class="stat-label">BEST</span>
              <span class="stat-value mono" id="hud-best">--:--</span>
            </div>
          </div>

          <div class="hud-block hud-cluster">
            <div class="speed-readout">
              <span class="gear-badge" id="hud-gear">1</span>
              <span class="speed-num mono" id="hud-speed">0</span>
              <span class="speed-unit">KM/H</span>
            </div>
            <div class="bars-stack">
              <div class="meter-row">
                <span class="meter-tag">RPM</span>
                <div class="meter-track"><div class="meter-fill rpm-fill" id="hud-rpm"></div></div>
              </div>
              <div class="meter-row">
                <span class="meter-tag">NOS</span>
                <div class="meter-track"><div class="meter-fill nitro-fill" id="hud-nitro"></div></div>
              </div>
            </div>
          </div>

          <div class="hud-right">
            <canvas id="minimap-canvas" width="144" height="96" aria-label="Track minimap"></canvas>
            <div class="hud-actions">
              <button type="button" class="hud-btn" id="btn-cam">Chase [C]</button>
              <button type="button" class="hud-btn" id="btn-mute">Sound [M]</button>
              <button type="button" class="hud-btn" id="btn-recover">Reset [R]</button>
              <button type="button" class="hud-btn" id="btn-pause">Pause [P]</button>
            </div>
          </div>
        </div>

        <div class="turn-warn hidden" id="hud-turn-warn">
          <span class="turn-arrow" id="hud-turn-arrow">↱</span>
          <span class="turn-label" id="hud-turn-label">SHARP RIGHT</span>
        </div>

        <div class="status-strip hidden" id="hud-status-strip"></div>
        <div class="race-banner hidden" id="hud-banner"></div>
        <div class="center-callout" id="hud-countdown"></div>
        <div class="offtrack-callout hidden" id="hud-offtrack">OFF TRACK</div>
        <div class="wrongway-callout hidden" id="hud-wrongway">WRONG WAY &middot; PRESS R</div>

        <!-- Touch Controls (coarse pointers / mobile) -->
        <div class="touch-controls" id="touch-controls">
          <div class="touch-pad">
            <button type="button" class="t-btn" data-t="left" aria-label="Steer left">&larr;</button>
            <button type="button" class="t-btn" data-t="right" aria-label="Steer right">&rarr;</button>
          </div>
          <div class="touch-pad">
            <button type="button" class="t-btn" data-t="brake">BRK</button>
            <button type="button" class="t-btn t-nitro" data-t="nitro">NOS</button>
            <button type="button" class="t-btn t-gas" data-t="gas">GAS</button>
          </div>
        </div>
      </section>

      <!-- Track Loading Overlay -->
      <section class="overlay modal-overlay hidden" id="screen-loading">
        <div class="modal-card">
          <h2>Preparing Circuit</h2>
          <p class="modal-sub" id="load-label">Building track sectors…</p>
          <div class="load-track"><div class="load-fill" id="load-bar"></div></div>
        </div>
      </section>

      <!-- Pause Overlay -->
      <section class="overlay modal-overlay hidden" id="screen-pause">
        <div class="modal-card">
          <h2>Race Paused</h2>
          <p class="modal-sub">Take a breather or adjust your race strategy</p>
          <div class="modal-actions">
            <button type="button" class="cta-btn" id="btn-resume">Resume</button>
            <button type="button" class="sec-btn" id="btn-restart-pause">Restart</button>
            <button type="button" class="sec-btn" id="btn-garage-pause">Change Car</button>
          </div>
        </div>
      </section>

      <!-- Post-Race Results Overlay -->
      <section class="overlay modal-overlay hidden" id="screen-done">
        <div class="modal-card results-card">
          <h2 id="res-headline">1st Place Finish</h2>
          <p class="modal-sub" id="res-meta"></p>
          <div class="standings-list" id="res-rows"></div>
          <div class="modal-actions">
            <button type="button" class="cta-btn" id="btn-race-again" data-start="true">Race Again</button>
            <button type="button" class="sec-btn" id="btn-garage-done">Change Car</button>
          </div>
        </div>
      </section>
    `;

    this.titleEl = root.querySelector('#screen-title')!;
    this.raceHudEl = root.querySelector('#screen-hud')!;
    this.loadingEl = root.querySelector('#screen-loading')!;
    this.pauseEl = root.querySelector('#screen-pause')!;
    this.doneEl = root.querySelector('#screen-done')!;
    this.recordBadgeEl = root.querySelector('#garage-record')!;
    this.minimapCanvas = root.querySelector('#minimap-canvas')!;

    this.lapValEl = root.querySelector('#hud-lap')!;
    this.posValEl = root.querySelector('#hud-pos')!;
    this.timeValEl = root.querySelector('#hud-time')!;
    this.bestValEl = root.querySelector('#hud-best')!;
    this.speedValEl = root.querySelector('#hud-speed')!;
    this.gearValEl = root.querySelector('#hud-gear')!;
    this.rpmBarEl = root.querySelector('#hud-rpm')!;
    this.nitroBarEl = root.querySelector('#hud-nitro')!;
    this.camBtn = root.querySelector('#btn-cam')!;
    this.muteBtn = root.querySelector('#btn-mute')!;
    this.countdownEl = root.querySelector('#hud-countdown')!;
    this.offTrackEl = root.querySelector('#hud-offtrack')!;
    this.wrongWayEl = root.querySelector('#hud-wrongway')!;
    this.turnWarnEl = root.querySelector('#hud-turn-warn')!;
    this.turnArrowEl = root.querySelector('#hud-turn-arrow')!;
    this.turnLabelEl = root.querySelector('#hud-turn-label')!;
    this.statusStripEl = root.querySelector('#hud-status-strip')!;
    this.bannerEl = root.querySelector('#hud-banner')!;
    this.loadBarEl = root.querySelector('#load-bar')!;
    this.loadLabelEl = root.querySelector('#load-label')!;
    this.resultHeadlineEl = root.querySelector('#res-headline')!;
    this.resultMetaEl = root.querySelector('#res-meta')!;
    this.resultRowsEl = root.querySelector('#res-rows')!;

    // Populate 6 car selection cards
    const garageGrid = root.querySelector('#garage-grid')!;
    for (const id of CAR_IDS) {
      const c = CAR_VARIANTS[id];
      const [spd, acc, grp] = getCarStats(c);
      const card = document.createElement('button');
      card.type = 'button';
      card.className = 'car-card';
      card.dataset.car = id;
      card.innerHTML = `
        <div class="car-thumb-wrap">
          <img src="data:image/jpeg;base64,${THUMBS[id]}" alt="${c.name}" loading="eager" />
          <span class="car-swatch" style="background:${c.sw}"></span>
        </div>
        <div class="car-name">${c.name}</div>
        <div class="car-stats">
          <div class="cstat"><span>SPD</span><div><i style="width:${spd}%"></i></div></div>
          <div class="cstat"><span>ACC</span><div><i style="width:${acc}%"></i></div></div>
          <div class="cstat"><span>GRP</span><div><i style="width:${grp}%"></i></div></div>
        </div>
      `;
      card.addEventListener('click', () => this.cb.onSelectCar(id));
      garageGrid.appendChild(card);
      this.carCards.set(id, card);
    }

    // Wire events
    root.querySelectorAll<HTMLButtonElement>('[data-tod]').forEach((btn) => {
      const tod = btn.dataset.tod as TimeOfDay;
      this.todButtons.set(tod, btn);
      btn.addEventListener('click', () => this.cb.onSelectTimeOfDay(tod));
    });

    root.querySelectorAll<HTMLButtonElement>('[data-diff]').forEach((btn) => {
      const diff = btn.dataset.diff as Difficulty;
      this.diffButtons.set(diff, btn);
      btn.addEventListener('click', () => this.cb.onSelectDifficulty(diff));
    });

    root.querySelector('#btn-start-game')?.addEventListener('click', () => this.cb.onStartRace());
    root.querySelector('#btn-cam')?.addEventListener('click', () => this.cb.onCycleCamera());
    root.querySelector('#btn-mute')?.addEventListener('click', () => this.cb.onToggleMute());
    root.querySelector('#btn-recover')?.addEventListener('click', () => this.cb.onRecoverCar());
    root.querySelector('#btn-pause')?.addEventListener('click', () => this.cb.onTogglePause());
    root.querySelector('#btn-resume')?.addEventListener('click', () => this.cb.onTogglePause());
    root.querySelector('#btn-restart-pause')?.addEventListener('click', () => this.cb.onRestartRace());
    root.querySelector('#btn-garage-pause')?.addEventListener('click', () => this.cb.onChangeCar());
    root.querySelector('#btn-race-again')?.addEventListener('click', () => this.cb.onRestartRace());
    root.querySelector('#btn-garage-done')?.addEventListener('click', () => this.cb.onChangeCar());

    // Bind touch controls
    const bindTouch = (sel: string, key: 'st' | 'th' | 'br' | 'nt', val: number) => {
      const el = root.querySelector(`[data-t="${sel}"]`);
      if (!el) return;
      const on = (e: Event) => {
        e.preventDefault();
        this.cb.onTouchControl(key, val);
      };
      const off = (e: Event) => {
        e.preventDefault();
        this.cb.onTouchControl(key, 0);
      };
      el.addEventListener('pointerdown', on);
      el.addEventListener('pointerup', off);
      el.addEventListener('pointercancel', off);
      el.addEventListener('pointerleave', off);
    };
    bindTouch('left', 'st', 1);
    bindTouch('right', 'st', -1);
    bindTouch('gas', 'th', 1);
    bindTouch('brake', 'br', 1);
    bindTouch('nitro', 'nt', 1);
  }

  public update(snap: HudSnapshot) {
    document.body.dataset.state = snap.bodyState;

    if (snap.mode !== this.prevMode) {
      this.prevMode = snap.mode;
      this.titleEl.classList.toggle('hidden', snap.mode !== 'menu');
      this.loadingEl.classList.toggle('hidden', snap.mode !== 'loading');
      this.pauseEl.classList.toggle('hidden', snap.mode !== 'pause');
      this.doneEl.classList.toggle('hidden', snap.mode !== 'done');
      const showHud =
        snap.mode === 'count' ||
        snap.mode === 'race' ||
        snap.mode === 'pause';
      this.raceHudEl.classList.toggle('hidden', !showHud);

      if (snap.mode === 'done') {
        this.renderResults(snap);
      }
    }

    if (snap.recordLapSec !== this.prevRecord) {
      this.prevRecord = snap.recordLapSec;
      if (snap.recordLapSec > 0) {
        this.recordBadgeEl.textContent = `RECORD ${formatRaceTime(snap.recordLapSec)}`;
        this.recordBadgeEl.classList.remove('hidden');
      } else {
        this.recordBadgeEl.classList.add('hidden');
      }
    }

    if (snap.timeOfDay !== this.prevTod) {
      this.prevTod = snap.timeOfDay;
      this.todButtons.forEach((btn, tod) => {
        btn.classList.toggle('active', tod === snap.timeOfDay);
      });
    }

    if (snap.difficulty !== this.prevDiff) {
      this.prevDiff = snap.difficulty;
      this.diffButtons.forEach((btn, d) => {
        btn.classList.toggle('active', d === snap.difficulty);
      });
    }

    if (snap.selectedCar !== this.prevCar) {
      this.prevCar = snap.selectedCar;
      this.carCards.forEach((card, id) => {
        card.classList.toggle('active', id === snap.selectedCar);
      });
    }

    if (snap.cameraMode !== this.prevCam) {
      this.prevCam = snap.cameraMode;
      this.camBtn.textContent = CAM_LABELS[snap.cameraMode];
    }

    if (snap.muted !== this.prevMuted) {
      this.prevMuted = snap.muted;
      this.muteBtn.textContent = snap.muted ? 'Muted [M]' : 'Sound [M]';
    }

    if (snap.mode === 'loading') {
      this.loadBarEl.style.width = `${Math.round(snap.loadProgress * 100)}%`;
      this.loadLabelEl.textContent = snap.loadText;
    }

    if (snap.mode === 'count' || snap.mode === 'race') {
      this.posValEl.textContent = `${formatOrdinal(snap.position)}/${snap.totalCars}`;
      this.lapValEl.textContent = `${snap.lap}/${snap.totalLaps}`;
      this.timeValEl.textContent = formatRaceTime(snap.raceTimeSec);
      this.bestValEl.textContent =
        snap.bestLapSec > 0 ? formatRaceTime(snap.bestLapSec) : '--:--';
      this.speedValEl.textContent = String(snap.speedKmh);
      this.gearValEl.textContent = String(snap.gear);
      const redline = snap.rpmRatio > 0.88 && snap.speedKmh > 35;
      this.gearValEl.classList.toggle('gear-redline', redline);
      this.rpmBarEl.style.width = `${Math.round(snap.rpmRatio * 100)}%`;
      this.nitroBarEl.style.width = `${Math.round(snap.nitroRatio * 100)}%`;
      this.nitroBarEl.classList.toggle('nitro-active', snap.nitroActive);
      this.offTrackEl.classList.toggle('hidden', !snap.offTrack);
      this.wrongWayEl.classList.toggle('hidden', !snap.wrongWay);

      // Upcoming sharp corner pace warning
      if (snap.upcomingTurn !== this.prevTurn) {
        this.prevTurn = snap.upcomingTurn;
        if (snap.mode === 'race' && snap.upcomingTurn !== 'none') {
          const meta = TURN_META[snap.upcomingTurn];
          this.turnArrowEl.textContent = meta.arrow;
          this.turnLabelEl.textContent = meta.label;
          this.turnWarnEl.classList.toggle('turn-hot', meta.hot);
          this.turnWarnEl.classList.remove('hidden');
        } else {
          this.turnWarnEl.classList.add('hidden');
        }
      } else if (snap.mode !== 'race') {
        this.turnWarnEl.classList.add('hidden');
      }

      // Live Slipstream / Drift active indicator
      if (snap.mode === 'race' && (snap.drifting || snap.drafting)) {
        const parts: string[] = [];
        if (snap.drafting) parts.push('SLIPSTREAM +AERO');
        if (snap.drifting) parts.push(`DRIFT ${snap.driftScore} PTS`);
        this.statusStripEl.textContent = parts.join('  ·  ');
        this.statusStripEl.classList.toggle('status-drift', snap.drifting);
        this.statusStripEl.classList.remove('hidden');
      } else {
        this.statusStripEl.classList.add('hidden');
      }

      // Transient Lap / Best Lap / Drift Boost banner
      if (snap.bannerText) {
        this.bannerEl.textContent = snap.bannerText;
        this.bannerEl.dataset.tone = snap.bannerTone;
        this.bannerEl.classList.remove('hidden');
      } else {
        this.bannerEl.classList.add('hidden');
      }

      if (snap.mode === 'count') {
        const n = Math.ceil(snap.countdownSec);
        this.countdownEl.textContent = n > 0 ? String(n) : 'GO!';
        this.countdownEl.classList.remove('hidden');
      } else if (snap.raceTimeSec < 0.9) {
        this.countdownEl.textContent = 'GO!';
        this.countdownEl.classList.remove('hidden');
      } else {
        this.countdownEl.classList.add('hidden');
      }
    }
  }

  private renderResults(snap: HudSnapshot) {
    this.resultHeadlineEl.textContent =
      snap.position === 1
        ? 'Victory · 1st Place'
        : `${formatOrdinal(snap.position)} Place Finish`;
    const bestLabel =
      snap.playerBestLapSec > 0 ? formatRaceTime(snap.playerBestLapSec) : '--:--';
    const driftStr =
      snap.playerDriftTotal > 0 ? ` · Drift ${snap.playerDriftTotal} pts` : '';
    this.resultMetaEl.textContent = `${DIFFICULTY_SPECS[snap.difficulty].label} · Finish ${formatRaceTime(snap.playerFinishTimeSec)} · Best Lap ${bestLabel} · Top ${snap.playerTopSpeedKmh} km/h${driftStr}`;

    this.resultRowsEl.innerHTML = snap.standings
      .map((s, idx) => {
        const timeStr = s.finishTimeSec
          ? formatRaceTime(s.finishTimeSec)
          : 'Racing';
        return `
          <div class="standing-row ${s.isPlayer ? 'is-player' : ''}">
            <span class="st-pos">${formatOrdinal(idx + 1)}</span>
            <span class="st-swatch" style="background:${s.swatch}"></span>
            <span class="st-name">${s.name}${s.isPlayer ? ' (You)' : ''}</span>
            <span class="st-time mono">${timeStr}</span>
          </div>
        `;
      })
      .join('');
  }
}
