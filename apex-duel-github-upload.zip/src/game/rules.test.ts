import test from 'node:test';
import assert from 'node:assert/strict';
import {
  applyWallBounce,
  clampDt,
  computeAiControl,
  computeGearAndRpm,
  createCarState,
  driveCar,
  formatOrdinal,
  formatRaceTime,
  getStandings,
  getUpcomingTurn,
  isInSlipstream,
  isWrongWay,
  locateOnTrack,
  placeCar,
  resolveCollision,
  TRACK,
  WALL,
} from './rules';

test('track spline forms a continuous closed circuit with unit normals', () => {
  assert.ok(TRACK.N > 200);
  const firstToLast = Math.hypot(
    TRACK.x[0] - TRACK.x[TRACK.N - 1],
    TRACK.z[0] - TRACK.z[TRACK.N - 1]
  );
  assert.ok(firstToLast < 6);
  for (let i = 0; i < TRACK.N; i += 25) {
    const len = Math.hypot(TRACK.nx[i], TRACK.nz[i]);
    assert.ok(Math.abs(len - 1) < 1e-4);
  }
});

test('driveCar accelerates, activates nitro at speed, and triggers braking state', () => {
  const car = createCarState('sup');
  placeCar(car, 0, 0);

  for (let i = 0; i < 60; i++) {
    driveCar(car, { st: 0, th: 1, br: 0, hb: 0, nt: 0 }, 1 / 60);
  }
  assert.ok(car.s > 14);
  const baseSpeed = car.s;

  // Activate nitro above 7 m/s while on throttle
  const nitroBefore = car.nitro;
  driveCar(car, { st: 0, th: 1, br: 0, hb: 0, nt: 1 }, 1 / 60);
  assert.equal(car.nitroActive, true);
  assert.ok(car.nitro < nitroBefore);
  assert.ok(car.s >= baseSpeed);

  // Braking sets brakingActive and slows down
  driveCar(car, { st: 0, th: 0, br: 1, hb: 0, nt: 0 }, 1 / 60);
  assert.equal(car.brakingActive, true);
  assert.ok(car.s < baseSpeed);
});

test('locateOnTrack detects forward and backward start/finish line crossings', () => {
  const car = createCarState('bug');
  placeCar(car, TRACK.N - 2, 0);
  car.lap = 0;

  car.x = TRACK.x[2];
  car.z = TRACK.z[2];
  const evForward = locateOnTrack(car);
  assert.equal(evForward, 1);
  assert.equal(car.lap, 1);

  car.x = TRACK.x[TRACK.N - 2];
  car.z = TRACK.z[TRACK.N - 2];
  const evBack = locateOnTrack(car);
  assert.equal(evBack, -1);
  assert.equal(car.lap, 0);
});

test('resolveCollision separates overlapping cars and transfers impulse', () => {
  const a = createCarState('sup');
  const b = createCarState('bug');
  placeCar(a, 10, 0);
  placeCar(b, 10, 0);
  b.x = a.x + 0.6;
  a.vx = 18;
  b.vx = -6;

  const impact = resolveCollision(a, b);
  assert.ok(impact > 0);
  assert.ok(Math.hypot(a.x - b.x, a.z - b.z) > 0.6);
});

test('applyWallBounce clamps car inside barrier perimeter', () => {
  const car = createCarState('sup');
  placeCar(car, 20, WALL + 3);
  car.vx = TRACK.nx[20] * 12;
  car.vz = TRACK.nz[20] * 12;

  const impact = applyWallBounce(car);
  assert.ok(impact > 0);
  assert.ok(Math.abs(car.lat) <= WALL + 1e-6);
});

test('getStandings prioritizes finished times, then track progress', () => {
  const p1 = createCarState('sup');
  const p2 = createCarState('bug');
  const p3 = createCarState('supn');
  p1.fin = 95.4;
  p2.fin = 91.2;
  p3.prog = 999;

  const ordered = getStandings([p1, p2, p3]);
  assert.deepEqual(
    ordered.map((c) => c.id),
    ['bug', 'sup', 'supn']
  );
});

test('computeAiControl slows down for tight corners and uses nitro on clear straights', () => {
  const aiCar = createCarState('sup');
  let minIdx = 0;
  let minAheadMax = Infinity;
  let maxIdx = 0;
  for (let i = 0; i < TRACK.N; i++) {
    let aheadMax = 0;
    for (let d = 3; d <= 22; d += 2) {
      aheadMax = Math.max(aheadMax, TRACK.ka[(i + d) % TRACK.N]);
    }
    if (aheadMax < minAheadMax) {
      minAheadMax = aheadMax;
      minIdx = i;
    }
    if (TRACK.ka[i] > TRACK.ka[maxIdx]) maxIdx = i;
  }

  placeCar(aiCar, minIdx, 0);
  aiCar.vx = Math.sin(aiCar.h) * 32;
  aiCar.vz = Math.cos(aiCar.h) * 32;
  aiCar.s = 32;
  const straightCmd = computeAiControl(aiCar, [aiCar], 1, 1, 1 / 60);
  assert.ok(straightCmd.th > 0.7);
  assert.equal(straightCmd.nt, 1);

  placeCar(aiCar, maxIdx, 0);
  aiCar.vx = Math.sin(aiCar.h) * 65;
  aiCar.vz = Math.cos(aiCar.h) * 65;
  aiCar.s = 65;
  const cornerCmd = computeAiControl(aiCar, [aiCar], 1, 1, 1 / 60);
  assert.ok(cornerCmd.br > 0);
  assert.equal(cornerCmd.nt, 0);
});

test('telemetry helpers clamp dt, compute gears, and format labels', () => {
  assert.equal(clampDt(0.4), 0.05);
  assert.equal(clampDt(-1), 0.016);
  const g1 = computeGearAndRpm(5, 72);
  const g6 = computeGearAndRpm(70, 72);
  assert.equal(g1.gear, 1);
  assert.equal(g6.gear, 6);
  assert.equal(formatRaceTime(65.34), '1:05.34');
  assert.equal(formatOrdinal(1), '1st');
});

test('computeAiControl picks an open overtake lane when blocked by slower lead car', () => {
  const ai = createCarState('sup');
  const blocker = createCarState('bug');
  placeCar(ai, 5, 0);
  ai.s = 36;
  ai.vx = Math.sin(ai.h) * 36;
  ai.vz = Math.cos(ai.h) * 36;

  // Place slower blocker directly ahead at +10m and another car on the left lane
  placeCar(blocker, 8, 0);
  blocker.s = 18;
  const leftCar = createCarState('supl');
  placeCar(leftCar, 7, -4.5);

  computeAiControl(ai, [ai, blocker, leftCar], 1, 1, 1 / 60);
  assert.equal(ai.avoidSide, 1);
  assert.ok(ai.avoidTimer > 0);
});

test('isInSlipstream detects drafting behind a lead car and boosts speed/nitro', () => {
  const chaser = createCarState('sup');
  const leader = createCarState('bug');
  placeCar(chaser, 10, 0);
  placeCar(leader, 14, 0);
  chaser.s = 40;
  chaser.vx = Math.sin(chaser.h) * 40;
  chaser.vz = Math.cos(chaser.h) * 40;
  leader.s = 38;
  leader.vx = Math.sin(leader.h) * 38;
  leader.vz = Math.cos(leader.h) * 38;

  assert.equal(isInSlipstream(chaser, [chaser, leader]), true);

  chaser.nitro = 50;
  driveCar(chaser, { st: 0, th: 1, br: 0, hb: 0, nt: 0 }, 0.25, true);
  assert.equal(chaser.draftingActive, true);
  assert.ok(chaser.nitro > 52);
});

test('sustained drift accumulates score, charges nitro, and triggers drift-exit boost', () => {
  const car = createCarState('sup');
  placeCar(car, 10, 0);
  car.s = 36;
  car.vx = Math.sin(car.h) * 36;
  car.vz = Math.cos(car.h) * 36;
  car.nitro = 40;

  for (let i = 0; i < 45; i++) {
    driveCar(car, { st: 0.7, th: 1, br: 0, hb: 1, nt: 0 }, 1 / 60, false);
  }
  assert.equal(car.driftingActive, true);
  assert.ok(car.driftScore > 20);
  assert.ok(car.nitro > 45);

  // Straighten out smoothly: lateral slip fades and triggers driftBoostTimer
  car.vx = Math.sin(car.h) * 35;
  car.vz = Math.cos(car.h) * 35;
  driveCar(car, { st: 0, th: 1, br: 0, hb: 0, nt: 0 }, 1 / 60, false);
  assert.ok(car.driftBoostTimer > 0.5);
  assert.equal(car.nitroActive, true);
});

test('isWrongWay and getUpcomingTurn detect reverse driving and sharp corners', () => {
  const car = createCarState('bug');
  placeCar(car, 20, 0);
  car.s = 20;
  assert.equal(isWrongWay(car), false);

  car.h += Math.PI;
  assert.equal(isWrongWay(car), true);

  let foundCorner = false;
  for (let i = 0; i < TRACK.N; i += 5) {
    if (getUpcomingTurn(i) !== 'none') {
      foundCorner = true;
      break;
    }
  }
  assert.equal(foundCorner, true);
});
