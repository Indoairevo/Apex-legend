import {
  CarState,
  CarVariant,
  CarVariantId,
  ControlInput,
  Difficulty,
  TrackData,
  TurnSeverity,
} from './types';

export const TAU = Math.PI * 2;
export const HW = 9;
export const LAPS = 3;
export const TS = 1.05;
export const WALL = HW + 7;
export const NCH = 14;

export function clamp(v: number, a: number, b: number): number {
  return v < a ? a : v > b ? b : v;
}

export function clampDt(rawDt: number): number {
  if (!Number.isFinite(rawDt) || rawDt <= 0) return 0.016;
  return Math.min(rawDt, 0.05);
}

export function wrapAngle(a: number): number {
  let r = a;
  while (r > Math.PI) r -= TAU;
  while (r < -Math.PI) r += TAU;
  return r;
}

export const CAR_VARIANTS: Record<CarVariantId, CarVariant> = {
  sup: {
    id: 'sup',
    model: 'sup',
    name: 'Toyota GR Supra GT300',
    acc: 25,
    vmax: 72,
    brake: 36,
    grip: 8,
    turn: 2.2,
    al: 31,
    sw: '#eceef0',
  },
  supn: {
    id: 'supn',
    model: 'sup',
    name: 'Supra GT300 · Night Run',
    acc: 24,
    vmax: 74,
    brake: 36,
    grip: 7.6,
    turn: 2.1,
    al: 31,
    sw: '#ff7a00',
    tint: { w: [24, 24, 30], r: [255, 122, 0] },
  },
  supl: {
    id: 'supl',
    model: 'sup',
    name: 'Supra GT300 · Hyper Lime',
    acc: 26,
    vmax: 70,
    brake: 37,
    grip: 8.4,
    turn: 2.3,
    al: 30,
    sw: '#9be82a',
    tint: { w: [150, 235, 40], r: [22, 22, 26] },
  },
  bug: {
    id: 'bug',
    model: 'bug',
    name: 'Bugatti EB110 SS',
    acc: 23,
    vmax: 82,
    brake: 32,
    grip: 6.5,
    turn: 2,
    al: 29,
    sw: '#183e96',
  },
  bugr: {
    id: 'bugr',
    model: 'bug',
    name: 'EB110 SS · Rosso Corsa',
    acc: 24,
    vmax: 81,
    brake: 32,
    grip: 6.4,
    turn: 2,
    al: 29,
    sw: '#c4161c',
    tint: { p: [196, 22, 28] },
  },
  bugy: {
    id: 'bugy',
    model: 'bug',
    name: 'EB110 SS · Giallo',
    acc: 22,
    vmax: 84,
    brake: 31,
    grip: 6.2,
    turn: 1.95,
    al: 28.5,
    sw: '#f2bb14',
    tint: { p: [246, 190, 20] },
  },
};

export const CAR_IDS = Object.keys(CAR_VARIANTS) as CarVariantId[];

export function getCarStats(c: CarVariant): [number, number, number] {
  return [c.vmax / 84, c.acc / 27, (c.al + c.grip * 2) / 47].map((v) =>
    Math.round(Math.min(1, v) * 100)
  ) as [number, number, number];
}

export const DIFFICULTY_SPECS: Record<
  Difficulty,
  { label: string; mult: number }
> = {
  rookie: { label: 'ROOKIE', mult: 0.91 },
  pro: { label: 'PRO', mult: 1.0 },
  legend: { label: 'LEGEND', mult: 1.105 },
};

export const TRACK: TrackData = (() => {
  const controlPts: Array<[number, number]> = [
    [0, 0],
    [220, 0],
    [420, -30],
    [560, 60],
    [600, 200],
    [520, 310],
    [380, 330],
    [300, 250],
    [310, 150],
    [220, 100],
    [100, 160],
    [60, 290],
    [-60, 360],
    [-220, 330],
    [-300, 220],
    [-260, 90],
    [-140, 30],
  ].map((p) => [p[0] * TS, p[1] * TS]);

  const n = controlPts.length;
  const d: Array<[number, number]> = [];
  for (let i = 0; i < n; i++) {
    const a = controlPts[(i + n - 1) % n];
    const b = controlPts[i];
    const c = controlPts[(i + 1) % n];
    const e = controlPts[(i + 2) % n];
    for (let k = 0; k < 30; k++) {
      const t = k / 30;
      const t2 = t * t;
      const t3 = t2 * t;
      const f = (j: 0 | 1) =>
        0.5 *
        (2 * b[j] +
          (c[j] - a[j]) * t +
          (2 * a[j] - 5 * b[j] + 4 * c[j] - e[j]) * t2 +
          (3 * b[j] - a[j] - 3 * c[j] + e[j]) * t3);
      d.push([f(0), f(1)]);
    }
  }

  const m = d.length;
  const cumLen = [0];
  for (let i = 0; i < m; i++) {
    const p = d[i];
    const q = d[(i + 1) % m];
    cumLen.push(cumLen[i] + Math.hypot(q[0] - p[0], q[1] - p[1]));
  }

  const len = cumLen[m];
  const N = Math.round(len / 3.5);
  const x: number[] = [];
  const z: number[] = [];
  let j = 0;
  for (let i = 0; i < N; i++) {
    const s = (i * len) / N;
    while (cumLen[j + 1] < s) j++;
    const u = (s - cumLen[j]) / (cumLen[j + 1] - cumLen[j]);
    const p = d[j];
    const q = d[(j + 1) % m];
    x.push(p[0] + (q[0] - p[0]) * u);
    z.push(p[1] + (q[1] - p[1]) * u);
  }

  const h: number[] = [];
  const nx: number[] = [];
  const nz: number[] = [];
  const k: number[] = [];
  const ds = len / N;
  const ka: number[] = [];

  for (let i = 0; i < N; i++) {
    const a = (i + N - 1) % N;
    const b = (i + 1) % N;
    const tx = x[b] - x[a];
    const tz = z[b] - z[a];
    const l = Math.hypot(tx, tz);
    h.push(Math.atan2(tx, tz));
    nx.push(tz / l);
    nz.push(-tx / l);
  }

  for (let i = 0; i < N; i++) {
    k.push(Math.abs(wrapAngle(h[(i + 1) % N] - h[(i + N - 1) % N])) / (2 * ds));
  }

  for (let i = 0; i < N; i++) {
    let q = 0;
    for (let s = 0; s < 32; s++) {
      q = Math.max(q, k[(i + s) % N]);
    }
    ka.push(q);
  }

  return { N, x, z, h, nx, nz, ka, len };
})();

export const CHUNK_SIZE = Math.ceil(TRACK.N / NCH);

export function createCarState(id: CarVariantId): CarState {
  return {
    id,
    c: CAR_VARIANTS[id],
    x: 0,
    z: 0,
    h: 0,
    vx: 0,
    vz: 0,
    s: 0,
    steer: 0,
    idx: 0,
    lap: -1,
    lat: 0,
    ls: 0,
    fin: 0,
    best: 0,
    last: 0,
    lane: 0,
    baseLane: 0,
    avoidSide: 0,
    avoidTimer: 0,
    prog: 0,
    off: 0,
    spin: 0,
    sk: 1,
    nitro: 100,
    nitroActive: false,
    brakingActive: false,
    draftingActive: false,
    driftingActive: false,
    driftCharge: 0,
    driftScore: 0,
    driftBoostTimer: 0,
    skidClock: 0,
    topSpeedKmh: 0,
  };
}

export function placeCar(c: CarState, idx: number, lat: number) {
  const safeIdx = ((idx % TRACK.N) + TRACK.N) % TRACK.N;
  c.idx = safeIdx;
  c.x = TRACK.x[safeIdx] + TRACK.nx[safeIdx] * lat;
  c.z = TRACK.z[safeIdx] + TRACK.nz[safeIdx] * lat;
  c.h = TRACK.h[safeIdx];
  c.vx = 0;
  c.vz = 0;
  c.s = 0;
  c.steer = 0;
  c.lat = lat;
  c.draftingActive = false;
  c.driftingActive = false;
  c.driftCharge = 0;
  c.driftBoostTimer = 0;
  c.prog = c.lap * TRACK.N + safeIdx;
}

export function locateOnTrack(c: CarState): number {
  let bestDistSq = 1e18;
  let bestIdx = c.idx;
  for (let j = -14; j <= 14; j++) {
    const i = (c.idx + j + TRACK.N) % TRACK.N;
    const dx = c.x - TRACK.x[i];
    const dz = c.z - TRACK.z[i];
    const q = dx * dx + dz * dz;
    if (q < bestDistSq) {
      bestDistSq = q;
      bestIdx = i;
    }
  }
  const prevIdx = c.idx;
  c.idx = bestIdx;
  c.lat =
    (c.x - TRACK.x[bestIdx]) * TRACK.nx[bestIdx] +
    (c.z - TRACK.z[bestIdx]) * TRACK.nz[bestIdx];

  let ev = 0;
  if (prevIdx > TRACK.N * 0.8 && bestIdx < TRACK.N * 0.2) {
    c.lap++;
    ev = 1;
  } else if (prevIdx < TRACK.N * 0.2 && bestIdx > TRACK.N * 0.8) {
    c.lap--;
    ev = -1;
  }
  c.prog = c.lap * TRACK.N + bestIdx;
  return ev;
}

/**
 * Checks whether a car is currently tucked inside another active car's
 * aerodynamic slipstream cone (4..28m behind, <2.6m lateral offset, >22 m/s).
 */
export function isInSlipstream(car: CarState, allCars: CarState[]): boolean {
  if (car.s < 22 || car.off) return false;
  const fx = Math.sin(car.h);
  const fz = Math.cos(car.h);
  const rx = fz;
  const rz = -fx;
  for (const o of allCars) {
    if (o === car || o.fin || o.s < 18) continue;
    const dx = o.x - car.x;
    const dz = o.z - car.z;
    const forward = dx * fx + dz * fz;
    if (forward < 4.0 || forward > 28.0) continue;
    const lat = Math.abs(dx * rx + dz * rz);
    if (lat < 2.6) {
      return true;
    }
  }
  return false;
}

/**
 * Detects whether a car is travelling backwards relative to track direction.
 */
export function isWrongWay(car: CarState): boolean {
  if (car.s < 4.5) return false;
  const tx = Math.sin(TRACK.h[car.idx]);
  const tz = Math.cos(TRACK.h[car.idx]);
  const fx = Math.sin(car.h);
  const fz = Math.cos(car.h);
  return fx * tx + fz * tz < -0.35;
}

/**
 * Looks ahead along the spline to provide rally/GT-style cornering pace warnings.
 */
export function getUpcomingTurn(idx: number): TurnSeverity {
  const N = TRACK.N;
  let totalTurn = 0;
  let peakCurv = 0;
  for (let d = 14; d <= 44; d += 2) {
    const i = (idx + d) % N;
    const dh = wrapAngle(TRACK.h[(i + 2) % N] - TRACK.h[(i + N - 2) % N]);
    totalTurn += dh;
    if (TRACK.ka[i] > peakCurv) peakCurv = TRACK.ka[i];
  }
  if (peakCurv < 0.0082 || Math.abs(totalTurn) < 0.36) return 'none';
  // Note: heading angle increases counter-clockwise in XZ (+x right, +z forward -> atan2(dx, dz))
  // Positive dh = turning LEFT; negative dh = turning RIGHT
  const isLeft = totalTurn > 0;
  if (peakCurv > 0.0138 || Math.abs(totalTurn) > 1.05) {
    return isLeft ? 'hairpin-left' : 'hairpin-right';
  }
  return isLeft ? 'left' : 'right';
}

export function driveCar(
  c: CarState,
  u: ControlInput,
  dt: number,
  inSlipstream = false
) {
  const k = c.c;
  let fx = Math.sin(c.h);
  let fz = Math.cos(c.h);
  let s = c.vx * fx + c.vz * fz;

  c.steer += (u.st - c.steer) * Math.min(1, dt * 9);
  c.off = Math.abs(c.lat) > HW + 1.5 ? 1 : 0;
  c.draftingActive = inSlipstream && !c.off && s > 22 && u.th > 0.1;

  // Drift detection & drift-exit turbo surge
  const latVelMag = Math.abs(c.vx * fz - c.vz * fx);
  const driftingNow = !c.off && s > 15 && (u.hb > 0 || latVelMag > 4.4);
  if (driftingNow) {
    c.driftingActive = true;
    c.driftCharge = Math.min(2.4, c.driftCharge + dt);
    c.driftScore += Math.round((s * 1.4 + latVelMag * 5.2) * dt);
  } else {
    if (c.driftingActive && c.driftCharge >= 0.55) {
      // Reward sustained drift exit with a crisp 0.9s momentum boost!
      c.driftBoostTimer = Math.max(c.driftBoostTimer, 0.85);
    }
    c.driftingActive = false;
    c.driftCharge = Math.max(0, c.driftCharge - dt * 2.5);
  }
  if (c.driftBoostTimer > 0) {
    c.driftBoostTimer = Math.max(0, c.driftBoostTimer - dt);
  }

  const boostOn = !!u.nt && c.nitro > 0 && s > 7 && u.th > 0.05 && !c.off;
  const nitroRate = boostOn
    ? -31
    : (driftingNow ? 16 : 4.5) + (c.draftingActive ? 8.5 : 0);
  c.nitro = clamp(c.nitro + nitroRate * dt, 0, 100);
  c.nitroActive = boostOn || c.driftBoostTimer > 0.05;
  c.brakingActive = u.br > 0.12 && s > 2;

  const aeroMult = c.draftingActive ? 1.065 : 1.0;
  const boostMult = boostOn ? 1.23 : c.driftBoostTimer > 0.05 ? 1.11 : 1.0;
  const vm = k.vmax * (c.off ? 0.5 : 1) * boostMult * aeroMult;

  let a = 0;
  if (u.th > 0 && s < vm) {
    const powerBoost = boostOn ? 1.18 : c.driftBoostTimer > 0.05 ? 1.12 : 1.0;
    a += k.acc * u.th * (1 - (s / vm) * (s / vm)) * powerBoost * aeroMult;
  }
  if (u.br > 0) {
    a -= s > 1 ? k.brake * u.br : s > -12 ? k.acc * 0.5 * u.br : 0;
  }
  a -= Math.sign(s) * (1.2 + 0.0006 * s * s + (c.off ? 10 : 0));
  s += a * dt;
  if (Math.abs(s) < 0.05 && !u.th && !u.br) s = 0;

  const w = Math.min(
    k.turn * clamp(Math.abs(s) / 9, 0, 1),
    (1.15 * k.al) / Math.max(Math.abs(s), 1)
  );
  c.h += c.steer * w * Math.sign(s) * (u.hb ? 1.32 : 1) * dt;

  fx = Math.sin(c.h);
  fz = Math.cos(c.h);
  const so = c.vx * fx + c.vz * fz;
  let lx = c.vx - fx * so;
  let lz = c.vz - fz * so;
  const g = Math.max(0, 1 - (u.hb ? k.grip * 0.2 : k.grip) * dt);
  lx *= g;
  lz *= g;

  c.vx = fx * s + lx;
  c.vz = fz * s + lz;
  c.s = s;
  c.x += c.vx * dt;
  c.z += c.vz * dt;
  c.spin += s * dt;
  const kmh = Math.round(Math.abs(s) * 3.6);
  if (kmh > c.topSpeedKmh) c.topSpeedKmh = kmh;
}

export function resolveCollision(a: CarState, b: CarState): number {
  const pp = [-1.4, 1.4];
  const radius = 2.15;
  let maxImpact = 0;
  for (const ua of pp) {
    for (const ub of pp) {
      const ax = a.x + Math.sin(a.h) * ua;
      const az = a.z + Math.cos(a.h) * ua;
      const bx = b.x + Math.sin(b.h) * ub;
      const bz = b.z + Math.cos(b.h) * ub;
      let dx = ax - bx;
      let dz = az - bz;
      const d = Math.hypot(dx, dz);
      if (d >= radius || d < 1e-4) continue;
      dx /= d;
      dz /= d;
      const overlap = (radius - d) / 2;
      a.x += dx * overlap;
      a.z += dz * overlap;
      b.x -= dx * overlap;
      b.z -= dz * overlap;
      const rv = (a.vx - b.vx) * dx + (a.vz - b.vz) * dz;
      if (rv < 0) {
        maxImpact = Math.max(maxImpact, Math.abs(rv));
        const j = rv * 0.6;
        a.vx -= j * dx;
        a.vz -= j * dz;
        b.vx += j * dx;
        b.vz += j * dz;
      }
    }
  }
  return maxImpact;
}

export function applyWallBounce(c: CarState): number {
  const i = c.idx;
  const l = c.lat;
  let impact = 0;
  if (Math.abs(l) > WALL) {
    const g = Math.sign(l);
    const o = Math.abs(l) - WALL;
    c.x -= TRACK.nx[i] * g * o;
    c.z -= TRACK.nz[i] * g * o;
    c.lat = g * WALL;
    const vo = (c.vx * TRACK.nx[i] + c.vz * TRACK.nz[i]) * g;
    if (vo > 0) {
      impact = vo;
      c.vx -= TRACK.nx[i] * g * vo * 1.25;
      c.vz -= TRACK.nz[i] * g * vo * 1.25;
    }
    c.vx *= 0.985;
    c.vz *= 0.985;
  }
  return impact;
}

export function recoverCar(c: CarState) {
  const i = c.idx;
  c.x = TRACK.x[i];
  c.z = TRACK.z[i];
  c.h = TRACK.h[i];
  c.vx = 0;
  c.vz = 0;
  c.s = 0;
  c.lat = 0;
  c.driftCharge = 0;
  c.driftingActive = false;
}

export function computeAiControl(
  c: CarState,
  allCars: CarState[],
  skill: number,
  boost: number,
  dt = 1 / 60
): ControlInput {
  const k = c.c;
  const s = Math.max(0, c.s);
  const N = TRACK.N;
  const look = clamp(8 + Math.abs(s) * 0.14, 9, 20);
  const ti = (c.idx + Math.round(look)) % N;

  // Scan ahead for peak corner curvature (for braking) & near-turn curvature (for apex line)
  let curve = 0;
  let turn = 0;
  let nearCurve = 0;
  let nearTurn = 0;
  for (let d = 3; d <= look + 12; d += 2) {
    const i = (c.idx + d) % N;
    const v = TRACK.ka[i];
    const tDir = wrapAngle(TRACK.h[(i + 2) % N] - TRACK.h[(i + N - 2) % N]);
    if (v > curve) {
      curve = v;
      turn = tDir;
    }
    if (d <= 12 && v > nearCurve) {
      nearCurve = v;
      nearTurn = tDir;
    }
  }

  // Detect cars ahead for drafting & overtaking
  let lead: CarState | null = null;
  let leadForward = 1e9;
  let draftCandidate: CarState | null = null;
  const mySin = Math.sin(c.h);
  const myCos = Math.cos(c.h);
  const myLateral =
    (c.x - TRACK.x[c.idx]) * TRACK.nx[c.idx] +
    (c.z - TRACK.z[c.idx]) * TRACK.nz[c.idx];

  for (const o of allCars) {
    if (o === c || o.fin) continue;
    const dx = o.x - c.x;
    const dz = o.z - c.z;
    const forward = dx * mySin + dz * myCos;
    if (forward < 1.2 || forward > 34) continue;
    const lateral =
      (o.x - TRACK.x[c.idx]) * TRACK.nx[c.idx] +
      (o.z - TRACK.z[c.idx]) * TRACK.nz[c.idx];
    const latDiff = Math.abs(lateral - myLateral);

    if (forward >= 4 && forward <= 26 && latDiff < 2.5) {
      draftCandidate = o;
    }
    if (latDiff < 4.9 && forward < leadForward) {
      lead = o;
      leadForward = forward;
    }
  }

  // Multi-car overtake lane scoring
  if (lead && (c.avoidTimer <= 0 || leadForward < 10)) {
    const scoreLane = (candidate: number) => {
      let score = HW - 1.6 - Math.abs(candidate) * 0.7;
      if (nearCurve > 0.004 && Math.sign(candidate) === Math.sign(nearTurn)) {
        score += 2.2;
      }
      for (const o of allCars) {
        if (o === c || o.fin) continue;
        const dx = o.x - c.x;
        const dz = o.z - c.z;
        const forward = dx * mySin + dz * myCos;
        if (forward > -4.5 && forward < 30) {
          const lateral =
            (o.x - TRACK.x[c.idx]) * TRACK.nx[c.idx] +
            (o.z - TRACK.z[c.idx]) * TRACK.nz[c.idx];
          const gap = Math.abs(lateral - candidate);
          if (gap < 4.5) {
            const urgency = 1 - clamp(forward, 0, 32) / 36;
            score -= (4.5 - gap) * 2.5 * urgency;
          }
        }
      }
      return score;
    };
    const left = scoreLane(-4.6);
    const center = scoreLane(0);
    const right = scoreLane(4.6);
    if (left >= right && left >= center) {
      c.avoidSide = -1;
    } else if (right >= left && right >= center) {
      c.avoidSide = 1;
    } else {
      c.avoidSide = Math.sign(-myLateral) || 1;
    }
    c.avoidTimer = 1.25;
  }

  // Optimal racing line: swing slightly wide on entry, clip inside apex at peak curvature
  let laneGoal = c.baseLane ?? c.lane;
  if (nearCurve > 0.0032) {
    laneGoal = Math.sign(nearTurn) * clamp(nearCurve * 260, 1.5, HW - 2.3);
  } else if (curve > 0.0045) {
    laneGoal = -Math.sign(turn) * clamp(curve * 180, 1.2, HW - 3.2);
  }

  if (c.avoidTimer > 0) {
    laneGoal = c.avoidSide * 4.4;
    c.avoidTimer = Math.max(0, c.avoidTimer - dt);
  }
  if (Math.abs(c.lat) > HW - 2.0) {
    laneGoal = clamp(-c.lat * 0.6, -2.5, 2.5);
  }
  laneGoal = clamp(laneGoal, -HW + 1.9, HW - 1.9);
  c.lane += (laneGoal - c.lane) * Math.min(1, dt * (c.avoidTimer > 0 ? 3.8 : 2.6));

  const tx = TRACK.x[ti] + TRACK.nx[ti] * c.lane;
  const tz = TRACK.z[ti] + TRACK.nz[ti] * c.lane;
  const e = wrapAngle(Math.atan2(tx - c.x, tz - c.z) - c.h);

  const slipstreamMult = draftCandidate && curve < 0.003 ? 1.055 : 1.0;

  let vt = Math.min(
    k.vmax * skill * boost * slipstreamMult,
    Math.sqrt((k.al * 0.94) / (curve + 1e-4))
  );
  if (lead && leadForward < 12 && c.avoidTimer <= 0.1) {
    vt = Math.min(vt, Math.max(lead.s - 1.2, 20));
  }
  if (c.off) vt = Math.min(vt, 27);

  const steerAngleAbs = Math.abs(e);
  if (steerAngleAbs > 0.45 && s > 24) {
    vt = Math.min(vt, 30);
  }

  const steering = clamp(e * 2.75, -1, 1);
  const throttle = clamp((vt - s + 1.8) / 6.5, 0, 1);
  const useNitro =
    c.nitro > 34 &&
    curve < 0.0025 &&
    s > 22 &&
    (!lead || leadForward > 16 || c.avoidTimer > 0.25) &&
    throttle > 0.15;

  return {
    st: steering,
    th: throttle,
    br: clamp((s - vt - 0.8) / 7.5, 0, 1),
    hb: 0,
    nt: useNitro ? 1 : 0,
  };
}

export function getStandings(allCars: CarState[]): CarState[] {
  return allCars
    .slice()
    .sort((a, b) =>
      a.fin && b.fin ? a.fin - b.fin : a.fin ? -1 : b.fin ? 1 : b.prog - a.prog
    );
}

export function getPlayerPosition(allCars: CarState[], player: CarState): number {
  return getStandings(allCars).indexOf(player) + 1;
}

export function computeGearAndRpm(speedMs: number, vmaxMs: number): {
  gear: number;
  rpmRatio: number;
} {
  const absSpeed = Math.abs(speedMs);
  const band = Math.max(1, vmaxMs / 6);
  const gear = clamp(Math.floor(absSpeed / band) + 1, 1, 6);
  const rpmPhase = (absSpeed / band) % 1;
  const rpmRatio = clamp(
    0.18 + (gear === 6 && absSpeed > vmaxMs ? 0.82 : rpmPhase * 0.78),
    0.18,
    1
  );
  return { gear, rpmRatio };
}

export function formatRaceTime(t: number): string {
  const m = Math.floor(t / 60);
  const s = t - m * 60;
  return `${m}:${s < 10 ? '0' : ''}${s.toFixed(2)}`;
}

export function formatOrdinal(n: number): string {
  return ['', '1st', '2nd', '3rd', '4th'][n] || `${n}th`;
}
