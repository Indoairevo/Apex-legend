export type GameMode = 'menu' | 'loading' | 'count' | 'race' | 'pause' | 'done';
export type BodyState = 'title' | 'playing' | 'paused' | 'gameover';
export type TimeOfDay = 'day' | 'sunset' | 'night';
export type Difficulty = 'rookie' | 'pro' | 'legend';
export type CameraMode = 0 | 1 | 2 | 3; // 0 = Chase, 1 = Close, 2 = Hood, 3 = Bumper
export type CarModelId = 'sup' | 'bug';
export type CarVariantId = 'sup' | 'supn' | 'supl' | 'bug' | 'bugr' | 'bugy';
export type TurnSeverity = 'none' | 'left' | 'right' | 'hairpin-left' | 'hairpin-right';

export interface CarTint {
  w?: [number, number, number];
  r?: [number, number, number];
  p?: [number, number, number];
}

export interface CarVariant {
  id: CarVariantId;
  model: CarModelId;
  name: string;
  acc: number;
  vmax: number;
  brake: number;
  grip: number;
  turn: number;
  al: number;
  sw: string;
  tint?: CarTint;
}

export interface ControlInput {
  st: number;
  th: number;
  br: number;
  hb: number;
  nt: number;
}

export interface CarState {
  id: CarVariantId;
  c: CarVariant;
  x: number;
  z: number;
  h: number;
  vx: number;
  vz: number;
  s: number;
  steer: number;
  idx: number;
  lap: number;
  lat: number;
  ls: number;
  fin: number;
  best: number;
  last: number;
  lane: number;
  baseLane: number;
  avoidSide: number;
  avoidTimer: number;
  prog: number;
  off: number;
  spin: number;
  sk: number;
  nitro: number;
  nitroActive: boolean;
  brakingActive: boolean;
  draftingActive: boolean;
  driftingActive: boolean;
  driftCharge: number;
  driftScore: number;
  driftBoostTimer: number;
  skidClock: number;
  topSpeedKmh: number;
}

export interface TrackData {
  N: number;
  x: number[];
  z: number[];
  h: number[];
  nx: number[];
  nz: number[];
  ka: number[];
  len: number;
}

export interface HudSnapshot {
  mode: GameMode;
  bodyState: BodyState;
  timeOfDay: TimeOfDay;
  difficulty: Difficulty;
  selectedCar: CarVariantId;
  cameraMode: CameraMode;
  muted: boolean;
  lap: number;
  totalLaps: number;
  position: number;
  totalCars: number;
  raceTimeSec: number;
  bestLapSec: number;
  recordLapSec: number;
  countdownSec: number;
  offTrack: boolean;
  wrongWay: boolean;
  drafting: boolean;
  drifting: boolean;
  driftScore: number;
  upcomingTurn: TurnSeverity;
  bannerText: string;
  bannerTone: 'info' | 'best' | 'boost';
  speedKmh: number;
  gear: number;
  rpmRatio: number;
  nitroRatio: number;
  nitroActive: boolean;
  loadProgress: number;
  loadText: string;
  standings: Array<{
    name: string;
    swatch: string;
    isPlayer: boolean;
    finishTimeSec: number;
    topSpeedKmh: number;
  }>;
  playerTopSpeedKmh: number;
  playerFinishTimeSec: number;
  playerBestLapSec: number;
  playerDriftTotal: number;
}
