import * as THREE from 'three';
import { ASSET } from './legacyAssets';
import { CarModelId, CarState, CarTint, CarVariant } from './types';

interface BinaryPartMeta {
  n: string;
  nv: number;
  ni: number;
  c?: [number, number, number];
  r?: number;
}

interface BinaryAssetHeader {
  parts: BinaryPartMeta[];
}

interface WheelRef {
  pivot: THREE.Group;
  mesh: THREE.Mesh;
  radius: number;
  isFront: boolean;
}

export interface CarVisual {
  root: THREE.Group;
  chassis: THREE.Group;
  wheels: WheelRef[];
  headlightGlowMat: THREE.SpriteMaterial;
  headlightBeamMat: THREE.MeshBasicMaterial;
  brakeGlowMat: THREE.SpriteMaterial;
  nitroGroup: THREE.Group;
  nitroCones: THREE.Mesh[];
  nitroGlow: THREE.Sprite;
  modelId: CarModelId;
  prevSpeed: number;
}

const LUT = new Float32Array(256);
for (let i = 0; i < 256; i++) {
  LUT[i] = Math.pow(i / 255, 2.2);
}

function align4(n: number): number {
  return (n + 3) & ~3;
}

function decodeBase64Bytes(b64: string): Uint8Array {
  const s = atob(b64);
  const b = new Uint8Array(s.length);
  for (let i = 0; i < s.length; i++) {
    b[i] = s.charCodeAt(i);
  }
  return b;
}

function recolorVertexColors(
  co: Uint8Array,
  tint: CarTint | undefined,
  model: CarModelId
) {
  if (!tint) return;
  for (let i = 0; i < co.length; i += 3) {
    const r = co[i];
    const g = co[i + 1];
    const b = co[i + 2];
    if (model === 'bug' && tint.p) {
      if (b > r * 1.7 && b > g * 1.35 && b > 50) {
        const lum = Math.min(1.15, b / 150);
        co[i] = Math.min(255, tint.p[0] * lum);
        co[i + 1] = Math.min(255, tint.p[1] * lum);
        co[i + 2] = Math.min(255, tint.p[2] * lum);
      }
    } else if (model === 'sup') {
      if (tint.r && r > 150 && g < 70 && b < 80) {
        co[i] = tint.r[0];
        co[i + 1] = tint.r[1];
        co[i + 2] = tint.r[2];
      } else if (tint.w && r > 200 && g > 200 && b > 200) {
        co[i] = tint.w[0];
        co[i + 1] = tint.w[1];
        co[i + 2] = tint.w[2];
      }
    }
  }
}

export interface CarVisualTextures {
  contactShadow: THREE.Texture;
  nitroGlow: THREE.Texture;
  headlightGlow: THREE.Texture;
  headlightBeam: THREE.Texture;
  brakeGlow: THREE.Texture;
}

export function buildCarVisual(
  variant: CarVariant,
  tex: CarVisualTextures,
  castShadows: boolean,
  simplifyPbr = false
): CarVisual {
  const b = decodeBase64Bytes(ASSET[variant.model]);
  const dv = new DataView(b.buffer);
  const headerLen = dv.getUint32(0, true);
  let p = 4;
  const header = JSON.parse(
    new TextDecoder().decode(b.subarray(p, p + headerLen))
  ) as BinaryAssetHeader;
  p += headerLen;

  const root = new THREE.Group();
  const chassis = new THREE.Group();
  root.add(chassis);

  // Studio-grade automotive clearcoat paint: balanced metalness preserves pure whites,
  // jet blacks, and vivid Rosso/Giallo/Lime liveries while catching crisp sky reflections.
  const bodyMat = simplifyPbr
    ? new THREE.MeshStandardMaterial({
        vertexColors: true,
        roughness: 0.28,
        metalness: 0.22,
        envMapIntensity: 0.68,
        side: THREE.DoubleSide,
      })
    : new THREE.MeshPhysicalMaterial({
        vertexColors: true,
        roughness: 0.2,
        metalness: 0.22,
        clearcoat: 1.0,
        clearcoatRoughness: 0.04,
        reflectivity: 0.96,
        envMapIntensity: 0.96,
        side: THREE.DoubleSide,
      });

  // Sleek dark-tinted GT300/supercar cockpit glass (deep contrast like hero renders)
  const glassMat = simplifyPbr
    ? new THREE.MeshStandardMaterial({
        color: 0x050a14,
        roughness: 0.05,
        metalness: 0.82,
        envMapIntensity: 1.3,
        transparent: true,
        opacity: 0.9,
        side: THREE.DoubleSide,
      })
    : new THREE.MeshPhysicalMaterial({
        color: 0x040912,
        roughness: 0.04,
        metalness: 0.68,
        clearcoat: 1.0,
        clearcoatRoughness: 0.03,
        reflectivity: 1.0,
        envMapIntensity: 1.55,
        transparent: true,
        opacity: 0.88,
        side: THREE.DoubleSide,
      });

  // Deep satin rubber + metallic rim wheel shader
  const wheelMat = new THREE.MeshStandardMaterial({
    vertexColors: true,
    roughness: 0.68,
    metalness: 0.16,
    envMapIntensity: 0.7,
    side: THREE.DoubleSide,
  });

  const wheels: WheelRef[] = [];
  const bodyBox = new THREE.Box3();

  for (const part of header.parts) {
    const pos = new Float32Array(
      b.buffer,
      b.byteOffset + p,
      part.nv * 3
    );
    p += part.nv * 12;

    const nrRaw = new Int8Array(
      b.buffer,
      b.byteOffset + p,
      part.nv * 3
    );
    p += align4(part.nv * 3);

    const co = new Uint8Array(b.subarray(p, p + part.nv * 3));
    p += align4(part.nv * 3);

    const idx = new Uint16Array(
      b.buffer,
      b.byteOffset + p,
      part.ni
    );
    p += align4(part.ni * 2);

    // Only apply livery recolor to body shell (matching original binary model design)
    if (part.n === 'body' && variant.tint) {
      recolorVertexColors(co, variant.tint, variant.model);
    }

    const nr = new Float32Array(part.nv * 3);
    const cf = new Float32Array(part.nv * 3);
    for (let i = 0; i < part.nv * 3; i++) {
      nr[i] = nrRaw[i] / 127;
      cf[i] = LUT[co[i]];
    }

    const g = new THREE.BufferGeometry();
    g.setAttribute('position', new THREE.BufferAttribute(pos, 3));
    g.setAttribute('normal', new THREE.BufferAttribute(nr, 3));
    g.setAttribute('color', new THREE.BufferAttribute(cf, 3));
    g.setIndex(new THREE.BufferAttribute(idx, 1));

    if (part.n === 'body' || part.n === 'glass') {
      g.computeBoundingBox();
      if (g.boundingBox) bodyBox.union(g.boundingBox);
      const mesh = new THREE.Mesh(g, part.n === 'glass' ? glassMat : bodyMat);
      mesh.castShadow = castShadows && part.n === 'body';
      mesh.receiveShadow = castShadows;
      chassis.add(mesh);
    } else if (part.c) {
      const mesh = new THREE.Mesh(g, wheelMat);
      mesh.castShadow = castShadows;
      const pivot = new THREE.Group();
      pivot.position.set(part.c[0], part.c[1], part.c[2]);
      pivot.add(mesh);
      root.add(pivot);
      wheels.push({
        pivot,
        mesh,
        radius: part.r || 0.35,
        // Front wheels have positive Z center in both Supra and Bugatti binaries
        isFront: part.c[2] > 0,
      });
    }
  }

  const minX = Number.isFinite(bodyBox.min.x) ? bodyBox.min.x : -1.0;
  const maxX = Number.isFinite(bodyBox.max.x) ? bodyBox.max.x : 1.0;
  const minZ = Number.isFinite(bodyBox.min.z) ? bodyBox.min.z : -2.25;
  const maxZ = Number.isFinite(bodyBox.max.z) ? bodyBox.max.z : 2.35;
  const halfW = (maxX - minX) * 0.5;

  // Grounding under-car radial contact shadow right above asphalt surface
  const shadowGeo = new THREE.PlaneGeometry(halfW * 2.55, (maxZ - minZ) * 1.14);
  shadowGeo.rotateX(-Math.PI * 0.5);
  const shadowMat = new THREE.MeshBasicMaterial({
    map: tex.contactShadow,
    transparent: true,
    opacity: 0.9,
    depthWrite: false,
    polygonOffset: true,
    polygonOffsetFactor: -1,
    polygonOffsetUnits: -1,
  });
  const shadowMesh = new THREE.Mesh(shadowGeo, shadowMat);
  shadowMesh.position.set(0, 0.018, (minZ + maxZ) * 0.5);
  shadowMesh.renderOrder = 2;
  root.add(shadowMesh);

  // Subtle optical headlight flares (recessed flush inside lamp housings; lit softly in Sunset)
  const headlightGlowMat = new THREE.SpriteMaterial({
    map: tex.headlightGlow,
    color: 0xfff4dc,
    transparent: true,
    opacity: 0.0,
    blending: THREE.AdditiveBlending,
    depthWrite: false,
  });
  const hlPos =
    variant.model === 'sup'
      ? { x: 0.72, y: 0.61, z: 1.98 }
      : { x: 0.66, y: 0.56, z: 2.02 };
  for (const sx of [-1, 1]) {
    const sp = new THREE.Sprite(headlightGlowMat);
    sp.position.set(sx * hlPos.x, hlPos.y, hlPos.z);
    sp.scale.set(0.32, 0.18, 1);
    chassis.add(sp);
  }

  // Twin projected headlight asphalt beam pools (active in Night & subtly in Sunset)
  const headlightBeamMat = new THREE.MeshBasicMaterial({
    map: tex.headlightBeam,
    color: 0xeaf4ff,
    transparent: true,
    opacity: 0.0,
    blending: THREE.AdditiveBlending,
    depthWrite: false,
    side: THREE.DoubleSide,
  });
  const beamGeo = new THREE.PlaneGeometry(3.6, 18.0);
  beamGeo.rotateX(-Math.PI * 0.5);
  for (const sx of [-1, 1]) {
    const beam = new THREE.Mesh(beamGeo, headlightBeamMat);
    beam.position.set(sx * 0.72, 0.055, maxZ + 8.6);
    beam.rotation.y = sx * 0.04;
    beam.renderOrder = 3;
    root.add(beam);
  }

  // Reactive crimson brake-light flares (off when parked in showroom, bright under active braking)
  const brakeGlowMat = new THREE.SpriteMaterial({
    map: tex.brakeGlow,
    color: 0xff2936,
    transparent: true,
    opacity: 0.0,
    blending: THREE.AdditiveBlending,
    depthWrite: false,
  });
  const tlPos =
    variant.model === 'sup'
      ? { x: 0.68, y: 0.74, z: -2.02 }
      : { x: 0.66, y: 0.62, z: -2.38 };
  for (const sx of [-1, 1]) {
    const sp = new THREE.Sprite(brakeGlowMat);
    sp.position.set(sx * tlPos.x, tlPos.y, tlPos.z);
    sp.scale.set(0.56, 0.28, 1);
    chassis.add(sp);
  }

  // Dual exhaust cyan-plasma nitro afterburners
  const nitroGroup = new THREE.Group();
  nitroGroup.position.set(
    0,
    variant.model === 'sup' ? 0.34 : 0.32,
    minZ - 0.02
  );
  nitroGroup.visible = false;

  const coneGeo = new THREE.ConeGeometry(0.135, 1.4, 10);
  coneGeo.rotateX(-Math.PI * 0.5);
  coneGeo.translate(0, 0, -0.68);

  const outerMat = new THREE.MeshBasicMaterial({
    color: 0x22b8ff,
    transparent: true,
    opacity: 0.88,
    blending: THREE.AdditiveBlending,
    depthWrite: false,
  });
  const innerMat = new THREE.MeshBasicMaterial({
    color: 0xffffff,
    transparent: true,
    opacity: 0.96,
    blending: THREE.AdditiveBlending,
    depthWrite: false,
  });

  const nitroCones: THREE.Mesh[] = [];
  const pipeOffsets = variant.model === 'sup' ? [-0.34, 0.34] : [-0.26, 0.26];
  for (const px of pipeOffsets) {
    const outer = new THREE.Mesh(coneGeo, outerMat);
    outer.position.set(px, 0, 0);
    const inner = new THREE.Mesh(coneGeo, innerMat);
    inner.scale.set(0.52, 0.52, 0.72);
    outer.add(inner);
    nitroGroup.add(outer);
    nitroCones.push(outer);
  }

  const spriteMat = new THREE.SpriteMaterial({
    map: tex.nitroGlow,
    color: 0x45d6ff,
    transparent: true,
    opacity: 0.88,
    blending: THREE.AdditiveBlending,
    depthWrite: false,
  });
  const nitroGlow = new THREE.Sprite(spriteMat);
  nitroGlow.scale.set(1.85, 1.1, 1);
  nitroGlow.position.set(0, 0.04, -0.45);
  nitroGroup.add(nitroGlow);
  chassis.add(nitroGroup);

  return {
    root,
    chassis,
    wheels,
    headlightGlowMat,
    headlightBeamMat,
    brakeGlowMat,
    nitroGroup,
    nitroCones,
    nitroGlow,
    modelId: variant.model,
    prevSpeed: 0,
  };
}

export function updateCarVisual(
  vis: CarVisual,
  car: CarState,
  steer: number,
  clockSec: number
) {
  vis.root.position.set(car.x, 0.12, car.z);
  vis.root.rotation.y = car.h;

  // Dynamic suspension body roll & longitudinal pitch
  const targetRoll = -steer * Math.min(1, Math.abs(car.s) / 38) * 0.042;
  const accelDelta = car.s - vis.prevSpeed;
  vis.prevSpeed = car.s;
  const targetPitch = car.brakingActive
    ? 0.025
    : car.nitroActive
      ? -0.022
      : Math.max(-0.016, Math.min(0.02, -accelDelta * 0.024));

  vis.chassis.rotation.z += (targetRoll - vis.chassis.rotation.z) * 0.22;
  vis.chassis.rotation.x += (targetPitch - vis.chassis.rotation.x) * 0.18;

  const knAngle = steer * 0.42;
  for (let i = 0; i < vis.wheels.length; i++) {
    const w = vis.wheels[i];
    w.mesh.rotation.x = car.spin / w.radius;
    if (w.isFront) {
      w.pivot.rotation.y = knAngle;
    }
  }

  // Reactive crimson brake flare during race
  vis.brakeGlowMat.opacity = car.brakingActive ? 0.94 : 0.18;

  // Cyan plasma nitro afterburners
  vis.nitroGroup.visible = car.nitroActive;
  if (car.nitroActive) {
    const pulse = 0.88 + 0.24 * Math.sin(clockSec * 52 + car.idx * 0.7);
    for (let i = 0; i < vis.nitroCones.length; i++) {
      vis.nitroCones[i].scale.set(1, 1, pulse);
    }
    vis.nitroGlow.scale.set(1.85 * pulse, 1.1 * pulse, 1);
  }
}
