import * as THREE from 'three';

const MAX_SMOKE = 140;
const MAX_SPARKS = 90;

interface SmokeParticle {
  active: boolean;
  x: number;
  y: number;
  z: number;
  vx: number;
  vy: number;
  vz: number;
  age: number;
  life: number;
  size0: number;
  size1: number;
  color: THREE.Color;
}

interface SparkParticle {
  active: boolean;
  x: number;
  y: number;
  z: number;
  vx: number;
  vy: number;
  vz: number;
  age: number;
  life: number;
  color: THREE.Color;
}

export class PooledRaceParticles {
  public readonly group = new THREE.Group();
  private smokeMesh: THREE.InstancedMesh;
  private sparkMesh: THREE.InstancedMesh;
  private smokePool: SmokeParticle[] = [];
  private sparkPool: SparkParticle[] = [];
  private smokeHead = 0;
  private sparkHead = 0;

  // Zero-GC scratch objects
  private dummyPos = new THREE.Vector3();
  private dummyQuat = new THREE.Quaternion();
  private dummyScale = new THREE.Vector3();
  private dummyMat = new THREE.Matrix4();
  private lookTarget = new THREE.Vector3();
  private upVec = new THREE.Vector3(0, 1, 0);
  private rotMat = new THREE.Matrix4();
  private hiddenMat = new THREE.Matrix4().makeScale(0, 0, 0);

  constructor() {
    const smokeGeo = new THREE.DodecahedronGeometry(0.42, 1);
    const smokeMat = new THREE.MeshBasicMaterial({
      color: 0xffffff,
      transparent: true,
      opacity: 0.34,
      depthWrite: false,
    });
    this.smokeMesh = new THREE.InstancedMesh(smokeGeo, smokeMat, MAX_SMOKE);
    this.smokeMesh.instanceMatrix.setUsage(THREE.DynamicDrawUsage);
    this.smokeMesh.frustumCulled = false;

    const sparkGeo = new THREE.BoxGeometry(0.08, 0.08, 0.56);
    const sparkMat = new THREE.MeshBasicMaterial({
      color: 0xffffff,
      transparent: true,
      opacity: 0.95,
      blending: THREE.AdditiveBlending,
      depthWrite: false,
    });
    this.sparkMesh = new THREE.InstancedMesh(sparkGeo, sparkMat, MAX_SPARKS);
    this.sparkMesh.instanceMatrix.setUsage(THREE.DynamicDrawUsage);
    this.sparkMesh.frustumCulled = false;

    for (let i = 0; i < MAX_SMOKE; i++) {
      this.smokePool.push({
        active: false,
        x: 0,
        y: 0,
        z: 0,
        vx: 0,
        vy: 0,
        vz: 0,
        age: 0,
        life: 0.5,
        size0: 0.4,
        size1: 1.5,
        color: new THREE.Color(0xdce2ec),
      });
      this.smokeMesh.setMatrixAt(i, this.hiddenMat);
      this.smokeMesh.setColorAt(i, new THREE.Color(0xdce2ec));
    }

    for (let i = 0; i < MAX_SPARKS; i++) {
      this.sparkPool.push({
        active: false,
        x: 0,
        y: 0,
        z: 0,
        vx: 0,
        vy: 0,
        vz: 0,
        age: 0,
        life: 0.3,
        color: new THREE.Color(0xffb338),
      });
      this.sparkMesh.setMatrixAt(i, this.hiddenMat);
      this.sparkMesh.setColorAt(i, new THREE.Color(0xffb338));
    }

    this.group.add(this.smokeMesh);
    this.group.add(this.sparkMesh);
  }

  public emitSmoke(
    x: number,
    y: number,
    z: number,
    vx: number,
    vz: number,
    isGravel: boolean
  ) {
    const p = this.smokePool[this.smokeHead];
    this.smokeHead = (this.smokeHead + 1) % MAX_SMOKE;
    p.active = true;
    p.x = x + (Math.random() - 0.5) * 0.45;
    p.y = y + 0.16;
    p.z = z + (Math.random() - 0.5) * 0.45;
    p.vx = vx * 0.22 + (Math.random() - 0.5) * 1.8;
    p.vy = 1.2 + Math.random() * 1.4;
    p.vz = vz * 0.22 + (Math.random() - 0.5) * 1.8;
    p.age = 0;
    p.life = isGravel ? 0.58 : 0.48;
    p.size0 = isGravel ? 0.45 : 0.36;
    p.size1 = isGravel ? 1.8 : 1.55;
    if (isGravel) {
      p.color.setRGB(0.68, 0.54, 0.34);
    } else {
      p.color.setRGB(0.84, 0.87, 0.92);
    }
  }

  public emitSparks(
    x: number,
    y: number,
    z: number,
    dirX: number,
    dirZ: number,
    count = 10
  ) {
    for (let i = 0; i < count; i++) {
      const p = this.sparkPool[this.sparkHead];
      this.sparkHead = (this.sparkHead + 1) % MAX_SPARKS;
      p.active = true;
      p.x = x;
      p.y = y + 0.35;
      p.z = z;
      p.vx = dirX * (6 + Math.random() * 10) + (Math.random() - 0.5) * 10;
      p.vy = 3.5 + Math.random() * 6.5;
      p.vz = dirZ * (6 + Math.random() * 10) + (Math.random() - 0.5) * 10;
      p.age = 0;
      p.life = 0.22 + Math.random() * 0.18;
      if (Math.random() > 0.4) {
        p.color.setRGB(1.0, 0.72, 0.22);
      } else {
        p.color.setRGB(1.0, 0.94, 0.7);
      }
    }
  }

  public emitBackfire(
    x: number,
    y: number,
    z: number,
    backX: number,
    backZ: number,
    isBlue = false
  ) {
    for (let i = 0; i < 6; i++) {
      const p = this.sparkPool[this.sparkHead];
      this.sparkHead = (this.sparkHead + 1) % MAX_SPARKS;
      p.active = true;
      p.x = x + (Math.random() - 0.5) * 0.35;
      p.y = y + 0.32;
      p.z = z + (Math.random() - 0.5) * 0.35;
      p.vx = backX * (8 + Math.random() * 8) + (Math.random() - 0.5) * 2.5;
      p.vy = 0.6 + Math.random() * 1.4;
      p.vz = backZ * (8 + Math.random() * 8) + (Math.random() - 0.5) * 2.5;
      p.age = 0;
      p.life = 0.11 + Math.random() * 0.08;
      if (isBlue) {
        p.color.setRGB(0.32, 0.85, 1.0);
      } else {
        p.color.setRGB(1.0, 0.52, 0.12);
      }
    }
  }

  public emitSpeedStreak(
    x: number,
    y: number,
    z: number,
    backX: number,
    backZ: number,
    isNitro: boolean
  ) {
    const p = this.sparkPool[this.sparkHead];
    this.sparkHead = (this.sparkHead + 1) % MAX_SPARKS;
    p.active = true;
    p.x = x;
    p.y = y;
    p.z = z;
    p.vx = backX * 36;
    p.vy = 0.1;
    p.vz = backZ * 36;
    p.age = 0;
    p.life = 0.14;
    if (isNitro) {
      p.color.setRGB(0.28, 0.86, 1.0);
    } else {
      p.color.setRGB(0.85, 0.94, 1.0);
    }
  }

  public update(dt: number) {
    let smokeDirty = false;
    for (let i = 0; i < MAX_SMOKE; i++) {
      const p = this.smokePool[i];
      if (!p.active) continue;
      smokeDirty = true;
      p.age += dt;
      if (p.age >= p.life) {
        p.active = false;
        this.smokeMesh.setMatrixAt(i, this.hiddenMat);
        continue;
      }
      const t = p.age / p.life;
      p.x += p.vx * dt;
      p.y += p.vy * dt;
      p.z += p.vz * dt;
      p.vx *= Math.max(0, 1 - dt * 2.5);
      p.vz *= Math.max(0, 1 - dt * 2.5);

      const scale = (p.size0 + (p.size1 - p.size0) * t) * (1 - t * 0.45);
      this.dummyPos.set(p.x, p.y, p.z);
      this.dummyQuat.identity();
      this.dummyScale.set(scale, scale * 0.72, scale);
      this.dummyMat.compose(this.dummyPos, this.dummyQuat, this.dummyScale);
      this.smokeMesh.setMatrixAt(i, this.dummyMat);
      this.smokeMesh.setColorAt(i, p.color);
    }
    if (smokeDirty) {
      this.smokeMesh.instanceMatrix.needsUpdate = true;
      if (this.smokeMesh.instanceColor) {
        this.smokeMesh.instanceColor.needsUpdate = true;
      }
    }

    let sparkDirty = false;
    for (let i = 0; i < MAX_SPARKS; i++) {
      const p = this.sparkPool[i];
      if (!p.active) continue;
      sparkDirty = true;
      p.age += dt;
      if (p.age >= p.life) {
        p.active = false;
        this.sparkMesh.setMatrixAt(i, this.hiddenMat);
        continue;
      }
      const t = p.age / p.life;
      p.vy -= 18 * dt;
      p.x += p.vx * dt;
      p.y = Math.max(0.15, p.y + p.vy * dt);
      p.z += p.vz * dt;

      this.dummyPos.set(p.x, p.y, p.z);
      this.lookTarget.set(p.x + p.vx, p.y + p.vy, p.z + p.vz);
      this.rotMat.lookAt(this.lookTarget, this.dummyPos, this.upVec);
      this.dummyQuat.setFromRotationMatrix(this.rotMat);
      const s = 1 - t * 0.7;
      this.dummyScale.set(s, s, s * 1.15);
      this.dummyMat.compose(this.dummyPos, this.dummyQuat, this.dummyScale);
      this.sparkMesh.setMatrixAt(i, this.dummyMat);
      this.sparkMesh.setColorAt(i, p.color);
    }
    if (sparkDirty) {
      this.sparkMesh.instanceMatrix.needsUpdate = true;
      if (this.sparkMesh.instanceColor) {
        this.sparkMesh.instanceColor.needsUpdate = true;
      }
    }
  }

  public clear() {
    for (let i = 0; i < MAX_SMOKE; i++) {
      this.smokePool[i].active = false;
      this.smokeMesh.setMatrixAt(i, this.hiddenMat);
    }
    for (let i = 0; i < MAX_SPARKS; i++) {
      this.sparkPool[i].active = false;
      this.sparkMesh.setMatrixAt(i, this.hiddenMat);
    }
    this.smokeMesh.instanceMatrix.needsUpdate = true;
    this.sparkMesh.instanceMatrix.needsUpdate = true;
  }

  public dispose() {
    this.smokeMesh.geometry.dispose();
    (this.smokeMesh.material as THREE.Material).dispose();
    this.sparkMesh.geometry.dispose();
    (this.sparkMesh.material as THREE.Material).dispose();
  }
}
