import { CarModelId } from './types';

export class RaceAudio {
  private ctx: AudioContext | null = null;
  private engOscA: OscillatorNode | null = null;
  private engOscB: OscillatorNode | null = null;
  private engOscC: OscillatorNode | null = null;
  private engFilter: BiquadFilterNode | null = null;
  private engGain: GainNode | null = null;

  private skidGain: GainNode | null = null;
  private nitroGain: GainNode | null = null;
  private windGain: GainNode | null = null;
  public muted = false;

  private ensureContext(): AudioContext | null {
    if (typeof window === 'undefined') return null;
    if (
      typeof navigator !== 'undefined' &&
      'userActivation' in navigator &&
      !navigator.userActivation.hasBeenActive
    ) {
      return null;
    }
    if (!this.ctx) {
      const AC =
        window.AudioContext ||
        (window as unknown as { webkitAudioContext: typeof AudioContext })
          .webkitAudioContext;
      if (!AC) return null;
      this.ctx = new AC();
      this.initContinuousSynths(this.ctx);
    }
    if (this.ctx.state === 'suspended') {
      void this.ctx.resume();
    }
    return this.ctx;
  }

  private initContinuousSynths(ctx: AudioContext) {
    // Triple-oscillator GT300 / Quad-Turbo V12 engine synth
    this.engOscA = ctx.createOscillator();
    this.engOscB = ctx.createOscillator();
    this.engOscC = ctx.createOscillator();
    this.engOscA.type = 'sawtooth';
    this.engOscB.type = 'triangle';
    this.engOscC.type = 'square';

    const oscCGain = ctx.createGain();
    oscCGain.gain.value = 0.18;

    this.engFilter = ctx.createBiquadFilter();
    this.engFilter.type = 'lowpass';
    this.engFilter.frequency.value = 650;
    this.engFilter.Q.value = 1.8;

    this.engGain = ctx.createGain();
    this.engGain.gain.value = 0;

    this.engOscA.connect(this.engFilter);
    this.engOscB.connect(this.engFilter);
    this.engOscC.connect(oscCGain);
    oscCGain.connect(this.engFilter);
    this.engFilter.connect(this.engGain);
    this.engGain.connect(ctx.destination);
    this.engOscA.start();
    this.engOscB.start();
    this.engOscC.start();

    // Shared white noise buffer for tyre scrub, nitro jet, and aero slipstream wind
    const bufferSize = ctx.sampleRate * 1.5;
    const noiseBuffer = ctx.createBuffer(1, bufferSize, ctx.sampleRate);
    const data = noiseBuffer.getChannelData(0);
    for (let i = 0; i < bufferSize; i++) {
      data[i] = Math.random() * 2 - 1;
    }

    const skidSrc = ctx.createBufferSource();
    skidSrc.buffer = noiseBuffer;
    skidSrc.loop = true;
    const skidFilter = ctx.createBiquadFilter();
    skidFilter.type = 'bandpass';
    skidFilter.frequency.value = 1480;
    skidFilter.Q.value = 3.4;
    this.skidGain = ctx.createGain();
    this.skidGain.gain.value = 0;
    skidSrc.connect(skidFilter);
    skidFilter.connect(this.skidGain);
    this.skidGain.connect(ctx.destination);
    skidSrc.start();

    const nitroSrc = ctx.createBufferSource();
    nitroSrc.buffer = noiseBuffer;
    nitroSrc.loop = true;
    const nitroFilter = ctx.createBiquadFilter();
    nitroFilter.type = 'bandpass';
    nitroFilter.frequency.value = 820;
    nitroFilter.Q.value = 1.05;
    this.nitroGain = ctx.createGain();
    this.nitroGain.gain.value = 0;
    nitroSrc.connect(nitroFilter);
    nitroFilter.connect(this.nitroGain);
    this.nitroGain.connect(ctx.destination);
    nitroSrc.start();

    const windSrc = ctx.createBufferSource();
    windSrc.buffer = noiseBuffer;
    windSrc.loop = true;
    const windFilter = ctx.createBiquadFilter();
    windFilter.type = 'highpass';
    windFilter.frequency.value = 1850;
    this.windGain = ctx.createGain();
    this.windGain.gain.value = 0;
    windSrc.connect(windFilter);
    windFilter.connect(this.windGain);
    this.windGain.connect(ctx.destination);
    windSrc.start();
  }

  public unlock() {
    this.ensureContext();
  }

  public setMuted(muted: boolean) {
    this.muted = muted;
    if (muted) this.silence();
  }

  public silence() {
    if (!this.ctx) return;
    const t = this.ctx.currentTime;
    this.engGain?.gain.setTargetAtTime(0, t, 0.03);
    this.skidGain?.gain.setTargetAtTime(0, t, 0.03);
    this.nitroGain?.gain.setTargetAtTime(0, t, 0.03);
    this.windGain?.gain.setTargetAtTime(0, t, 0.03);
  }

  public updateTelemetry(
    active: boolean,
    isCountdown: boolean,
    speedMs: number,
    rpmRatio: number,
    nitroActive: boolean,
    skidIntensity: number,
    modelId: CarModelId = 'sup',
    drafting = false
  ) {
    const ctx = this.ensureContext();
    if (!ctx) return;
    const t = ctx.currentTime;
    if (!active || this.muted) {
      this.silence();
      return;
    }

    if (
      this.engGain &&
      this.engOscA &&
      this.engOscB &&
      this.engOscC &&
      this.engFilter
    ) {
      const targetVol = isCountdown ? 0.016 : 0.036 + rpmRatio * 0.022;
      // Supra: crisp higher-revving inline-6 turbo; Bugatti: rich lower V12 harmonic growl
      const pitchScale = modelId === 'sup' ? 1.12 : 0.92;
      const harmonicRatio = modelId === 'sup' ? 1.5 : 1.333;
      const baseFreq =
        (46 + rpmRatio * 134 + speedMs * 0.65 + (nitroActive ? 30 : 0)) *
        pitchScale;
      this.engGain.gain.setTargetAtTime(targetVol, t, 0.04);
      this.engOscA.frequency.setTargetAtTime(baseFreq, t, 0.03);
      this.engOscB.frequency.setTargetAtTime(baseFreq * 0.5, t, 0.03);
      this.engOscC.frequency.setTargetAtTime(baseFreq * harmonicRatio, t, 0.03);
      this.engFilter.frequency.setTargetAtTime(
        390 + rpmRatio * 1050 + (nitroActive ? 580 : 0),
        t,
        0.04
      );
    }

    if (this.skidGain) {
      const skidTarget = isCountdown ? 0 : Math.min(0.062, skidIntensity * 0.058);
      this.skidGain.gain.setTargetAtTime(skidTarget, t, 0.04);
    }

    if (this.nitroGain) {
      const nitroTarget = !isCountdown && nitroActive ? 0.056 : 0;
      this.nitroGain.gain.setTargetAtTime(nitroTarget, t, 0.04);
    }

    if (this.windGain) {
      const speedNorm = Math.max(0, (speedMs - 38) / 55);
      const windTarget = isCountdown
        ? 0
        : Math.min(0.035, speedNorm * 0.014 + (drafting ? 0.016 : 0));
      this.windGain.gain.setTargetAtTime(windTarget, t, 0.06);
    }
  }

  public playGearShift(upshift: boolean) {
    if (this.muted) return;
    const ctx = this.ensureContext();
    if (!ctx) return;
    const now = ctx.currentTime;
    // Crisp motorsport exhaust crack / turbo flutter on gear change
    const osc = ctx.createOscillator();
    const g = ctx.createGain();
    osc.type = 'sawtooth';
    osc.frequency.setValueAtTime(upshift ? 185 : 120, now);
    osc.frequency.exponentialRampToValueAtTime(52, now + 0.08);
    g.gain.setValueAtTime(0.055, now);
    g.gain.exponentialRampToValueAtTime(0.001, now + 0.085);
    osc.connect(g);
    g.connect(ctx.destination);
    osc.start(now);
    osc.stop(now + 0.09);
  }

  public playLapChime(isBest: boolean) {
    if (this.muted) return;
    const ctx = this.ensureContext();
    if (!ctx) return;
    const now = ctx.currentTime;
    const notes = isBest ? [587.33, 739.99, 880, 1174.66] : [523.25, 659.25, 783.99];
    notes.forEach((freq, idx) => {
      const osc = ctx.createOscillator();
      const g = ctx.createGain();
      osc.type = 'triangle';
      const t0 = now + idx * 0.065;
      osc.frequency.setValueAtTime(freq, t0);
      g.gain.setValueAtTime(0.065, t0);
      g.gain.exponentialRampToValueAtTime(0.001, t0 + 0.24);
      osc.connect(g);
      g.connect(ctx.destination);
      osc.start(t0);
      osc.stop(t0 + 0.25);
    });
  }

  public playCountdownTone(go: boolean) {
    if (this.muted) return;
    const ctx = this.ensureContext();
    if (!ctx) return;
    const now = ctx.currentTime;
    const osc = ctx.createOscillator();
    const g = ctx.createGain();
    osc.type = go ? 'triangle' : 'sine';
    osc.frequency.setValueAtTime(go ? 880 : 440, now);
    g.gain.setValueAtTime(0.08, now);
    g.gain.exponentialRampToValueAtTime(0.001, now + (go ? 0.34 : 0.16));
    osc.connect(g);
    g.connect(ctx.destination);
    osc.start(now);
    osc.stop(now + (go ? 0.36 : 0.18));
  }

  public playImpact(strength: number) {
    if (this.muted) return;
    const ctx = this.ensureContext();
    if (!ctx) return;
    const now = ctx.currentTime;
    const vol = Math.min(0.14, 0.04 + strength * 0.006);
    const osc = ctx.createOscillator();
    const g = ctx.createGain();
    osc.type = 'triangle';
    osc.frequency.setValueAtTime(140, now);
    osc.frequency.exponentialRampToValueAtTime(38, now + 0.16);
    g.gain.setValueAtTime(vol, now);
    g.gain.exponentialRampToValueAtTime(0.001, now + 0.17);
    osc.connect(g);
    g.connect(ctx.destination);
    osc.start(now);
    osc.stop(now + 0.18);
  }

  public dispose() {
    if (this.ctx) {
      void this.ctx.close();
      this.ctx = null;
    }
  }
}
