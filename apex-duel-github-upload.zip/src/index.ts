import { RaceHud } from './game/hud';
import { RaceWorld } from './game/RaceWorld';

const canvasRoot = document.getElementById('canvas-root');
const hudRoot = document.getElementById('hud-root');

if (!canvasRoot || !hudRoot) {
  throw new Error('Missing #canvas-root or #hud-root container in index.html');
}

let world: RaceWorld | null = null;

const hud = new RaceHud(hudRoot, {
  onSelectTimeOfDay: (tod) => world?.setTimeOfDay(tod),
  onSelectDifficulty: (d) => world?.setDifficulty(d),
  onSelectCar: (id) => world?.selectCar(id),
  onStartRace: () => world?.startRace(),
  onCycleCamera: () => world?.cycleCamera(),
  onToggleMute: () => world?.toggleMute(),
  onTogglePause: () => world?.togglePause(),
  onRecoverCar: () => world?.recoverPlayer(),
  onRestartRace: () => world?.restartRace(),
  onChangeCar: () => world?.returnToGarage(),
  onTouchControl: (key, val) => world?.setTouchControl(key, val),
});

world = new RaceWorld(canvasRoot, hud.minimapCanvas, (snap) => {
  hud.update(snap);
});

// Auto-start when ?autostart=1 is passed (e.g. direct race / verification)
const params = new URLSearchParams(window.location.search);
if (params.get('autostart') === '1') {
  world.startRace();
}
