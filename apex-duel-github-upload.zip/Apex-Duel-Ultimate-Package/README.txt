APEX DUEL — ULTIMATE EDITION

HOW TO RUN
1. Extract the complete ZIP archive.
2. Keep the assets folder beside “Apex Duel Ultimate.html”.
3. Open the HTML file in Chrome or another modern browser.
4. An internet connection is required to load Three.js from its CDN.

UPGRADES
- Keeps the original detailed Toyota GR Supra GT300 and Bugatti EB110 SS 3D models.
- 3072px-wide transparent PNG mountain panoramas for Day and Sunset.
- Progressive track chunk and car-model loading to avoid a single large startup load.
- Opponent AI looks ahead through bends, brakes before corners, searches for passing lanes, and uses nitro on clear straights.
- Three AI difficulty levels: Rookie, Pro, and Legend.
- Player nitro with an energy meter, recharge, and blue exhaust boost effect.
- Three camera views: Chase, Close, and Hood.
- Pause, resume, restart, and change-car controls.
- Gear and RPM display, nitro meter, and tyre skid marks.
- Skid marks use one dynamic mesh to keep the visual effect lightweight.
- Instanced roadside rocks and image-based trees remain in the environment.

CONTROLS
Keyboard:
  W / Up Arrow = Gas
  S / Down Arrow = Brake
  A-D / Left-Right Arrows = Steer
  Space = Drift
  N = Nitro (use with gas)
  C = Cycle camera
  P = Pause / resume
  R = Reset to track

Touch:
  Use the on-screen steering, gas, brake, drift, and N2O buttons.

ASSET NOTES
- Mountain PNGs are generated background assets included with this game.
- The original car model credits and non-commercial-use notes remain in the HTML menu.
